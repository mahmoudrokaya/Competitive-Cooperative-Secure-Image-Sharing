# Experiment B2 — external image evaluation (frozen A3.1)

The earlier local dataset inventory identifies **39 TIFF files in Data\misc** with names consistent with the USC-SIPI Miscellaneous image collection. **Filenames and dimensions alone do not prove provenance.** The supplied candidate CSV is explicitly UNVERIFIED.

## 1. Check provenance and integrity

Confirm independently that the files came from the USC-SIPI Misc dataset (e.g. original download archive or documented acquisition) and that research use is permitted. Run from the extracted folder:

```powershell
python -m pip install -r requirements.txt
python .\41_B_independent_evaluation.py --self-test
python .\42_B2_verify_and_prepare.py --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data"
```

The verification helper checks 39 file hashes against the earlier dataset inventory, checks uniqueness and image readability. It does NOT prove provenance. If and only if you have independently verified origin and use permissions, run:

```powershell
python .\42_B2_verify_and_prepare.py --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" --confirm-provenance
```

This creates `external_manifest_verified.csv`. If origin cannot be verified, use a different documented external dataset and build a proper manifest instead.

## 2. Execute B2

```powershell
python .\41_B_independent_evaluation.py --phase B2 --external-manifest .\external_manifest_verified.csv --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B"
```

Expected with 39 images: 39 × 7 × 3 × 2 × 6 = **9,828 batches**, **39,312 jobs**. Resume interrupted execution with the same command plus `--resume`. Outputs under `Experiment_B\B2` as `B2_00_manifest.csv`, `B2_01_runs.csv`, `B2_02_summary.csv`, `B2_03_metadata.json`. The existing runner rejects exact SHA-256 overlaps with all BSDS500 partitions.

## 3. Analysis caveats

Report color versus grayscale separately, and stratify by image size. All 39 are from the *Misc* candidate collection; this is not a random sample of the full USC-SIPI corpus. Results are from a simulated network and do not establish full joint optimization or physical-network performance. Preserve B1 as an untouched test evaluation.
