#!/usr/bin/env python3
"""Experiment B: independent-image evaluation of FROZEN A3.1 mechanisms.

B1: BSDS500 test; B2: explicitly sourced external image manifest.
This is not a joint-optimizer benchmark and is not a physical-network test.
"""
import argparse, csv, hashlib, importlib.util, json, platform, sys, time
from collections import defaultdict
from pathlib import Path
from PIL import Image

HERE=Path(__file__).resolve().parent
A31=HERE/'40_A3_1_capacity_aware.py'

def load_a31():
 spec=importlib.util.spec_from_file_location('frozen_a31',A31)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def images(folder):
 return sorted((p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in {'.jpg','.jpeg','.png','.bmp','.tif','.tiff'}),key=lambda p:p.name)

def entry(root,p,split,source):
 with Image.open(p) as im:
  width,height=im.size;mode=im.mode;im.verify()
 return {'source':source,'split':split,'image':p.name,'relative_path':p.relative_to(root).as_posix(),
         'sha256':sha(p),'width':width,'height':height,'mode':mode}

def check_b1(root,limit):
 base=root/'BSR'/'BSDS500'/'data'/'images'
 train=images(base/'train');val=images(base/'val');test=images(base/'test')
 if not train or not val or len(test)!=200:raise ValueError(f'Unexpected BSDS500 partitions: train={len(train)}, val={len(val)}, test={len(test)}')
 train_hashes={sha(p) for p in train};val_hashes={sha(p) for p in val}
 if train_hashes & val_hashes:raise ValueError('train/val overlap detected')
 selected=test if limit==0 else test[:limit]
 out=[entry(root,p,'test','BSDS500') for p in selected]
 if len({e['sha256'] for e in out})!=len(out):raise ValueError('Duplicate test images')
 if {e['sha256'] for e in out} & (train_hashes|val_hashes):raise ValueError('TEST LEAKAGE: test image matches development partition')
 return out,train_hashes|val_hashes,{e['sha256'] for e in out}

def check_b2(root,manifest_path,limit,development_hashes,test_hashes):
 if not manifest_path:raise ValueError('B2 requires --external-manifest with verified provenance')
 with manifest_path.open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
 if not rows:raise ValueError('Empty external manifest')
 for key in ('relative_path','source','license_or_origin'):
  if key not in rows[0]:raise ValueError('External manifest requires: relative_path,source,license_or_origin')
 selected=rows if limit==0 else rows[:limit]
 out=[]
 for row in selected:
  rel=Path(row['relative_path']);p=(root/rel).resolve()
  if not p.is_relative_to(root.resolve()) or not p.is_file():raise ValueError(f'Invalid external path: {rel}')
  if not row['source'].strip() or not row['license_or_origin'].strip():raise ValueError(f'Missing provenance: {rel}')
  e=entry(root,p,'external',row['source'].strip());e['license_or_origin']=row['license_or_origin'].strip()
  if row.get('sha256') and row['sha256'].strip().lower()!=e['sha256']:raise ValueError(f'Hash mismatch: {rel}')
  out.append(e)
 hashes={e['sha256'] for e in out}
 if len(hashes)!=len(out):raise ValueError('Duplicate external images')
 if hashes & (development_hashes|test_hashes):raise ValueError('External image overlaps BSDS500 train/val/test')
 return out

def write_csv(path,rows):
 if not rows:return
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def read_csv(path):
 if not path.exists():return []
 with path.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def key(row):return (row['sha256'],row['scenario'],str(row['repeat']),row['method'],row['mode'])

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--data',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data'))
 p.add_argument('--out',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B'))
 p.add_argument('--phase',choices=('B1','B2'),default='B1')
 p.add_argument('--external-manifest',type=Path,help='CSV with relative_path,source,license_or_origin[,sha256]')
 p.add_argument('--limit',type=int,default=0,help='0 = all images; >0 = deterministic first N images (pilot only)')
 p.add_argument('--repeats',type=int,default=3);p.add_argument('--jobs',type=int,default=4)
 p.add_argument('--seed',type=int,default=4001)
 p.add_argument('--resume',action='store_true',help='Continue matching existing output; verify settings first')
 p.add_argument('--self-test',action='store_true')
 p.add_argument('--save-traces',action='store_true',help='Save large event-trace CSV (off by default)')
 a=p.parse_args()
 if a.limit<0 or a.repeats<1 or a.jobs<1:p.error('Invalid counts')
 frozen=load_a31();s33=frozen.mod('33_expanded_baseline.py');s34=frozen.mod('34_multipath_loss_simulator.py');s35=frozen.mod('35_packet_recovery.py')
 class Config:pass
 cfg=Config();cfg.seed=a.seed;cfg.jobs=a.jobs;cfg.capacity=4;cfg.contention_capacity=2;cfg.policy='fec_arq';cfg.mtu=1000;cfg.header_bytes=20;cfg.fec_group=4;cfg.max_retries=3
 cfg.failed_path=1;cfg.failure_at_ms=180.;cfg.burst_persist=.85;cfg.timeout_ms=3000.;cfg.detection_ms=80.;cfg.queue_penalty_ms=20.;cfg.duplicate_path_penalty_ms=10.;cfg.max_interventions_per_job=3;cfg.max_events=100000;cfg.path_rates=(20.,10.,15.);cfg.path_delays=(10.,40.,25.)
 if a.self_test:
  frozen.self_test(cfg,s33,s34,s35);print('PASS: frozen A3.1 self-test');return
 root=a.data.resolve();out=a.out/a.phase;out.mkdir(parents=True,exist_ok=True)
 b1,dev_hashes,test_hashes=check_b1(root,0)
 selected=(b1 if a.limit==0 else b1[:a.limit]) if a.phase=='B1' else check_b2(root,a.external_manifest,a.limit,dev_hashes,test_hashes)
 if not selected:raise ValueError('No images selected')
 prefix=a.phase
 manifest_path=out/f'{prefix}_00_manifest.csv';runs_path=out/f'{prefix}_01_runs.csv';summary_path=out/f'{prefix}_02_summary.csv';metadata_path=out/f'{prefix}_03_metadata.json';trace_path=out/f'{prefix}_04_event_traces.csv'
 frozen_hashes={name:sha(HERE/name) for name in ('40_A3_1_capacity_aware.py','33_expanded_baseline.py','34_multipath_loss_simulator.py','35_packet_recovery.py')}
 settings={'phase':a.phase,'seed':a.seed,'jobs':a.jobs,'repeats':a.repeats,'scenarios':list(frozen.SCENARIOS),'methods':list(frozen.METHODS),'modes':list(frozen.MODES),'code_sha256':frozen_hashes,'dataset_root':str(root),'image_manifest':selected,'save_traces':a.save_traces}
 settings_sha=hashlib.sha256(json.dumps(settings,sort_keys=True).encode()).hexdigest()
 if runs_path.exists() and not a.resume:raise FileExistsError(f'{runs_path} already exists. Use --resume or choose a new output directory.')
 if a.resume and metadata_path.exists():
  old=json.loads(metadata_path.read_text(encoding='utf-8'))
  if old.get('settings_sha256')!=settings_sha:raise ValueError('Cannot resume: settings or image manifest changed')
 if a.resume and runs_path.exists() and not metadata_path.exists():raise ValueError('Cannot resume without matching metadata')
 write_csv(manifest_path,selected)
 metadata={'status':'independent image evaluation of frozen A3.1 organizational mechanisms; not joint optimizer','settings_sha256':settings_sha,'settings':settings,'python':sys.version,'platform':platform.platform(),'pillow':Image.__version__,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'expected_batches':len(selected)*len(frozen.SCENARIOS)*a.repeats*len(frozen.METHODS)*len(frozen.MODES),'limitations':['Simulated network, not physical network','Frozen A3.1 fixed protection/recovery; no joint optimizer claims','Idealized queue timing and abstract ownership commitments','B2 external provenance supplied by user manifest; not independently certified','Timeout-censored completion time includes failed jobs']}
 metadata_path.write_text(json.dumps(metadata,indent=2),encoding='utf-8')
 existing=read_csv(runs_path) if a.resume else []
 seen={key(r) for r in existing}
 if len(seen)!=len(existing):raise ValueError('Duplicate keys in existing results')
 if a.resume and a.save_traces and existing:raise ValueError('Trace resume is unsupported: run without --save-traces or use a fresh output directory')
 if a.save_traces and trace_path.exists():raise FileExistsError(f'Existing trace file: {trace_path}')
 n_new=0
 with runs_path.open('a' if existing else 'w',newline='',encoding='utf-8-sig' if not existing else 'utf-8') as rf:
  writer=None
  if existing:writer=csv.DictWriter(rf,fieldnames=list(existing[0]))
  tf=trace_path.open('w',newline='',encoding='utf-8-sig') if a.save_traces else None
  tw=None
  try:
   for i,e in enumerate(selected,1):
    path=root/e['relative_path']
    if sha(path)!=e['sha256']:raise RuntimeError(f'Image changed: {path}')
    with Image.open(path) as im:rgb=im.convert('RGB').tobytes()
    for sc in frozen.SCENARIOS:
     for rep in range(a.repeats):
      for method in frozen.METHODS:
       for mode in frozen.MODES:
        k=(e['sha256'],sc,str(rep),method,mode)
        if k in seen:continue
        traces=[]
        row=frozen.execute(e,rgb,method,mode,sc,rep,cfg,s33,s34,s35,traces)
        row={'source':e['source'],**row}
        if writer is None:
         writer=csv.DictWriter(rf,fieldnames=list(row));writer.writeheader()
        writer.writerow(row);rf.flush();seen.add(k);n_new+=1
        if tf is not None:
         for event in traces:
          event={'source':e['source'],**event}
          if tw is None:tw=csv.DictWriter(tf,fieldnames=list(event));tw.writeheader()
          tw.writerow(event)
    print(f'[{i}/{len(selected)}] {e["image"]}: complete (new rows={n_new})',flush=True)
  finally:
   if tf is not None:tf.close()
 rows=read_csv(runs_path)
 groups=defaultdict(list)
 for row in rows:groups[(row['method'],row['mode'])].append(row)
 summaries=[]
 for (method,mode),group in sorted(groups.items()):
  def mean(field):return sum(float(r[field]) for r in group)/len(group)
  summaries.append({'method':method,'mode':mode,'batches':len(group),'jobs':sum(int(r['jobs']) for r in group),'success_rate':sum(int(r['successes']) for r in group)/sum(int(r['jobs']) for r in group),'mean_wire_ratio':mean('wire_ratio'),'mean_censored_ms':mean('mean_censored_ms'),'assists':sum(int(r['assists']) for r in group),'reassignments':sum(int(r['reassignments']) for r in group),'queued_requests':sum(int(r['queued_requests']) for r in group),'blocked_interventions':sum(int(r['blocked_interventions']) for r in group),'capacity_violations':sum(int(r['capacity_violations']) for r in group)})
 write_csv(summary_path,summaries)
 metadata['completed_batches']=len(rows);metadata['new_batches']=n_new;metadata['complete']=len(rows)==metadata['expected_batches'];metadata['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 metadata_path.write_text(json.dumps(metadata,indent=2),encoding='utf-8')
 print(f'COMPLETE: {len(rows)}/{metadata["expected_batches"]} batches; output={out}')

if __name__=='__main__':main()
