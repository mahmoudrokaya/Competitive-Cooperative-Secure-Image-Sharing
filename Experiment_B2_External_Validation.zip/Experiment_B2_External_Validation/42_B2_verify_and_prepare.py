"""Verify external candidates against actual local bytes and create a B2 manifest ONLY with explicit provenance confirmation."""
import argparse,csv,hashlib,pathlib,sys
from PIL import Image
p=argparse.ArgumentParser()
p.add_argument('--data',type=pathlib.Path,required=True)
p.add_argument('--candidates',type=pathlib.Path,default=pathlib.Path(__file__).with_name('B2_00_candidate_manifest_REVIEW.csv'))
p.add_argument('--out',type=pathlib.Path,default=pathlib.Path(__file__).with_name('external_manifest_verified.csv'))
p.add_argument('--confirm-provenance',action='store_true',help='You independently verified that these files originate from USC-SIPI Misc and have appropriate use permissions')
a=p.parse_args()
with a.candidates.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
if not rows:raise SystemExit('No candidate rows')
root=a.data.resolve(); hashes=set();bad=[]
for row in rows:
 path=(root/row['relative_path']).resolve()
 if not path.is_relative_to(root) or not path.is_file():bad.append(f'MISSING/UNSAFE {path}');continue
 h=hashlib.sha256()
 with path.open('rb') as file:
  for chunk in iter(lambda:file.read(1024*1024),b''):h.update(chunk)
 if h.hexdigest().lower()!=row['sha256'].lower():bad.append(f'HASH MISMATCH {path}')
 if h.hexdigest() in hashes:bad.append(f'DUPLICATE {path}')
 hashes.add(h.hexdigest())
 try:
  with Image.open(path) as im: im.verify()
 except Exception as exc:bad.append(f'INVALID IMAGE {path}: {exc}')
print(f'Candidates: {len(rows)}; unique hashes: {len(hashes)}; errors: {len(bad)}')
for issue in bad:print(issue)
if bad:raise SystemExit('STOP: fix validation errors; no verified manifest written')
if not a.confirm_provenance:
 print('File integrity checks passed, but provenance is NOT established by matching filenames/hashes.')
 print('Check the original USC-SIPI download/archive and rights, then rerun with --confirm-provenance.')
 sys.exit(0)
with a.out.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['relative_path','source','license_or_origin','sha256']);w.writeheader()
 for row in rows:w.writerow({'relative_path':row['relative_path'],'source':'USC-SIPI Misc','license_or_origin':'USC-SIPI Misc dataset; provenance independently confirmed by user','sha256':row['sha256']})
print('Verified manifest written:',a.out)
