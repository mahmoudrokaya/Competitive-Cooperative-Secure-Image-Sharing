# Experiment B — Independent Image Evaluation

This package evaluates the **frozen A3.1 organizational simulator** on images that were excluded from development. It is **not** the complete Section 2.3 joint optimizer.

## Contents

- `41_B_independent_evaluation.py`: B1 and B2 runner with leakage checks and resumable CSV output.
- `40_A3_1_capacity_aware.py`: frozen A3.1 event-driven simulation.
- `33_expanded_baseline.py`, `34_multipath_loss_simulator.py`, `35_packet_recovery.py`: original protection/transport modules.
- `requirements.txt`: dependencies.
- `external_manifest_template.csv`: B2 schema (example only, not real verified provenance).

## Installation (PowerShell)

```powershell
cd "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Experiment_B_Independent_Image_Evaluation"
python -m pip install -r requirements.txt
python .\41_B_independent_evaluation.py --self-test
```

## B1: smoke run, 2 reserved test images

**Important:** The smoke run *reads* two held-out test images. It must not be used to tune algorithms or weights. To avoid any test exposure before the full evaluation, skip the smoke run and execute the full B1 directly after self-test.

```powershell
python .\41_B_independent_evaluation.py --phase B1 --limit 2 --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B_Pilot"
```

## B1: full independent evaluation, all 200 BSDS500 test images

```powershell
python .\41_B_independent_evaluation.py --phase B1 --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B"
```

Expected: **200 × 7 scenarios × 3 repeats × 2 protection methods × 6 organizational modes = 50,400 batches** (201,600 simulated jobs). This is computationally intensive. Default omits the potentially enormous event traces. If interrupted, rerun the exact command with `--resume`. Output: `Experiment_B\B1\B1_00_manifest.csv`, `B1_01_runs.csv`, `B1_02_summary.csv`, `B1_03_metadata.json`.

## B2: external evaluation

Do **not** assume all files in `Data\misc` are USC-SIPI. Create a CSV listing **verified** external images relative to the Data root with `relative_path,source,license_or_origin`, and optionally `sha256`. Example schema in `external_manifest_template.csv`. For every image, provide genuine provenance; don't copy placeholder text.

```powershell
python .\41_B_independent_evaluation.py --phase B2 --external-manifest ".\external_manifest_verified.csv" --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B"
```

B2 checks image hashes against *all* BSDS500 train/validation/test images and rejects overlaps. Report B1 and B2 separately.

## Limitations and reporting

- Network paths are simulated. Timings are model-derived and timeout-censored.
- A3.1 keeps protection and recovery fixed within each organizational comparison; **do not call this an independent evaluation of the full joint optimizer**.
- Baseline capacity rules are matched. Assistance/reassignment semantics are simulated, not distributed protocols.
- Report the image as the generalization unit and batch as the unit for paired scenario-level inference; jobs within batches are dependent.
- If evaluating the full joint optimizer later, use an explicitly frozen version, avoid changing hyperparameters after observing B1/B2, and report separately.
