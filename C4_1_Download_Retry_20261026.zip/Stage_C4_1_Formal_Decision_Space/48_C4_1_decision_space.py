#!/usr/bin/env python3
"""C4.1 proposed joint decision-space validator. No performance claims or HHO here."""
import argparse, csv, hashlib, itertools, json, math
from dataclasses import asdict, dataclass
from pathlib import Path

MODES=('static','bidding_ownership_assist','bidding_ownership_reassign','full')
METHODS=('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')
POLICIES=('arq','fec_arq')

@dataclass(frozen=True)
class Decision:
    method: str
    mode: str
    policy: str
    path_count: int
    # Fractions of total offered traffic; 0 for inactive paths.
    allocation: tuple
    fec_parity: int
    arq_limit: int
    # 1: permit organizational assistance, 0: prohibit.
    assistance: int
    # 1: permit reassignment, 0: prohibit.
    reassignment: int


def validate(d, max_paths=3, max_arq=3, max_parity=2, max_active=3):
    errors=[]
    if d.method not in METHODS: errors.append('unknown_method')
    if d.mode not in MODES: errors.append('unknown_mode')
    if d.policy not in POLICIES: errors.append('unknown_policy')
    if not isinstance(d.path_count,int) or not 1<=d.path_count<=max_active: errors.append('invalid_path_count')
    if len(d.allocation)!=max_paths: errors.append('allocation_dimension')
    elif any(not math.isfinite(v) or v < 0 for v in d.allocation): errors.append('allocation_nonnegative_finite')
    elif abs(sum(d.allocation)-1)>1e-8: errors.append('allocation_sum')
    elif sum(v>1e-9 for v in d.allocation)!=d.path_count: errors.append('allocation_active_paths')
    if not isinstance(d.arq_limit,int) or not 0<=d.arq_limit<=max_arq: errors.append('arq_bounds')
    if not isinstance(d.fec_parity,int) or not 0<=d.fec_parity<=max_parity: errors.append('parity_bounds')
    if d.policy=='arq' and d.fec_parity!=0: errors.append('arq_no_fec_parity')
    if d.policy=='fec_arq' and d.fec_parity==0: errors.append('fec_requires_parity')
    if d.method=='AESGCM_XOR_Erasure_2of3' and d.path_count<2: errors.append('multipath_requires_two_paths')
    if d.assistance not in (0,1) or d.reassignment not in (0,1): errors.append('invalid_organizational_flags')
    if d.mode=='static' and (d.assistance or d.reassignment): errors.append('static_disallows_interventions')
    if d.mode=='bidding_ownership_assist' and (d.assistance!=1 or d.reassignment!=0): errors.append('assist_mode_flags')
    if d.mode=='bidding_ownership_reassign' and (d.assistance!=0 or d.reassignment!=1): errors.append('reassign_mode_flags')
    if d.mode=='full' and (d.assistance!=1 or d.reassignment!=1): errors.append('full_mode_flags')
    return errors


def project_allocation(weights, active, max_paths=3):
    """Deterministic repair of nonnegative allocation for selected active path IDs."""
    if not active or len(set(active))!=len(active) or any(i<0 or i>=max_paths for i in active):
        raise ValueError('invalid active path indices')
    if len(weights)!=max_paths or any(not math.isfinite(v) for v in weights):
        raise ValueError('weights must be finite with correct dimension')
    raw=[max(0.0, weights[i]) for i in active]
    total=sum(raw)
    if total<=0: raw=[1.0]*len(active); total=len(active)
    out=[0.0]*max_paths
    for i,v in zip(active,raw): out[i]=v/total
    return tuple(out)


def make_decision(method,mode,policy,active,weights,fec_parity,arq_limit):
    flags={'static':(0,0),'bidding_ownership_assist':(1,0),
           'bidding_ownership_reassign':(0,1),'full':(1,1)}
    a,r=flags[mode]
    return Decision(method,mode,policy,len(active),project_allocation(weights,active),
                    fec_parity,arq_limit,a,r)


def create_candidates():
    # A small, reproducible INITIAL space, not a complete search of all allocations.
    allocs=((0,), (0,1), (0,1,2))
    rows=[]
    for method,mode,policy,active,arq in itertools.product(METHODS,MODES,POLICIES,allocs,(1,2)):
        for fec in ((0,) if policy=='arq' else (1,2)):
            d=make_decision(method,mode,policy,active,(1,1,1),fec,arq)
            errors=validate(d)
            rows.append((d,errors))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',required=True)
    args=p.parse_args(); out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    candidates=create_candidates()
    with (out/'C41_01_decision_space.csv').open('w',newline='',encoding='utf-8') as f:
        fields=['candidate_id']+list(Decision.__dataclass_fields__)+['feasible','violations']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for i,(d,errors) in enumerate(candidates,1):
            row=asdict(d);row['allocation']=json.dumps(row['allocation'])
            w.writerow({'candidate_id':f'D{i:04d}',**row,'feasible':int(not errors),'violations':';'.join(errors)})
    summary={'stage':'C4.1 proposed decision-space specification','formal_manuscript_J1_J6_confirmed':False,
             'simulation_executed':False,'HHO_executed':False,
             'total_generated':len(candidates),'feasible':sum(not e for _,e in candidates),
             'infeasible':sum(bool(e) for _,e in candidates),
             'search_space_note':'finite initial seed grid; allocations currently equal-share; continuous search not executed',
             'validation':'deterministic structural constraints only; no network-capacity or confidentiality verification',
             'objectives_status':'proposed definitions only; unmeasured terms are not assigned artificial scores'}
    (out/'C41_00_audit.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
