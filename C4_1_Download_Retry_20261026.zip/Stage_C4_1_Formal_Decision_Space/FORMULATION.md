# Stage C4.1 — Proposed mathematical formulation (author confirmation required)

**Status:** research-engineering proposal, NOT verified against the manuscript's original J1–J6 definitions. No new simulator or HHO experiment is conducted in this package.

## Decision vector
For image/job i in scenario s, let

x = (m, o, r, z_1..z_P, a_1..a_P, q, h, u, v),

where m is the cryptographic transport method, o organizational mode, r recovery policy, z_p binary path activation, a_p nonnegative traffic fraction, q parity budget, h ARQ retry limit, and u/v binary assistance/reassignment switches. The provided implementation uses P=3 and represents activation via an ordered set of active paths. The `allocation` tuple represents a_p. **These are proposed design variables; A3.1 has not been instrumented to apply all of them.**

## Proposed J1–J6, all minimized

J1(x) = 1 - Pr[authenticated image reconstruction succeeds | x]. **Measured surrogate:** 1 − empirical reconstruction success rate.

J2(x) = E[min(T(x), tau)] / tau, where tau is a prespecified timeout. **Measured surrogate:** censored completion time divided by tau (3000 ms in existing C3).

J3(x) = E[B_wire(x)/B_payload(x)] / B_ref, where B_ref is a prespecified communication normalization. **Measured surrogate:** C3 wire ratio; denominator choice must be fixed before experiments.

J4(x) = Pr[security-policy violation | x] or a prespecified severity-weighted risk metric. **NOT independently measured**: zero recorded simulator exposure violations is NOT a measurement of cryptographic security. Requires threat model, confidentiality/authentication tests, and operational instrumentation. AES-GCM provides authenticated encryption under appropriate nonce/key handling; XOR erasure coding does not constitute cryptographic secret sharing.

J5(x) = E[resource contention/coordination cost | x]/C_ref. **NOT measured** in C3; mode complexity is a structural proxy, not empirical coordination cost. Requires measured bidding messages, control traffic, handoff delays, and computational cost.

J6(x) = E[load imbalance or path-capacity utilization penalty | x], e.g. sum_p (load_p/capacity_p − mean_active_utilization)^2 / P. **NOT measured** in C3; requires per-path capacity/load instrumentation. This proposed definition is not the C4 proxy 'redundancy complexity'.

**No weighted six-objective score is calculated until all six quantities are operationally defined and measured.** A possible preregistered scalarization is F(x)=sum_k w_k normalized_Jk(x), with w_k >=0 and sum w_k=1. The weights and reference scales must be confirmed before test-set evaluation. Pareto ranking is an alternative; neither is claimed as the original manuscript method.

## Feasibility constraints

1. z_p ∈ {0,1}, a_p ≥ 0, a_p=0 if z_p=0, sum_p a_p=1; number of active paths equals path_count.
2. Active paths ≤ P; resource demands must not exceed per-path capacity (requires measured network state; **not checked** by this standalone validator).
3. XOR 2-of-3 erasure transport requires ≥2 active paths in this **proposed conservative policy**; confirm actual simulator semantics before deployment.
4. 0≤q≤2 integer; ARQ-only means q=0, FEC+ARQ means q≥1.
5. 0≤h≤3 integer; mode-dependent assistance and reassignment flags must agree.
6. Hard resource ceilings, timeout, confidentiality policy and no integrity violations must be enforced by simulator evaluation, **not inferred from structural feasibility**.

## Selection protocol

Optimize **training images only**; freeze objective definitions, weights, constraints, algorithm settings, and selected configuration before validation. Existing BSDS500 validation has already been inspected repeatedly and must be labeled development validation. Reserve BSDS500 test and external TIFF images for final frozen evaluation. For any new HHO comparison, enforce identical simulator call budgets, multiple random seeds, an exhaustive oracle on tiny discrete subsets, and matched network traces when technically feasible.

## Important limitations

- The existing C3 candidate grid covers 16 (method,mode,policy) combinations; this C4.1 file creates a **new structural decision space** with path allocation, parity, and retries, but does not evaluate those new combinations.
- Equal-share allocations in the generated seed grid are only initialization examples; no continuous optimizer or joint path allocator is connected.
- A3.1 must be modified and instrumented before the new variables can affect network outcomes.
- J4/J5/J6 need new measured evidence. Do not substitute proxy scores and call the result six-objective optimization.
- The exact manuscript J1–J6 equations and constraints must be supplied to confirm or replace this proposal.
