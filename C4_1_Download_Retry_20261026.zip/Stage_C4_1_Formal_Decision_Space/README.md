# Stage C4.1: Proposed six-objective formulation and decision-space implementation

This package **does not** claim the manuscript's formal J1–J6 are implemented. Read `FORMULATION.md` first.

## Windows PowerShell

```powershell
python .\48_C4_1_decision_space.py --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C4_1"
python -m unittest .\test_c41.py
```

No external Python packages are required. Outputs: `C41_00_audit.json` and `C41_01_decision_space.csv`. The latter is a *structural feasibility inventory*, not measured performance data.

## Before C4.2

1. Supply author-confirmed J1–J6 equations, objective directions, weights/constraints and security threat model.
2. Instrument the A3.1 simulator to accept `Decision` fields and report path loads, coordination costs, and security tests.
3. Test that changing each decision variable actually changes the intended simulator behavior.
4. Integrate HHO and baseline optimizers with equal evaluation budgets and held-out final evaluation.
