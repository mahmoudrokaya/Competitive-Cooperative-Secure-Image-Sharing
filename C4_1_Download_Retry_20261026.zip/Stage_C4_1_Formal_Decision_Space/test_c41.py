import unittest
from importlib.machinery import SourceFileLoader
from pathlib import Path
m=SourceFileLoader('c41',str(Path(__file__).with_name('48_C4_1_decision_space.py'))).load_module()
class Tests(unittest.TestCase):
    def test_feasible(self):
        d=m.make_decision(m.METHODS[0],'static','arq',(0,),(1,1,1),0,1)
        self.assertEqual(m.validate(d),[])
    def test_multipath(self):
        d=m.make_decision(m.METHODS[1],'static','arq',(0,),(1,1,1),0,1)
        self.assertIn('multipath_requires_two_paths',m.validate(d))
    def test_allocation(self):
        self.assertEqual(sum(m.project_allocation((2,1,1),(0,1))),1)
    def test_all_candidates(self):
        rows=m.create_candidates()
        self.assertGreater(len(rows),100)
        self.assertTrue(any(e for _,e in rows))
        self.assertTrue(any(not e for _,e in rows))
if __name__=='__main__':unittest.main()
