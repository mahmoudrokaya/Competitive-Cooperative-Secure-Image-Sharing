# Experiment A — joint adaptive optimization: executable pilot

## What is implemented

- Six policy configurations J1–J6, changing protection method, packet recovery, and fragment–path assignment.
- Reuses the original Step 33 image-protection routines, Step 34 share construction, and Step 35 transport/recovery.
- Uses only `train` and `val` BSDS500 folders; does not load the held-out `test` folder.
- Chooses candidate decisions from an **ex ante** analytic risk/cost proxy, without consulting generated future packet traces or post-commit failure outcomes.
- Records paired scenario keys, end-to-end reconstruction, traffic, timeout-censored completion, decision runtime, and objective components.
- Includes a six-arm smoke test and run-level/summary CSV output.

## Requirements

Python 3.10+ with `Pillow` and `cryptography`. The scripts do not require a GPU.

```
python -m pip install pillow cryptography
python 37_joint_optimizer_pilot.py --self-test
```

Development images must be arranged as:

```
DATA_ROOT/BSR/BSDS500/data/images/train/*.jpg
DATA_ROOT/BSR/BSDS500/data/images/val/*.jpg
```

Example development experiment on Windows:

```
python 37_joint_optimizer_pilot.py --data "D:\\PATH\\TO\\DATA_ROOT" --out "A_Pilot_Results" --max-images 2 --repeats 3 --jobs 4
```

For tasks requiring authenticated encryption:

```
python 37_joint_optimizer_pilot.py --data "D:\\PATH\\TO\\DATA_ROOT" --out "A_Authenticated_Results" --max-images 2 --repeats 3 --require-authentication
```

**Outputs:** `A_01_runs.csv`, `A_02_summary.csv`, and `A_03_metadata.json`.

## Critical research limitations — do not overclaim

This is a **functional pilot**, not the finished Section 2.3 joint optimizer. The current model does **not** implement cumulative adversarial exposure, formal ownership-state transitions, detailed per-agent processing capacities, or full security-state feasibility constraints. Its analytic score is a simplified planning proxy, and its queue/intervention behavior is less comprehensive than the original Step 36A1 organizational simulator. The policy comparisons can be used to check feasibility, logging, and candidate selection, but should not yet be presented as final evidence of the proposed framework's superiority.

**Required before publishable Experiment A:** integrate the exact Section 2.3 objective/constraints, enforce all security and commitment states, model agent–path resource contention faithfully, include per-task method eligibility and costs, pre-register weights/baselines, run matched training/validation experiments, then evaluate independent held-out data. Do not tune on held-out images.

## Integrity note

The supplied `44_cajo_experimental_core.py` is about *Edge AI pruning and knowledge distillation* and is unrelated to secure-image-sharing joint optimization. It is deliberately excluded.
