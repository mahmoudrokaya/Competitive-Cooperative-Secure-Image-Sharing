#!/usr/bin/env python3
"""Experiment A: six-arm decision-time-only joint-selection PILOT.

This is an executable feasibility/protocol pilot, NOT validated security-aware
joint optimization. Security eligibility is a conservative task-level filter;
cumulative compromise-domain exposure, dynamic security-state constraints and
full Section 2.3 optimizer remain future implementation work.

Only train/val BSDS500 images are loaded. Test images are never read.
"""
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json,math,platform,statistics,sys,time
from pathlib import Path
from PIL import Image

HERE=Path(__file__).resolve().parent
ARMS={
 'J1_static':(False,False,False),
 'J2_recovery':(False,True,False),
 'J3_organization':(False,False,True),
 'J4_protection':(True,False,False),
 'J5_recovery_organization':(False,True,True),
 'J6_joint':(True,True,True),
}
METHODS=('XOR_2of2','Shamir_GF256_2of3','AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')
POLICIES=('none','fec','arq','fec_arq')
FIELDS=['split','image','sha256','scenario','loss_rate','repeat','arm','method','policy','path_assignment','jobs','successful_jobs','success_rate','wire_bytes','wire_ratio','mean_censored_ms','interventions','objective','optimizer_ms','candidate_count','rejected_candidates','trace_key']

def load(name,filename):
 s=importlib.util.spec_from_file_location(name,str(HERE/filename));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def stable(*parts):return int.from_bytes(hashlib.sha256('|'.join(map(str,parts)).encode()).digest()[:8],'big')

def estimated_packet_success(nbytes,loss,policy,mtu,group=4,retries=3):
 # Pre-decision analytic proxy; never consults actual future loss traces.
 packets=max(1,math.ceil(nbytes/mtu)); q=loss**(retries+1) if policy in ('arq','fec_arq') else loss
 if policy in ('fec','fec_arq'):
  # conservative group success estimate: at most one missing among 4 packets
  block=(1-q)**group+group*q*(1-q)**(group-1)
  return max(0.,min(1.,block**math.ceil(packets/group)))
 return (1-q)**packets

def forecast(shares,required,method,policy,assignment,loss,scenario,args):
 probs=[];wire=0.;completion=0.
 for (sid,blob),path in zip(shares,assignment):
  p=loss  # post-commit failures are not known to the planner
  probs.append(estimated_packet_success(len(blob),p,policy,args.mtu))
  k=math.ceil(len(blob)/args.mtu)
  factor=1+(1/args.fec_group if policy in ('fec','fec_arq') else 0)
  if policy in ('arq','fec_arq'):factor+=sum(p**j for j in range(1,args.max_retries+1))
  bytes_est=(len(blob)+k*args.header_bytes)*factor
  wire+=bytes_est
  completion=max(completion,args.path_delays[path]+bytes_est*8/(args.path_rates[path]*1000))
 # exact probability at least 'required' fragments survive independently
 distribution=[1.]
 for p in probs:
  nxt=[0.]*(len(distribution)+1)
  for i,x in enumerate(distribution):nxt[i]+=x*(1-p);nxt[i+1]+=x*p
  distribution=nxt
 reliability=sum(distribution[required:])
 # Conservative normalized surrogate: reliability / latency / bytes.
 reference=max(1,sum(len(blob) for _,blob in shares))
 score=args.w_failure*(1-reliability)+args.w_time*completion/args.timeout_ms+args.w_wire*wire/reference
 return score,reliability,wire,completion

def assignments(n,adaptive):
 if not adaptive:return [tuple(i%3 for i in range(n))]
 import itertools
 return [p for p in itertools.product(range(3),repeat=n) if len(set(p))==n] if n<=3 else []

def choose(rgb,modules,arm,scenario,loss,args):
 s33,s34,s35=modules
 protection,recovery,organization=ARMS[arm]
 methods=METHODS if protection else (args.fixed_method,)
 policies=POLICIES if recovery else (args.fixed_policy,)
 best=None;checked=0;rejected=0
 for method in methods:
  # Task requires authenticated confidentiality: XOR/Shamir excluded.
  if args.require_authentication and method not in ('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3'):
   rejected+=len(policies);continue
  shares,decoder,target,required=s34.make_shares(s33,method,rgb,b'')
  for policy in policies:
   for assignment in assignments(len(shares),organization):
    checked+=1
    score,pr,wire,delay=forecast(shares,required,method,policy,assignment,loss,scenario,args)
    key=(score,method,policy,assignment)
    if best is None or key<best[0]:best=(key,dict(method=method,policy=policy,assignment=assignment,shares=shares,decoder=decoder,target=target,required=required,score=score))
 if best is None:raise RuntimeError('No feasible candidates: check task constraints')
 return best[1],checked,rejected

def execute_job(job,scenario,loss,repeat,jid,args,s35):
 receipts={};times=[];wire=0;failed=[];interventions=0
 for (sid,blob),path in zip(job['shares'],job['assignment']):
  # A permanent failure is revealed only during execution, not selection.
  permanent=scenario=='post_commit_failure' and path==args.failed_path
  if permanent:
   failed.append((sid,blob,path,True));continue
  kind='burst' if scenario=='burst' else 'iid'
  got,w,_,_,_,_,ms=s35.transport(blob,path,job['policy'],kind,loss,repeat+jid*100000,args)
  wire+=w
  if got is None:failed.append((sid,blob,path,False))
  else:receipts[sid]=got;times.append(ms)
 # organizational adaptation: one eligible intervention, without future trace access.
 if job['organization'] and len(receipts)<job['required'] and failed:
  sid,blob,old,permanent=failed[0]
  possible=[p for p in range(3) if p!=old and not (scenario=='post_commit_failure' and p==args.failed_path)]
  if possible:
   new=min(possible,key=lambda p:(args.path_delays[p]+len(blob)*8/(args.path_rates[p]*1000),p))
   kind='burst' if scenario=='burst' else 'iid'
   got,w,_,_,_,_,ms=s35.transport(blob,new,job['policy'],kind,loss,repeat+jid*100000+args.backup_rep_offset,args)
   wire+=w;interventions+=1
   if got is not None:receipts[sid]=got;times.append(args.detection_ms+ms)
 ok=len(receipts)>=job['required']
 if ok:
  try:ok=job['decoder'](receipts)==job['target']
  except Exception:ok=False
 return int(ok),wire,(max(sorted(times)[:job['required']]) if ok else args.timeout_ms),interventions

def evaluate(image,modules,scenario,loss,rep,arm,args):
 split,name,sha,rgb=image;s35=modules[2]
 t0=time.perf_counter();plan,n,rejected=choose(rgb,modules,arm,scenario,loss,args);optimizer_ms=(time.perf_counter()-t0)*1000
 job={**plan,'organization':ARMS[arm][2]}
 outcomes=[execute_job(job,scenario,loss,rep,j,args,s35) for j in range(args.jobs)]
 succ=sum(x[0] for x in outcomes);wire=sum(x[1] for x in outcomes);elapsed=statistics.mean(x[2] for x in outcomes)
 base=len(rgb)*args.jobs
 objective=args.w_failure*(1-succ/args.jobs)+args.w_time*elapsed/args.timeout_ms+args.w_wire*wire/max(1,base)
 return dict(split=split,image=name,sha256=sha,scenario=scenario,loss_rate=loss,repeat=rep,arm=arm,method=plan['method'],policy=plan['policy'],path_assignment='-'.join(map(str,plan['assignment'])),jobs=args.jobs,successful_jobs=succ,success_rate=succ/args.jobs,wire_bytes=wire,wire_ratio=wire/max(1,base),mean_censored_ms=elapsed,interventions=sum(x[3] for x in outcomes),objective=objective,optimizer_ms=optimizer_ms,candidate_count=n,rejected_candidates=rejected,trace_key=f'{args.seed}:{scenario}:{loss}:{rep}:{name}')

def images(root,limit):
 for split in ('train','val'):
  folder=root/'BSR'/'BSDS500'/'data'/'images'/split
  if not folder.is_dir():raise FileNotFoundError(f'Missing BSDS500 {split}: {folder}')
  for fp in sorted(folder.glob('*.jpg'))[:limit]:
   with Image.open(fp) as im:rgb=im.convert('RGB').tobytes()
   yield (split,fp.name,hashlib.sha256(fp.read_bytes()).hexdigest(),rgb)

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--data',type=Path,help='BSDS500 data root (containing BSR/BSDS500/data/images)')
 p.add_argument('--out',type=Path,default=Path('Experiment_A_Results'))
 p.add_argument('--self-test',action='store_true')
 p.add_argument('--max-images',type=int,default=1,help='Per train/val split; never reads test')
 p.add_argument('--repeats',type=int,default=2);p.add_argument('--jobs',type=int,default=4)
 p.add_argument('--loss-rates',default='0.01,0.10,0.20');p.add_argument('--seed',type=int,default=3701)
 p.add_argument('--fixed-method',choices=METHODS,default='AESGCM_XOR_Erasure_2of3')
 p.add_argument('--fixed-policy',choices=POLICIES,default='fec_arq')
 p.add_argument('--require-authentication',action='store_true')
 p.add_argument('--w-failure',type=float,default=0.65);p.add_argument('--w-time',type=float,default=0.20);p.add_argument('--w-wire',type=float,default=0.15)
 p.add_argument('--mtu',type=int,default=1000);p.add_argument('--header-bytes',type=int,default=20)
 p.add_argument('--fec-group',type=int,default=4);p.add_argument('--max-retries',type=int,default=3)
 p.add_argument('--failed-path',type=int,default=1);p.add_argument('--burst-persist',type=float,default=.85)
 p.add_argument('--timeout-ms',type=float,default=3000);p.add_argument('--detection-ms',type=float,default=80)
 p.add_argument('--backup-rep-offset',type=int,default=10000000)
 a=p.parse_args();a.path_rates=(20.,10.,15.);a.path_delays=(10.,40.,25.)
 if any(w<0 for w in (a.w_failure,a.w_time,a.w_wire)) or abs(a.w_failure+a.w_time+a.w_wire-1)>1e-8:p.error('Weights must be nonnegative and sum to 1')
 if a.jobs<1 or a.repeats<1 or a.max_images<1:p.error('Invalid experiment size')
 modules=(load('step33','33_expanded_baseline.py'),load('step34','34_multipath_loss_simulator.py'),load('step35','35_packet_recovery.py'))
 if a.self_test:
  data=bytes(range(256))*8
  for arm in ARMS:
   row=evaluate(('train','synthetic','test',data),modules,'iid',0.,0,arm,a)
   assert row['successful_jobs']==a.jobs,(arm,row)
  print('PASS: six-arm functional smoke test; no claims about security or comparative superiority');return
 if not a.data:p.error('--data is required except for --self-test')
 rows=[];losses=[float(x) for x in a.loss_rates.split(',')]
 for im in images(a.data,a.max_images):
  for scenario,loss in [(s,l) for s in ('iid','burst') for l in losses]+[('post_commit_failure',0.)]:
   for rep in range(a.repeats):
    for arm in ARMS:
     row=evaluate(im,modules,scenario,loss,rep,arm,a);rows.append(row)
     print(im[1],scenario,loss,rep,arm,row['success_rate'],flush=True)
 a.out.mkdir(parents=True,exist_ok=True)
 with (a.out/'A_01_runs.csv').open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
 grouped={}
 for r in rows:grouped.setdefault(r['arm'],[]).append(r)
 with (a.out/'A_02_summary.csv').open('w',newline='',encoding='utf8') as f:
  w=csv.writer(f);w.writerow(['arm','batches','jobs','success_rate','mean_wire_ratio','mean_censored_ms','mean_objective','mean_optimizer_ms'])
  for arm,rs in grouped.items():w.writerow([arm,len(rs),sum(r['jobs'] for r in rs),sum(r['successful_jobs'] for r in rs)/sum(r['jobs'] for r in rs),statistics.mean(r['wire_ratio'] for r in rs),statistics.mean(r['mean_censored_ms'] for r in rs),statistics.mean(r['objective'] for r in rs),statistics.mean(r['optimizer_ms'] for r in rs)])
 metadata=dict(scope='development pilot only; no held-out data',arms=ARMS,methods=METHODS,policies=POLICIES,python=sys.version,platform=platform.platform(),seed=a.seed,images_per_split=a.max_images,repeats=a.repeats,jobs_per_batch=a.jobs,loss_rates=losses,weights=dict(failure=a.w_failure,time=a.w_time,wire=a.w_wire),limitations=['Not the full Section 2.3 constrained optimizer','No cumulative fragment-exposure enforcement','No explicit agent processing or memory capacities','Single intervention per job; simplified queue contention','Planning proxy assumes independent fragment delivery','Protection methods generated independently across arms','Ideal feedback and synthetic discrete-event transmission','Do not use this pilot as proof of security or optimizer superiority'])
 (a.out/'A_03_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf8')
 print('Saved',len(rows),'records to',a.out)
if __name__=='__main__':main()
