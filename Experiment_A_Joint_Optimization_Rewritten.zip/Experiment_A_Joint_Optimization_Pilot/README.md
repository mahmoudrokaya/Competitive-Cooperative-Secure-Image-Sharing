# Experiment A — rewritten development benchmark

This package **replaces the earlier pilot** and uses the verified folder layout `Data/BSR/BSDS500/data/images/{train,val,test}`. The program reads only `train` and `val`; it never traverses `test`, `bench`, or `misc`. It generates a SHA-256 image manifest and checks files again when loaded.

## Setup (PowerShell)

```powershell
cd "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Experiment_A_Joint_Optimization_Pilot"
python -m pip install -r requirements.txt
python .\37_joint_optimizer.py --self-test
python .\37_joint_optimizer.py
```

For an explicit run with your locations:

```powershell
python .\37_joint_optimizer.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A" `
  --max-images 2 --repeats 3 --jobs 4
```

**Important:** `--max-images 2` means two images from **each** split (four total), not two total. PowerShell continuation uses the backtick; CMD uses `^`. You may also put the entire command on one line.

## Outputs

- `A_00_image_manifest.csv`: train/validation selections, dimensions, original mode, SHA-256.
- `A_01_runs.csv`: each image × scenario × repetition × J1–J6 batch.
- `A_02_summary.csv`: aggregate descriptive comparison.
- `A_03_metadata.json`: exact settings and limitations.

Default workload: 4 images × (3 iid + 3 burst + 1 path-failure) × 3 repetitions × 6 arms = **504 batch observations** and **2,016 simulated job outcomes**. No held-out images are used.

## Scientific scope and caveats

This is a **development benchmark**, not the fully implemented security-aware organizational optimization from manuscript Section 2.3. It uses real protection/decoding routines from Steps 33–35 and a deterministic simulated transport. The optimization is a bounded candidate enumeration with a decision-time analytical score, **not** a proof of global optimality. It does not enforce cumulative fragment exposure, full ownership transitions, agent processing capacities, or multi-agent assistance. Organizational adaptation is a simplified backup-path retransmission. Default task eligibility permits only authenticated encryption methods; `--allow-unauthenticated` is exploratory and changes the security task definition.

Do not claim security guarantees, operational deployment, statistical superiority, or completion of the full manuscript experiment based on this pilot. Further integration with the Step 36A1 organizational simulator and security-state model is required.
