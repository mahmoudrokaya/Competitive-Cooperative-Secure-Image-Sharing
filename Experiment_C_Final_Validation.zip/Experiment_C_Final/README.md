# Experiment C — final focused validation

This is the **single final focused validation** following the 912-run activation screening. It uses the **unchanged original A3.1 simulator** (verified SHA-256 `67507e212cfd8e2d3677d58b5f7dcdcb03ec24552d847e660337f55f542cf295`) and the original Step33–35 dependencies. No new controller algorithm is introduced.

## Minimal targeted design

Eight predeclared stress conditions, six organizational modes, two scenarios (`burst_0.20`, `path_failure`), and one encrypted XOR-erasure method. Jobs: 4, 8, 16. At 16 jobs, additional capacity=1, failure at 0 or 600 ms (reference 180 ms), and intervention budget 0 or 1 (reference 3). All other parameters are fixed to the earlier A3.1 settings. This is targeted screening/validation, **not a full factorial**. Failure-time variants on burst scenario serve as controls and are redundant with the reference condition; interpret failure-time effects only for path failure.

For 10 validation images and 3 repeats: **8 × 2 × 6 × 10 × 3 = 2,880 simulator executions**. The original A3.1 manifest also reads train entries for image-count verification, but only the selected validation split is simulated. No test/external images.

## Install and run

```powershell
python -m pip install pillow cryptography matplotlib
python -m unittest discover -p "test_cfinal.py" -v
python .\53_experiment_c_final.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_C_Final_Pilot" `
  --split train --images 1 --pilot
```

If the pilot succeeds:

```powershell
python .\53_experiment_c_final.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_C_Final_Validation" `
  --split val --images 10 --repeats 3 --bootstrap 2000 --policy arq
```

`--images 10` is a pragmatic validation sample, not a power analysis. Expand to 30–100 validation images only if the image-cluster confidence intervals are too wide to support the precise claims. Prior validation exposure means this is **not a previously untouched test**.

## Outputs

- `CF_00_audit.json`: source integrity, coverage, interventions, invariants, trace-based in-flight commitments.
- `CF_01_runs.csv`: per-image, per-mode, per-condition raw results.
- `CF_02_summary.csv`: mode/scenario/condition descriptive performance.
- `CF_03_paired_contrasts.csv`: within-image and repetition paired descriptive differences.
- `CF_04_image_bootstrap.csv`: 95% image-cluster bootstrap intervals (repeat averages per image); exploratory, no multiple-testing correction.
- `CF_04_scalability.png`: reliability versus concurrent jobs, burst scenario.
- `CF_06_errors.csv`: emitted only when errors occur.

## Claims and interpretation

- Count assistance/reassignment events; do not infer synergy if full=reassignment.
- Failure-in-flight proxy counts trace commitments on failed path that overlap failure timestamp. **Nonzero count alone does not prove packet loss or successful recovery**; examine failure outcome and intervention records.
- Original A3.1 `full` uses a fixed assistance-first intervention sequence; it does **not** learn the optimal intervention.
- The original simulator uses **simulated** transport and abstract ownership, not deployed networking. Capacity slots are not an independent agent-eligibility model.
- This package does **not** establish formal J1–J6 optimization, confidentiality or Section 2.3 authorization/exposure enforcement. Experiment D must address security claims, and unsupported C4 optimizer claims must be narrowed or tested separately.
