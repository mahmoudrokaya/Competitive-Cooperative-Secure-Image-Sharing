import unittest,importlib.util,pathlib,tempfile
from PIL import Image
P=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('cfinal',P/'53_experiment_c_final.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def test_grid(self):
  self.assertEqual(len(m.grid()),8)
  self.assertEqual(len({x[0] for x in m.grid()}),8)
 def test_trace_overlap(self):
  trace=[dict(event='commit_initial',path=1,job=0,fragment=0,time_ms=10),dict(event='release_initial',path=1,job=0,fragment=0,time_ms=20)]
  self.assertEqual(m.inflight_at_failure(trace,15,1),1)
  self.assertEqual(m.inflight_at_failure(trace,25,1),0)
 def test_contrasts(self):
  rows=[]
  for mode in m.MODES:
   rows.append(dict(condition='jobs_8',scenario='burst_0.20',sha256='abc',repeat=0,mode=mode,success_rate=1,mean_censored_ms=10,wire_ratio=1,assists=0,reassignments=0))
  self.assertEqual(len(m.contrasts(rows)),4)
if __name__=='__main__':unittest.main()
