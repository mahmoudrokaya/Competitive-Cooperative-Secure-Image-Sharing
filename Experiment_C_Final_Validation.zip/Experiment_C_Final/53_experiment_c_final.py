#!/usr/bin/env python3
"""Predeclared focused C validation on original frozen A3.1 (train/val only).
No security proof, no packet-level allocation, no intervention-choice optimization.
"""
import argparse,csv,json,hashlib,importlib.util,statistics,collections,math
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent
MODES=('static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full')
SCENARIOS=('burst_0.20','path_failure')
CONTRASTS=(('bidding_ownership_assist','bidding_ownership'),('bidding_ownership_reassign','bidding_ownership'),('full','bidding_ownership_reassign'),('full','bidding_ownership_assist'))
def load(name):
 spec=importlib.util.spec_from_file_location('cfinal_'+name[:2],HERE/name);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def write(path,rows):
 if not rows:return
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def grid():
 # Eight unique targeted conditions; failure timing only meaningful for path_failure.
 return [('jobs_4',4,4,180.,3),('jobs_8',8,4,180.,3),('jobs_16',16,4,180.,3),
 ('scarce_slots_16',16,1,180.,3),('failure_at_0_16',16,4,0.,3),
 ('failure_at_600_16',16,4,600.,3),('budget_1_16',16,4,180.,1),('budget_0_16',16,4,180.,0)]
def config(args,jobs,capacity,fail,budget):
 return argparse.Namespace(jobs=jobs,capacity=capacity,contention_capacity=2,policy=args.policy,mtu=1000,header_bytes=20,fec_group=4,max_retries=3,
 failed_path=1,failure_at_ms=fail,burst_persist=.85,timeout_ms=3000.,detection_ms=80.,queue_penalty_ms=20.,
 duplicate_path_penalty_ms=10.,max_interventions_per_job=budget,max_events=100000,seed=args.seed,
 path_rates=(20.,10.,15.),path_delays=(10.,40.,25.))
def inflight_at_failure(trace,fail,failed_path):
 # Count commits on the disabled path whose matching release happens after fail.
 # The event trace has no unique request identifier: match by (job,fragment) FIFO.
 outstanding=collections.defaultdict(list)
 n=0
 for e in trace:
  event=e['event'];p=int(e['path']);t=float(e['time_ms'])
  if p!=failed_path:continue
  key=(e['job'],e['fragment'])
  if event.startswith('commit_'):outstanding[key].append(t)
  elif event.startswith('release_') and outstanding[key]:
   start=outstanding[key].pop(0)
   if start < fail <= t:n+=1
 return n
def summarize(rows):
 g=collections.defaultdict(list)
 for r in rows:g[(r['condition'],r['scenario'],r['mode'])].append(r)
 out=[]
 for (condition,scenario,mode),rr in sorted(g.items()):
  jobs=sum(int(x['jobs']) for x in rr)
  out.append(dict(condition=condition,scenario=scenario,mode=mode,runs=len(rr),jobs=jobs,
   success_rate=sum(int(x['successes']) for x in rr)/jobs,
   mean_censored_ms=statistics.mean(float(x['mean_censored_ms']) for x in rr),
   wire_ratio=statistics.mean(float(x['wire_ratio']) for x in rr),
   transmitted_bytes_mean=statistics.mean(float(x['transmitted_bytes']) for x in rr),
   assists=sum(int(x['assists']) for x in rr),reassignments=sum(int(x['reassignments']) for x in rr),
   assists_per_job=sum(int(x['assists']) for x in rr)/jobs,
   reassignments_per_job=sum(int(x['reassignments']) for x in rr)/jobs,
   inflight_failure_commitments=sum(int(x['inflight_failure_commitments']) for x in rr),
   capacity_violations=sum(int(x['capacity_violations']) for x in rr),
   ownership_conflicts=sum(int(x['ownership_conflicts']) for x in rr),
   reservation_leaks=sum(int(x['reservation_leaks']) for x in rr)))
 return out
def contrasts(rows):
 g=collections.defaultdict(dict)
 for r in rows:g[(r['condition'],r['scenario'],r['sha256'],r['repeat'])][r['mode']]=r
 out=[]
 for (cond,sc,sha,rep),m in sorted(g.items()):
  for a,b in CONTRASTS:
   if a not in m or b not in m:continue
   x,y=m[a],m[b]
   out.append(dict(condition=cond,scenario=sc,sha256=sha,repeat=rep,contrast=a+' minus '+b,
    delta_success_pp=100*(float(x['success_rate'])-float(y['success_rate'])),
    delta_censored_ms=float(x['mean_censored_ms'])-float(y['mean_censored_ms']),
    delta_wire_ratio=float(x['wire_ratio'])-float(y['wire_ratio']),
    delta_assists=int(x['assists'])-int(y['assists']),delta_reassignments=int(x['reassignments'])-int(y['reassignments'])))
 return out
def bootstrap(contrast_rows,B,seed):
 import random
 g=collections.defaultdict(lambda:collections.defaultdict(list))
 for r in contrast_rows:g[(r['condition'],r['scenario'],r['contrast'])][r['sha256']].append(r)
 rng=random.Random(seed);out=[]
 for (cond,sc,contrast),by_image in sorted(g.items()):
  ids=sorted(by_image);n=len(ids)
  for metric in ('delta_success_pp','delta_censored_ms','delta_wire_ratio'):
   vals=[statistics.mean(float(x[metric]) for x in by_image[k]) for k in ids]
   observed=statistics.mean(vals)
   if n<2:lo=hi=float('nan')
   else:
    sims=sorted(statistics.mean(vals[rng.randrange(n)] for _ in range(n)) for _ in range(B))
    lo=sims[int(.025*(B-1))];hi=sims[int(.975*(B-1))]
   out.append(dict(condition=cond,scenario=sc,contrast=contrast,metric=metric,independent_images=n,
    mean_delta=observed,ci95_lower=lo,ci95_upper=hi,bootstrap_draws=B,
    inference='exploratory image-cluster bootstrap; no multiplicity-adjusted significance'))
 return out
def plot(summary,out):
 try:
  import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
 except ImportError:return 'not_generated_matplotlib_missing'
 s=[r for r in summary if r['scenario']=='burst_0.20' and r['condition'] in ('jobs_4','jobs_8','jobs_16')]
 fig,ax=plt.subplots(figsize=(10,5.8))
 for mode in MODES:
  rr=sorted((r for r in s if r['mode']==mode),key=lambda r:int(r['condition'].split('_')[1]))
  ax.plot([int(r['condition'].split('_')[1]) for r in rr],[100*r['success_rate'] for r in rr],marker='o',label=mode)
 ax.set(xlabel='Concurrent jobs',ylabel='Reconstruction success (%)',title='Focused validation: burst 20% (A3.1 simulation)')
 ax.set_xticks([4,8,16]);ax.set_ylim(0,105);ax.grid(alpha=.25);ax.legend(fontsize=7);fig.tight_layout()
 fig.savefig(out/'CF_04_scalability.png',dpi=180);plt.close(fig)
 return 'CF_04_scalability.png'
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
 p.add_argument('--split',choices=('train','val'),default='val');p.add_argument('--images',type=int,default=10)
 p.add_argument('--repeats',type=int,default=3);p.add_argument('--seed',type=int,default=5301)
 p.add_argument('--policy',choices=('arq','fec_arq'),default='arq')
 p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--pilot',action='store_true')
 args=p.parse_args()
 if min(args.images,args.repeats,args.bootstrap)<1:p.error('images, repeats and bootstrap must be positive')
 a31=load('40_A3_1_capacity_aware.py');s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py')
 entries=[e for e in a31.manifest(args.data,args.images) if e['split']==args.split]
 conditions=grid()[:2] if args.pilot else grid()
 if args.pilot:args.repeats=1;entries=entries[:1]
 args.out.mkdir(parents=True,exist_ok=True)
 rows=[];errors=[];expected=0
 for cond,jobs,cap,fail,budget in conditions:
  for entry in entries:
   with Image.open(args.data/entry['relative_path']) as im:rgb=im.convert('RGB').tobytes()
   for sc in SCENARIOS:
    for rep in range(args.repeats):
     for mode in MODES:
      expected+=1;cfg=config(args,jobs,cap,fail,budget);trace=[]
      try:
       r=a31.execute(entry,rgb,'AESGCM_XOR_Erasure_2of3',mode,sc,rep,cfg,s33,s34,s35,trace)
       n=inflight_at_failure(trace,fail,cfg.failed_path) if sc=='path_failure' else 0
       r.update(condition=cond,policy=args.policy,capacity=cap,failure_at_ms=fail,
        max_interventions_per_job=budget,transmitted_bytes=r['wire_ratio']*len(rgb)*jobs,
        inflight_failure_commitments=n)
       rows.append(r)
      except Exception as e:errors.append(dict(condition=cond,scenario=sc,sha256=entry['sha256'],repeat=rep,mode=mode,error=repr(e)))
  print(cond,'complete',flush=True)
 summ=summarize(rows);paired=contrasts(rows);ci=bootstrap(paired,args.bootstrap,args.seed)
 write(args.out/'CF_01_runs.csv',rows);write(args.out/'CF_02_summary.csv',summ)
 write(args.out/'CF_03_paired_contrasts.csv',paired);write(args.out/'CF_04_image_bootstrap.csv',ci)
 write(args.out/'CF_06_errors.csv',errors)
 fig=plot(summ,args.out)
 audit=dict(stage='Final focused Experiment C validation',source_sha256=a31.digest(HERE/'40_A3_1_capacity_aware.py'),
 split=args.split,images=len(entries),repeats=args.repeats,conditions=len(conditions),scenarios=list(SCENARIOS),modes=len(MODES),
 expected_runs=expected,completed_runs=len(rows),errors=len(errors),
 capacity_violations=sum(int(r['capacity_violations']) for r in rows),ownership_conflicts=sum(int(r['ownership_conflicts']) for r in rows),
 reservation_leaks=sum(int(r['reservation_leaks']) for r in rows),
 assists=sum(int(r['assists']) for r in rows),reassignments=sum(int(r['reassignments']) for r in rows),
 path_failure_runs_with_inflight_commitments=sum(r['scenario']=='path_failure' and r['inflight_failure_commitments']>0 for r in rows),
 figure=fig,bootstrap_unit='unique image sha256, repetitions averaged within image',
 limitations=['Predeclared focused stress grid; not full factorial','Previously explored data/simulator; validation is not untouched independent test',
 'A3.1 uses fragment-level assignment and abstract organization, not real network','Full mode uses fixed intervention order, not learned selection',
 'Loss traces are not strictly common across policies','No direct agent eligibility or separate assistance pool',
 'In-flight commitment count is a trace-based proxy, not proof of dropped packets',
 'Image-cluster bootstrap exploratory; no multiplicity adjustment','Security and Section 2.3 constraints require Experiment D'])
 (args.out/'CF_00_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
 print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
