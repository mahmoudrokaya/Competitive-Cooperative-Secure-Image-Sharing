# Stage C1 — Cross-Dataset Statistical Validation

This package contains reproducible image-clustered paired inference for the frozen Experiment B1 and B2 results.

## Usage

Install `numpy pandas scipy`, put `B1_00_manifest.csv`, `B1_01_runs.csv`, `B1_03_metadata.json`, `B2_00_manifest.csv`, `B2_01_runs.csv`, `B2_03_metadata.json` in one input directory, then run:

```powershell
python .\43_C1_statistical_validation.py --input "D:\path\to\uploaded_B_files" --out "D:\path\to\C1_results" --bootstrap 3000 --seed 4301
```

## Files

- `C1_00_descriptive.csv`: aggregate observed rates, wire ratios, censored completion times and queues.
- `C1_01_paired_inference.csv`: eight prespecified paired mode contrasts, three outcomes, separate datasets and methods; image-level bootstrap confidence intervals, t-test p-values, Holm correction.
- `C1_02_quality_checks.csv`: completeness, resource accounting, file SHA-256 and blocked interventions.
- `C1_03_cross_dataset_effects.csv`: exploratory unpaired difference of within-dataset effects, bootstrapping image clusters independently in each dataset.
- `C1_04_methodology.json`: assumptions and inference choices.

## Statistical unit and interpretation

The independent sampling unit is an image. Within each image, seven scenarios and three repetitions are averaged; each batch contains four jobs. A paired contrast compares exactly matching image/scenario/repetition/method records. Percentile 95% confidence intervals use 3,000 resamples of images. Two-sided one-sample image-level t-tests are Holm-adjusted within each dataset × protection method × metric across eight planned comparisons. Differences are mode A minus mode B. Reliability differences are proportions (multiply by 100 for percentage points). Cross-dataset effects are unpaired and descriptive because images differ.

**Limitations:** simulation, not physical networking; censored latency includes unsuccessful jobs; 7 network scenarios are equally weighted, not population prevalence; external images vary substantially in resolution and color mode; p-values for images treated as independent are conditional on the fixed simulation configurations; ownership is not an independently demonstrated distributed protocol; C1 does not validate the complete J1–J6 optimizer.
