# Stage C3.1 — Full development-set optimization and statistical validation

**Status:** Reproducible scripts ready; full-data results must be run on the user's Windows computer. The four A3.1 simulator dependencies are not bundled here and must be copied from the original experimental Code folder. No full-data improvement is claimed before running the scripts.

## Required simulator files (same directory as 45_C3_joint_optimizer_integration.py)

- `40_A3_1_capacity_aware.py`
- `33_expanded_baseline.py`
- `34_multipath_loss_simulator.py`
- `35_packet_recovery.py`

These must be the **same frozen versions** used in the earlier experiments. Do not replace them with rewritten stand-ins.

## Run in Windows PowerShell

```powershell
cd "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Stage_C3_1_Full_Development"
python -m pip install -r .\requirements.txt

python .\45_C3_joint_optimizer_integration.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C3_1_Full" `
  --train-images 0 --val-images 0 --repeats 3 --jobs 4 `
  --seed 4501

python .\46_C3_1_statistical_validation.py `
  --input "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C3_1_Full" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C3_1_Stats" `
  --bootstrap 3000 --permutations 10000 --seed 4601
```

This default run uses 3 scenarios × 16 candidates × 3 repeats × 300 images = **43,200 batches**. The first script holds all validation candidates for audit, but uses train results only for selection. It writes C3_00 through C3_06. The second script validates the complete factorial grid, verifies training-only selection, checks resource-integrity invariants, computes paired per-image reliability, wire ratio and timeout-censored time differences, 95% image-bootstrap CIs, sign-flip p-values and Holm correction. It writes C31_00 through C31_04.

For all seven network scenarios, add `--scenarios iid_0.01 iid_0.10 iid_0.20 burst_0.10 burst_0.20 path_failure contention` to the first command; this increases the workload to **100,800 batches**.

## Statistical and scientific caveats

- Images (not batches/jobs) are the sampling units. Repeats are averaged within images.
- This is a *finite-grid* selector, not HHO or J1–J6; simulated queueing and abstract organizational ownership remain.
- The BSDS500 `test` and external `misc` directories are never read by the C3 script.
- The image split is based on supplied dataset folder labels and manifest hashes; independent dataset provenance is not established by these scripts.
- Candidate comparisons across different recovery policies are not guaranteed to share identical random packet-loss traces.
- 100-image validation provides development evidence, not an untouched final test. Do not tune weights/constraints after reviewing validation if you want to retain an unbiased validation interpretation.
- The simulation runs can take considerable time; the C3 driver writes CSVs only after all simulations, so plan accordingly.
