# Experiment A — Constrained Joint Optimization (research simulator)

## Status
This package implements a **constrained, event-triggered research simulator** extending the J1–J6 pilot. It is **not a verified implementation of every detail of Sections 2.2–2.3**, not a globally optimal solver, and not a physical-network or cryptographic-security proof.

## Dataset
Only `Data/BSR/BSDS500/data/images/train` and `val` are loaded. Default: two images from each. The test/bench/misc folders are not accessed. Manifest includes file SHA-256 and source color mode. Images are converted to RGB for byte-exact reconstruction.

## Installation and execution (Windows PowerShell)
Extract this folder under:
`D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code`

```powershell
cd "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Experiment_A_Full_Constrained"
python -m pip install -r requirements.txt
python .\38_full_constrained_optimizer.py --self-test
python .\38_full_constrained_optimizer.py
```

Optional explicit command:
```powershell
python .\38_full_constrained_optimizer.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A_Full" `
  --max-images 2 --repeats 3 --jobs 4 --min-reliability 0.90
```

## Files produced
- `A_full_00_manifest.csv`: source images, partitions, SHA-256, original modes.
- `A_full_01_runs.csv`: batch outcomes and feasibility/intervention counters.
- `A_full_02_summary.csv`: descriptive averages for J1–J6.
- `A_full_03_metadata.json`: settings, environment, and model assumptions.

## Model and interpretation
- J1: static protection/recovery/assignment; J2: recovery only; J3: assignment only; J4: protection only; J5: recovery+assignment; J6: all three.
- Default methods are AES-GCM PSK and AES-GCM+XOR erasure (2,3); unauthenticated XOR and Shamir can be enabled *only for exploratory comparisons* with `--allow-unauthenticated`. The latter methods are not authenticated encryption.
- Default attacker compromise sets are each individual path (`0;1;2`). For unencrypted threshold schemes, cumulative exposures are tracked across interventions. Encrypted erasure fragments do **not** become secret shares; confidentiality relies on the AES-GCM key assumption.
- Minimum reliability is a **predicted** constraint based on a simplified packet model; it does not guarantee empirical reliability, especially under correlated burst loss and post-commit failure.
- Concurrent path and agent capacities count committed fragments. Agent id is identified with path id. There is no explicit agent CPU scheduling, queue service, or communication negotiation protocol.
- Assistance and reassignment are distinct state actions; assistance uses spare paths without changing ownership, reassignment changes the active fragment path. The simulation does not implement a full multi-agent ownership-transfer protocol.
- Paths are simulated, not actual sockets. Recovery policies are selected before the job and not changed after observation. Failure interventions are triggered by observed fragment failures, not by advance knowledge of losses.
- Planning enumerates a bounded small candidate space and does not prove global optimality.
- Randomness is deterministic for transport traces, but cryptographic protection generates fresh randomness per arm; this affects strict paired cryptographic comparisons.
- Objective is a selected weighted combination of empirical failure, censored completion time and communication ratio. It does not separately price processing cost or organizational interventions. The weights are research assumptions, not fitted coefficients.
- Some baseline arms may become infeasible under the common constraints; infeasibility is explicitly recorded and must not be silently dropped from comparisons.
- `bids` counts evaluated placement candidates, not actual negotiated agent messages. Security/capacity rejection counters count **candidate rejections**, not violations.
- `ownership_violations`, `exposure_violations`, and `capacity_violations` are audit counters, but **zero alone is not evidence that all possible violations were tested**. Add targeted adversarial and state-transition tests before publication.

## Verification performed before delivery
1. `--self-test` passed (six arms, loss-free reconstruction, exposure guard, ownership conflict/release).
2. End-to-end smoke experiment passed using a synthetic two-image dataset: 36 batch rows, all four output files generated.
3. Full real-dataset experiment has **not** been executed here because the local Windows dataset is unavailable in this environment.

## Next validation gates before publication
1. Inspect the real-data results and compare J1–J6 under common feasible constraints.
2. Implement/verify detailed agent queues, explicit bids/acceptance, bounded assistance, authorization and atomic ownership transfer.
3. Add true event-time reoptimization of recovery policies and an explicit adversarial compromise test suite.
4. Independently verify empirical reconstruction reliability against forecast and expand to held-out images only after freezing parameters.
