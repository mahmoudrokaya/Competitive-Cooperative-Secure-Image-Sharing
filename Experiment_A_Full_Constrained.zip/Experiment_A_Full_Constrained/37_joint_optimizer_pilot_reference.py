#!/usr/bin/env python3
"""Experiment A development benchmark: reproducible six-arm bounded joint search.

This is an explicitly limited implementation of Section 2.3: simulated
transport, approximate decision-time predictions, no real agent security state.
Do not interpret it as a verified end-to-end secure organizational optimizer.
"""
from __future__ import annotations
import argparse, csv, hashlib, importlib.util, itertools, json, math, platform, statistics, sys, time
from pathlib import Path
from PIL import Image

HERE=Path(__file__).resolve().parent
ARMS={
 'J1_static':(0,0,0),'J2_recovery':(0,1,0),
 'J3_organization':(0,0,1),'J4_protection':(1,0,0),
 'J5_recovery_organization':(0,1,1),'J6_joint':(1,1,1),
}
METHODS=('XOR_2of2','Shamir_GF256_2of3','AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')
AUTH_METHODS=('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')
POLICIES=('none','fec','arq','fec_arq')
FIELDS=['split','image','sha256','width','height','scenario','loss_rate','repeat','arm','method','policy','assignment','jobs','successful_jobs','success_rate','wire_bytes','wire_ratio','mean_censored_ms','interventions','objective','optimizer_ms','candidate_count','rejected_candidates','trace_key']

def load(name):
    filename={'s33':'33_expanded_baseline.py','s34':'34_multipath_loss_simulator.py','s35':'35_packet_recovery.py'}[name]
    spec=importlib.util.spec_from_file_location(name,str(HERE/filename));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def sha_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def manifest(root,per_split):
    base=root/'BSR'/'BSDS500'/'data'/'images'
    if not base.is_dir():raise FileNotFoundError(f'Expected BSDS500 directory not found: {base}')
    result=[];seen=set()
    for split in ('train','val'):
        folder=base/split
        if not folder.is_dir():raise FileNotFoundError(f'Missing partition: {folder}')
        files=sorted((p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ('.jpg','.jpeg','.png')),key=lambda p:p.name)
        if len(files)<per_split:raise ValueError(f'{split} contains only {len(files)} images; requested {per_split}')
        for p in files[:per_split]:
            digest=sha_file(p)
            if digest in seen:raise ValueError(f'Duplicate selected image SHA-256: {p}')
            seen.add(digest)
            with Image.open(p) as im:
                im.verify()
            with Image.open(p) as im:w,h=im.size;mode=im.mode
            result.append(dict(split=split,image=p.name,relative_path=p.relative_to(root).as_posix(),sha256=digest,width=w,height=h,original_mode=mode))
    return result

def image_data(root,entry):
    p=root/entry['relative_path']
    if sha_file(p)!=entry['sha256']:raise ValueError(f'Image changed since manifest creation: {p}')
    with Image.open(p) as im:return im.convert('RGB').tobytes()

def paths(n,adaptive,args):
    if not adaptive:return [tuple(i%len(args.path_rates) for i in range(n))]
    candidates=itertools.product(range(len(args.path_rates)),repeat=n)
    return [p for p in candidates if len(set(p))==n and all(p.count(i)<=args.max_fragments_per_path for i in range(len(args.path_rates)))]

def packet_success(blob_size,loss,policy,args):
    n=max(1,math.ceil(blob_size/args.mtu))
    q=loss**(args.max_retries+1) if policy in ('arq','fec_arq') else loss
    if policy in ('fec','fec_arq'):
        k=args.fec_group
        success=(1-q)**k+k*q*(1-q)**(k-1)
        return min(1.,max(0.,success**math.ceil(n/k)))
    return (1-q)**n

def forecast(shares,k,policy,assignment,loss,args):
    probabilities=[];wire=0.;delay=0.
    for (_,blob),path in zip(shares,assignment):
        probabilities.append(packet_success(len(blob),loss,policy,args))
        packets=max(1,math.ceil(len(blob)/args.mtu))
        factor=1+(1/args.fec_group if policy in ('fec','fec_arq') else 0)
        if policy in ('arq','fec_arq'):factor+=sum(loss**j for j in range(1,args.max_retries+1))
        bytes_est=(len(blob)+packets*args.header_bytes)*factor
        wire+=bytes_est
        delay=max(delay,args.path_delays[path]+bytes_est*8/(args.path_rates[path]*1000))
    distribution=[1.]
    for p in probabilities:
        nxt=[0.]*(len(distribution)+1)
        for i,v in enumerate(distribution):nxt[i]+=v*(1-p);nxt[i+1]+=v*p
        distribution=nxt
    reliability=sum(distribution[k:]);reference=sum(len(x) for _,x in shares)
    score=args.w_failure*(1-reliability)+args.w_time*delay/args.timeout_ms+args.w_wire*wire/max(1,reference)
    return score

def choose(rgb,modules,arm,loss,args):
    s33,s34,_=modules
    protect,recover,organize=ARMS[arm]
    methods=METHODS if protect else (args.fixed_method,)
    policies=POLICIES if recover else (args.fixed_policy,)
    best=None;checked=0;rejected=0
    for method in methods:
        if args.require_authentication and method not in AUTH_METHODS:
            rejected+=len(policies);continue
        shares,decoder,target,k=s34.make_shares(s33,method,rgb,b'')
        for policy in policies:
            for assignment in paths(len(shares),organize,args):
                if len(set(assignment))<len(assignment):rejected+=1;continue
                checked+=1
                score=forecast(shares,k,policy,assignment,loss,args)
                key=(score,method,policy,assignment)
                if best is None or key<best[0]:best=(key,dict(method=method,policy=policy,assignment=assignment,shares=shares,decoder=decoder,target=target,k=k))
    if best is None:raise RuntimeError(f'No feasible candidate for {arm}; check fixed method, authentication and assignment restrictions')
    return best[1],checked,rejected

def execute(plan,scenario,loss,rep,jid,args,s35):
    received={};arrival=[];wire=0;failures=[];interventions=0
    # Each arm uses identical deterministic transport trace keys per job and scenario.
    for (sid,blob),path in zip(plan['shares'],plan['assignment']):
        if scenario=='post_commit_failure' and path==args.failed_path:
            failures.append((sid,blob,path));continue
        kind='burst' if scenario=='burst' else 'iid'
        got,w,_,_,_,_,ms=s35.transport(blob,path,plan['policy'],kind,loss,rep+jid*100000,args)
        wire+=w
        if got is None:failures.append((sid,blob,path))
        else:received[sid]=got;arrival.append(ms)
    if plan['organization'] and len(received)<plan['k']:
        for sid,blob,old in failures:
            if len(received)>=plan['k']:break
            eligible=[p for p in range(len(args.path_rates)) if p!=old and (scenario!='post_commit_failure' or p!=args.failed_path)]
            if not eligible:continue
            path=min(eligible,key=lambda p:(args.path_delays[p]+len(blob)*8/(args.path_rates[p]*1000),p))
            kind='burst' if scenario=='burst' else 'iid'
            got,w,_,_,_,_,ms=s35.transport(blob,path,plan['policy'],kind,loss,rep+jid*100000+args.backup_rep_offset,args)
            wire+=w;interventions+=1
            if got is not None:received[sid]=got;arrival.append(args.detection_ms+ms)
    ok=len(received)>=plan['k']
    if ok:
        try:ok=plan['decoder'](received)==plan['target']
        except Exception:ok=False
    elapsed=max(sorted(arrival)[:plan['k']]) if ok else args.timeout_ms
    return int(ok),wire,elapsed,interventions

def run_one(entry,rgb,modules,scenario,loss,rep,arm,args):
    t=time.perf_counter();plan,n,rejected=choose(rgb,modules,arm,loss,args);opt_ms=(time.perf_counter()-t)*1000
    plan['organization']=bool(ARMS[arm][2]);results=[execute(plan,scenario,loss,rep,j,args,modules[2]) for j in range(args.jobs)]
    success=sum(r[0] for r in results);wire=sum(r[1] for r in results);delay=statistics.mean(r[2] for r in results)
    ratio=wire/max(1,len(rgb)*args.jobs)
    objective=args.w_failure*(1-success/args.jobs)+args.w_time*delay/args.timeout_ms+args.w_wire*ratio
    return dict(split=entry['split'],image=entry['image'],sha256=entry['sha256'],width=entry['width'],height=entry['height'],scenario=scenario,loss_rate=loss,repeat=rep,arm=arm,method=plan['method'],policy=plan['policy'],assignment='-'.join(map(str,plan['assignment'])),jobs=args.jobs,successful_jobs=success,success_rate=success/args.jobs,wire_bytes=wire,wire_ratio=ratio,mean_censored_ms=delay,interventions=sum(r[3] for r in results),objective=objective,optimizer_ms=opt_ms,candidate_count=n,rejected_candidates=rejected,trace_key=f'{args.seed}|{entry["sha256"]}|{scenario}|{loss}|{rep}')

def write_csv(path,rows,fields):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data'))
    p.add_argument('--out',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A'))
    p.add_argument('--self-test',action='store_true');p.add_argument('--max-images',type=int,default=2,help='Images PER split: 2 train + 2 val by default')
    p.add_argument('--repeats',type=int,default=3);p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--loss-rates',default='0.01,0.10,0.20');p.add_argument('--seed',type=int,default=3701)
    p.add_argument('--fixed-method',choices=METHODS,default='AESGCM_XOR_Erasure_2of3');p.add_argument('--fixed-policy',choices=POLICIES,default='fec_arq')
    p.add_argument('--allow-unauthenticated',action='store_true',help='Exploratory only: include XOR and Shamir, which do not provide authenticated confidentiality')
    p.add_argument('--w-failure',type=float,default=.65);p.add_argument('--w-time',type=float,default=.20);p.add_argument('--w-wire',type=float,default=.15)
    p.add_argument('--mtu',type=int,default=1000);p.add_argument('--header-bytes',type=int,default=20)
    p.add_argument('--fec-group',type=int,default=4);p.add_argument('--max-retries',type=int,default=3)
    p.add_argument('--failed-path',type=int,default=1);p.add_argument('--burst-persist',type=float,default=.85)
    p.add_argument('--timeout-ms',type=float,default=3000);p.add_argument('--detection-ms',type=float,default=80)
    p.add_argument('--max-fragments-per-path',type=int,default=1);p.add_argument('--backup-rep-offset',type=int,default=10000000)
    a=p.parse_args(argv);a.path_rates=(20.,10.,15.);a.path_delays=(10.,40.,25.);a.require_authentication=not a.allow_unauthenticated
    if a.max_images<1 or a.repeats<1 or a.jobs<1 or a.mtu<1 or a.fec_group<1 or a.max_retries<0 or a.max_fragments_per_path<1:p.error('Invalid integer parameter')
    if a.fixed_method not in AUTH_METHODS and a.require_authentication:p.error('Fixed method violates authenticated confidentiality requirement')
    weights=(a.w_failure,a.w_time,a.w_wire)
    if any(x<0 for x in weights) or not math.isclose(sum(weights),1.,abs_tol=1e-9):p.error('Weights must be nonnegative and sum to 1')
    try:losses=[float(x.strip()) for x in a.loss_rates.split(',')];assert losses and all(0<=x<1 for x in losses)
    except (ValueError,AssertionError):p.error('Loss rates must be comma-separated fractions in [0,1)')
    modules=tuple(load(name) for name in ('s33','s34','s35'))
    if a.self_test:
        modules[0].selftest()
        synthetic=bytes(range(256))*4;entry=dict(split='synthetic',image='selftest',sha256='synthetic',width=32,height=32)
        for arm in ARMS:
            row=run_one(entry,synthetic,modules,'iid',0.,0,arm,a)
            if row['successful_jobs']!=a.jobs:raise AssertionError((arm,row))
        print('PASS: all six arms reconstruct loss-free synthetic payloads');return
    selected=manifest(a.data,a.max_images)
    a.out.mkdir(parents=True,exist_ok=True)
    write_csv(a.out/'A_00_image_manifest.csv',selected,list(selected[0]))
    rows=[]
    for entry in selected:
        rgb=image_data(a.data,entry)
        for scenario,loss in [(s,l) for s in ('iid','burst') for l in losses]+[('post_commit_failure',0.)]:
            for rep in range(a.repeats):
                for arm in ARMS:
                    row=run_one(entry,rgb,modules,scenario,loss,rep,arm,a);rows.append(row)
                    print(f'{entry["split"]}/{entry["image"]} {scenario} {loss} rep={rep} {arm}: {row["success_rate"]:.3f}',flush=True)
    write_csv(a.out/'A_01_runs.csv',rows,FIELDS)
    summaries=[]
    for arm in ARMS:
        r=[x for x in rows if x['arm']==arm]
        summaries.append(dict(arm=arm,batches=len(r),jobs=sum(x['jobs'] for x in r),success_rate=sum(x['successful_jobs'] for x in r)/sum(x['jobs'] for x in r),mean_wire_ratio=statistics.mean(x['wire_ratio'] for x in r),mean_censored_ms=statistics.mean(x['mean_censored_ms'] for x in r),mean_objective=statistics.mean(x['objective'] for x in r),mean_optimizer_ms=statistics.mean(x['optimizer_ms'] for x in r)))
    write_csv(a.out/'A_02_summary.csv',summaries,list(summaries[0]))
    metadata=dict(status='development benchmark; not the complete Section 2.3 security-constrained optimizer',data_root=str(a.data),output=str(a.out),manifest_sha256=sha_file(a.out/'A_00_image_manifest.csv'),python=sys.version,platform=platform.platform(),pillow=Image.__version__,arms=ARMS,methods=METHODS,policies=POLICIES,seed=a.seed,repeats=a.repeats,jobs=a.jobs,loss_rates=losses,weights=dict(failure=a.w_failure,time=a.w_time,wire=a.w_wire),require_authentication=a.require_authentication,selected_images=len(selected),path_rates_mbps=a.path_rates,path_delays_ms=a.path_delays,limitations=['No cumulative fragment-exposure model','No actual agent ownership, bidding, queue, or processing-capacity simulation','No integrated assistance versus reassignment state machine','No adaptive reoptimization following observations; recovery is preselected','Predictor approximates independent fragment delivery even under burst loss','Fixed-policy and adaptive-policy methods may use independent cryptographic randomness','Simulated transport with idealized control feedback; not physical-network measurements','Optimizer wall time is Python planning overhead and not a network latency component','No test or external images are loaded'])
    (a.out/'A_03_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print(f'Completed {len(rows)} rows; output: {a.out}')

if __name__=='__main__':main()
