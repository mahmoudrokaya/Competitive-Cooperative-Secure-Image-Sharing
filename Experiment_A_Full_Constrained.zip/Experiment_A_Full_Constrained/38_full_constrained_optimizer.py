#!/usr/bin/env python3
"""Experiment A: security- and resource-constrained, event-driven multipath simulator.

This is an executable *operationalization* of Section 2.3, not a proof of global
optimality or real-world confidentiality. See README for assumptions/limits.
"""
from __future__ import annotations
import argparse, csv, hashlib, importlib.util, itertools, json, math, platform, statistics, sys, time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from PIL import Image

HERE=Path(__file__).resolve().parent
ARMS={'J1_static':(0,0,0),'J2_recovery':(0,1,0),'J3_organization':(0,0,1),
      'J4_protection':(1,0,0),'J5_recovery_organization':(0,1,1),'J6_joint':(1,1,1)}
METHODS=('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3','Shamir_GF256_2of3','XOR_2of2')
POLICIES=('none','fec','arq','fec_arq')
FIELDS=['split','image','sha256','scenario','loss_rate','repeat','arm','jobs','successful_jobs','success_rate',
        'wire_bytes','wire_ratio','mean_censored_ms','mean_objective','mean_planning_ms','methods','policies',
        'assignments','bids','commitments','assistance','reassignments','conflicts_prevented',
        'capacity_rejections','security_rejections','reliability_rejections','ownership_violations',
        'exposure_violations','capacity_violations','authentication_failures','infeasible_jobs','trace_key']

def load(file,alias):
    spec=importlib.util.spec_from_file_location(alias,HERE/file); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def manifest(root,n):
    base=root/'BSR'/'BSDS500'/'data'/'images'; out=[];seen=set()
    for split in ('train','val'):
        folder=base/split
        if not folder.is_dir():raise FileNotFoundError(folder)
        files=sorted((p for p in folder.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png')),key=lambda p:p.name)
        if len(files)<n:raise ValueError(f'Insufficient images in {folder}')
        for p in files[:n]:
            digest=sha(p)
            if digest in seen:raise ValueError('Duplicate selected image')
            seen.add(digest)
            with Image.open(p) as im:
                w,h=im.size;mode=im.mode;im.verify()
            out.append(dict(split=split,image=p.name,relative_path=p.relative_to(root).as_posix(),sha256=digest,width=w,height=h,original_mode=mode))
    return out

def stable(*parts):return int.from_bytes(hashlib.sha256('|'.join(map(str,parts)).encode()).digest()[:8],'big')

def reliability(fragment_probs,k):
    d=[1.]
    for p in fragment_probs:
        nd=[0.]*(len(d)+1)
        for i,x in enumerate(d):nd[i]+=x*(1-p);nd[i+1]+=x*p
        d=nd
    return sum(d[k:])

def packet_probability(length,loss,policy,a):
    n=max(1,math.ceil(length/a.mtu)); q=loss**(a.max_retries+1) if 'arq' in policy else loss
    if 'fec' in policy:
        k=a.fec_group; per=(1-q)**k+k*q*(1-q)**(k-1)
        return max(0.,min(1.,per**math.ceil(n/k)))
    return (1-q)**n

@dataclass
class State:
    # Exposure is cumulative over a task, not reset on reassignment.
    exposed:dict=field(default_factory=lambda:defaultdict(lambda:defaultdict(set)))
    owners:dict=field(default_factory=dict)
    committed:dict=field(default_factory=dict)
    path_load:dict=field(default_factory=lambda:defaultdict(int))
    agent_load:dict=field(default_factory=lambda:defaultdict(int))
    bids:int=0;commitments:int=0;assistance:int=0;reassignments:int=0
    conflicts_prevented:int=0;capacity_rejections:int=0;security_rejections:int=0
    reliability_rejections:int=0;ownership_violations:int=0;exposure_violations:int=0
    capacity_violations:int=0;authentication_failures:int=0;infeasible_jobs:int=0

@dataclass
class Plan:
    method:str;policy:str;assignment:tuple;shares:list;decoder:object;target:bytes;k:int
    predicted_reliability:float;predicted_time:float;predicted_wire:float;score:float


def secure_ok(method,job,shares,assignment,state,a):
    # Explicit adversary model: each adversary compromises a listed set of paths.
    # For unencrypted threshold methods, every compromised set must observe < k shares,
    # counting ALL previous placements for the same job.
    if method in ('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3'):return True
    k=2
    for compromised in a.compromised_sets:
        seen={sid for sid,paths in state.exposed[job].items() if paths.intersection(compromised)}
        seen.update(sid for (sid,_),p in zip(shares,assignment) if p in compromised)
        if len(seen)>=k:return False
    return True

def candidate_score(shares,k,assignment,policy,loss,a):
    ps=[];wire=0.;latency=0.
    for (_,blob),p in zip(shares,assignment):
        ps.append(packet_probability(len(blob),loss,policy,a))
        n=max(1,math.ceil(len(blob)/a.mtu));factor=1+(1/a.fec_group if 'fec' in policy else 0)
        if 'arq' in policy:factor+=sum(loss**j for j in range(1,a.max_retries+1))
        wb=(len(blob)+n*a.header_bytes)*factor;wire+=wb
        latency=max(latency,a.path_delays[p]+wb*8/(a.path_rates[p]*1000))
    r=reliability(ps,k)
    score=a.w_failure*(1-r)+a.w_time*latency/a.timeout_ms+a.w_wire*wire/max(1,a.original_bytes)
    return score,r,latency,wire

def choices(n,adaptive,a):
    if not adaptive:return [tuple(i%len(a.path_rates) for i in range(n))]
    return list(itertools.product(range(len(a.path_rates)),repeat=n))

def feasible_assignment(job,method,shares,assignment,state,a,incremental=False):
    if any(p not in a.allowed_paths for p in assignment):return False,'eligibility'
    if any(state.path_load[p]+sum(q==p for q in assignment)>a.path_capacity[p] for p in set(assignment)):
        return False,'capacity'
    if any(state.agent_load[p]+sum(q==p for q in assignment)>a.agent_capacity[p] for p in set(assignment)):
        return False,'capacity'
    if not secure_ok(method,job,shares,assignment,state,a):return False,'security'
    return True,''

def choose(job,rgb,arm,scenario,loss,state,a,s33,s34):
    adapt_m,adapt_r,adapt_o=ARMS[arm]; methods=METHODS if adapt_m else (a.fixed_method,)
    policies=POLICIES if adapt_r else (a.fixed_policy,)
    best=None;start=time.perf_counter(); cached={}
    for method in methods:
        if a.require_authentication and method not in ('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3'):
            state.security_rejections+=1;continue
        shares,decoder,target,k=s34.make_shares(s33,method,rgb,b'')
        cached[method]=(shares,decoder,target,k)
        for assignment in choices(len(shares),adapt_o,a):
            state.bids+=1
            feasible,reason=feasible_assignment(job,method,shares,assignment,state,a)
            if not feasible:
                if reason=='capacity':state.capacity_rejections+=1
                if reason=='security':state.security_rejections+=1
                continue
            for policy in policies:
                score,r,t,w=candidate_score(shares,k,assignment,policy,loss,a)
                # Reliability forecast is conditional on the specified impairment model.
                if r+1e-12<a.min_reliability:
                    state.reliability_rejections+=1;continue
                key=(score,method,policy,assignment)
                if best is None or key<best[0]:best=(key,Plan(method,policy,assignment,shares,decoder,target,k,r,t,w,score))
    return (best[1] if best else None),(time.perf_counter()-start)*1000

def commit(job,plan,state,a):
    if job in state.owners:
        state.conflicts_prevented+=1;return False
    feasible,reason=feasible_assignment(job,plan.method,plan.shares,plan.assignment,state,a)
    if not feasible:
        state.capacity_rejections+=reason=='capacity';state.security_rejections+=reason=='security';return False
    state.owners[job]=job;state.committed[job]=plan.assignment;state.commitments+=1
    for (sid,_),p in zip(plan.shares,plan.assignment):
        state.exposed[job][sid].add(p);state.path_load[p]+=1;state.agent_load[p]+=1
    return True

def release(job,plan,state):
    if state.owners.get(job)!=job:state.ownership_violations+=1;return
    for p in state.committed.pop(job):state.path_load[p]-=1;state.agent_load[p]-=1
    del state.owners[job]

def intervention(job,sid,blob,old,plan,received,state,scenario,loss,rep,a,s35,mode):
    # A helper transmits only on a free eligible path; primary owner stays unchanged.
    # Reassignment transfers the fragment's active path commitment, retaining exposure.
    candidates=[p for p in a.allowed_paths if p!=old and not(scenario=='post_commit_failure' and p==a.failed_path)]
    candidates.sort(key=lambda p:(a.path_delays[p]+len(blob)*8/(a.path_rates[p]*1000),p))
    for p in candidates:
        if state.path_load[p]>=a.path_capacity[p] or state.agent_load[p]>=a.agent_capacity[p]:
            state.capacity_rejections+=1;continue
        if not secure_ok(plan.method,job,[(sid,blob)],(p,),state,a):
            state.security_rejections+=1;continue
        if mode=='reassign':
            # Replace only the failed fragment commitment; other owners unchanged.
            active=list(state.committed[job]);ix=[s for s,_ in plan.shares].index(sid)
            oldp=active[ix];active[ix]=p
            state.path_load[oldp]-=1;state.agent_load[oldp]-=1
            state.path_load[p]+=1;state.agent_load[p]+=1
            state.committed[job]=tuple(active);state.reassignments+=1
        else:
            state.assistance+=1
        state.exposed[job][sid].add(p)
        kind='burst' if scenario=='burst' else 'iid'
        got,w,_,_,_,_,ms=s35.transport(blob,p,plan.policy,kind,loss,rep+stable(job,sid,'intervention')%10000000,a)
        if got is not None:received[sid]=got
        return w,a.detection_ms+ms
    return 0.,0.

def execute(job,plan,state,scenario,loss,rep,a,s35,adaptive):
    received={};arrivals=[];wire=0.
    failed=[]
    for (sid,blob),p in zip(plan.shares,plan.assignment):
        if scenario=='post_commit_failure' and p==a.failed_path:
            failed.append((sid,blob,p));continue
        kind='burst' if scenario=='burst' else 'iid'
        got,w,_,_,_,_,ms=s35.transport(blob,p,plan.policy,kind,loss,rep+stable(job)%10000000,a)
        wire+=w
        if got is None:failed.append((sid,blob,p))
        else:received[sid]=got;arrivals.append(ms)
    if adaptive and len(received)<plan.k:
        for sid,blob,p in failed:
            if len(received)>=plan.k:break
            # Bounded cooperative assistance first; reassignment if assistance unavailable/unsuccessful.
            if a.enable_assistance:
                w,ms=intervention(job,sid,blob,p,plan,received,state,scenario,loss,rep,a,s35,'assist')
                wire+=w
                if ms:arrivals.append(ms)
            if sid not in received and a.enable_reassignment:
                w,ms=intervention(job,sid,blob,p,plan,received,state,scenario,loss,rep+17,a,s35,'reassign')
                wire+=w
                if ms:arrivals.append(ms)
    ok=len(received)>=plan.k
    if ok:
        try:ok=plan.decoder(received)==plan.target
        except Exception:
            ok=False;state.authentication_failures+=1
    elapsed=max(sorted(arrivals)[:plan.k]) if ok else a.timeout_ms
    return int(ok),wire,elapsed

def run_batch(entry,rgb,arm,scenario,loss,repeat,a,s33,s34,s35):
    state=State();out=[];methods=[];policies=[];assignments=[];planning=[]
    # Simulate a batch of competing commitments. Decisions are made before outcomes.
    # Hold commitments until batch completes, enforcing concurrent capacity.
    plans=[]
    for j in range(a.jobs):
        job=f'{entry["sha256"]}:{scenario}:{loss}:{repeat}:{j}'
        plan,ms=choose(job,rgb,arm,scenario,loss,state,a,s33,s34);planning.append(ms)
        if plan is None:state.infeasible_jobs+=1;out.append((0,0.,a.timeout_ms));continue
        if not commit(job,plan,state,a):state.infeasible_jobs+=1;out.append((0,0.,a.timeout_ms));continue
        plans.append((job,plan,j));methods.append(plan.method);policies.append(plan.policy)
        assignments.append('-'.join(map(str,plan.assignment)))
    for job,plan,j in plans:
        out.append(execute(job,plan,state,scenario,loss,repeat*100+j,a,s35,ARMS[arm][2]))
    for job,plan,j in plans:release(job,plan,state)
    success=sum(x[0] for x in out);wire=sum(x[1] for x in out);ms=statistics.mean(x[2] for x in out)
    ratio=wire/max(1,len(rgb)*a.jobs)
    obj=a.w_failure*(1-success/a.jobs)+a.w_time*ms/a.timeout_ms+a.w_wire*ratio
    return dict(split=entry['split'],image=entry['image'],sha256=entry['sha256'],scenario=scenario,loss_rate=loss,repeat=repeat,arm=arm,
        jobs=a.jobs,successful_jobs=success,success_rate=success/a.jobs,wire_bytes=wire,wire_ratio=ratio,
        mean_censored_ms=ms,mean_objective=obj,mean_planning_ms=statistics.mean(planning),
        methods=';'.join(methods),policies=';'.join(policies),assignments=';'.join(assignments),
        **{name:getattr(state,name) for name in ('bids','commitments','assistance','reassignments','conflicts_prevented','capacity_rejections',
        'security_rejections','reliability_rejections','ownership_violations','exposure_violations','capacity_violations',
        'authentication_failures','infeasible_jobs')},trace_key=f'{a.seed}|{entry["sha256"]}|{scenario}|{loss}|{repeat}')

def write_csv(path,rows,fields):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def validate(a):
    if any(x<=0 for x in a.path_capacity+a.agent_capacity):raise ValueError('Capacities must be positive')
    if not 0<=a.min_reliability<=1:raise ValueError('min-reliability outside [0,1]')
    if any(x<0 for x in (a.w_failure,a.w_time,a.w_wire)) or not math.isclose(a.w_failure+a.w_time+a.w_wire,1,abs_tol=1e-8):raise ValueError('Weights must sum to 1')
    if a.fixed_method not in METHODS:raise ValueError('Unknown fixed method')
    if a.require_authentication and a.fixed_method not in METHODS[:2]:raise ValueError('Fixed method violates authentication')
    if a.jobs<1 or a.max_images<1 or a.repeats<1:raise ValueError('Invalid counts')
    if not a.allowed_paths:raise ValueError('No eligible paths')

def self_test(a,s33,s34,s35):
    s33.selftest()
    payload=bytes(range(256))*4;entry=dict(split='synthetic',image='test',sha256='synthetic')
    # No loss and no resource contention; all arms should reconstruct.
    old=(a.jobs,a.min_reliability,a.path_capacity,a.agent_capacity)
    a.jobs=2;a.min_reliability=0.;a.path_capacity=[20]*3;a.agent_capacity=[20]*3;a.original_bytes=len(payload)
    for arm in ARMS:
        r=run_batch(entry,payload,arm,'iid',0.,0,a,s33,s34,s35)
        assert r['successful_jobs']==2,(arm,r)
        assert not r['ownership_violations'] and not r['capacity_violations']
    a.jobs,a.min_reliability,a.path_capacity,a.agent_capacity=old
    # Verify threshold exposure blocks accumulating two shares on a compromised path.
    state=State();state.exposed['x'][0].add(0)
    assert not secure_ok('Shamir_GF256_2of3','x',[(1,b'a')],(0,),state,a)
    # Commit/release ownership and capacity invariants.
    shares,decoder,target,k=s34.make_shares(s33,'AES128_GCM_PSK',payload,b'')
    p=Plan('AES128_GCM_PSK','none',(0,),shares,decoder,target,k,1,0,0,0)
    assert commit('owner',p,state,a)
    assert not commit('owner',p,state,a)
    release('owner',p,state)
    assert not state.owners and not state.path_load[0]
    print('PASS: six-arm loss-free reconstruction, exposure, ownership and release tests')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data'))
    p.add_argument('--out',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A_Full'))
    p.add_argument('--self-test',action='store_true');p.add_argument('--max-images',type=int,default=2)
    p.add_argument('--repeats',type=int,default=3);p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--seed',type=int,default=3701);p.add_argument('--loss-rates',default='0.01,0.10,0.20')
    p.add_argument('--fixed-method',default='AESGCM_XOR_Erasure_2of3',choices=METHODS)
    p.add_argument('--fixed-policy',default='fec_arq',choices=POLICIES)
    p.add_argument('--min-reliability',type=float,default=.90)
    p.add_argument('--allow-unauthenticated',action='store_true')
    p.add_argument('--path-capacity',default='4,4,4',help='Concurrent fragment commitments per path')
    p.add_argument('--agent-capacity',default='4,4,4',help='Concurrent fragment commitments per agent')
    p.add_argument('--eligible-paths',default='0,1,2')
    p.add_argument('--compromised-path-sets',default='0;1;2',help='Semicolon-separated path sets, e.g. 0;1;2;0,1')
    p.add_argument('--disable-assistance',action='store_true');p.add_argument('--disable-reassignment',action='store_true')
    p.add_argument('--w-failure',type=float,default=.65);p.add_argument('--w-time',type=float,default=.20);p.add_argument('--w-wire',type=float,default=.15)
    p.add_argument('--mtu',type=int,default=1000);p.add_argument('--header-bytes',type=int,default=20)
    p.add_argument('--fec-group',type=int,default=4);p.add_argument('--max-retries',type=int,default=3)
    p.add_argument('--failed-path',type=int,default=1);p.add_argument('--burst-persist',type=float,default=.85)
    p.add_argument('--timeout-ms',type=float,default=3000);p.add_argument('--detection-ms',type=float,default=80)
    a=p.parse_args();a.path_rates=(20.,10.,15.);a.path_delays=(10.,40.,25.)
    a.require_authentication=not a.allow_unauthenticated
    a.path_capacity=[int(x) for x in a.path_capacity.split(',')];a.agent_capacity=[int(x) for x in a.agent_capacity.split(',')]
    a.allowed_paths=set(int(x) for x in a.eligible_paths.split(','))
    a.compromised_sets=[set(int(x) for x in group.split(',')) for group in a.compromised_path_sets.split(';')]
    a.enable_assistance=not a.disable_assistance;a.enable_reassignment=not a.disable_reassignment
    if len(a.path_capacity)!=3 or len(a.agent_capacity)!=3 or any(p not in range(3) for p in a.allowed_paths):p.error('Three capacities required and paths must be 0,1,2')
    validate(a)
    s33=load('33_expanded_baseline.py','s33');s34=load('34_multipath_loss_simulator.py','s34');s35=load('35_packet_recovery.py','s35')
    if a.self_test:self_test(a,s33,s34,s35);return
    selected=manifest(a.data,a.max_images);a.out.mkdir(parents=True,exist_ok=True)
    write_csv(a.out/'A_full_00_manifest.csv',selected,list(selected[0]))
    losses=[float(x) for x in a.loss_rates.split(',')]
    if not losses or any(x<0 or x>=1 for x in losses):p.error('Invalid loss rates')
    rows=[]
    for entry in selected:
        image_path=a.data/entry['relative_path']
        if sha(image_path)!=entry['sha256']:raise ValueError('Image changed')
        with Image.open(image_path) as im:rgb=im.convert('RGB').tobytes()
        a.original_bytes=len(rgb)
        for scenario,loss in [(s,l) for s in ('iid','burst') for l in losses]+[('post_commit_failure',0.)]:
            for rep in range(a.repeats):
                for arm in ARMS:
                    row=run_batch(entry,rgb,arm,scenario,loss,rep,a,s33,s34,s35);rows.append(row)
                    print(f'{entry["image"]} {scenario} {loss:.2f} rep={rep} {arm}: {row["success_rate"]:.2f} infeasible={row["infeasible_jobs"]}',flush=True)
    write_csv(a.out/'A_full_01_runs.csv',rows,FIELDS)
    summary=[]
    for arm in ARMS:
        rr=[r for r in rows if r['arm']==arm]
        d=dict(arm=arm,batches=len(rr),jobs=sum(r['jobs'] for r in rr),success_rate=sum(r['successful_jobs'] for r in rr)/sum(r['jobs'] for r in rr))
        for metric in ('wire_ratio','mean_censored_ms','mean_objective','mean_planning_ms','assistance','reassignments','infeasible_jobs','capacity_rejections','security_rejections','reliability_rejections'):
            col=metric if metric.startswith('mean_') else metric
            d['avg_'+metric]=statistics.mean(r[col] for r in rr)
        summary.append(d)
    write_csv(a.out/'A_full_02_summary.csv',summary,list(summary[0]))
    meta=dict(status='constrained event-driven simulation, not physical network validation',python=sys.version,platform=platform.platform(),
              pillow=Image.__version__,data_root=str(a.data),manifest_sha256=sha(a.out/'A_full_00_manifest.csv'),
              seed=a.seed,arms=ARMS,images=len(selected),jobs=a.jobs,repeats=a.repeats,loss_rates=losses,
              min_reliability=a.min_reliability,weights=dict(failure=a.w_failure,time=a.w_time,wire=a.w_wire),
              require_authentication=a.require_authentication,allowed_paths=sorted(a.allowed_paths),
              path_capacity=a.path_capacity,agent_capacity=a.agent_capacity,
              compromised_sets=[sorted(x) for x in a.compromised_sets],
              assumptions=['Agent id equals path id','Pre-shared encryption keys are uncompromised','Compromise scenarios are user-specified path sets','Forecast uses iid packet approximations under burst losses','No true packet-level adaptive recovery-policy switching after commitment','Assistance and reassignment use the same transport primitive','Path capacity is number of concurrent fragment commitments; no queueing model','Failed jobs use timeout censoring','Optimizer is bounded exhaustive candidate enumeration, not proof of global optimum','Simulated paths; no physical-network measurements'])
    (a.out/'A_full_03_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(f'COMPLETE: {len(rows)} batch rows saved in {a.out}')
if __name__=='__main__':main()
