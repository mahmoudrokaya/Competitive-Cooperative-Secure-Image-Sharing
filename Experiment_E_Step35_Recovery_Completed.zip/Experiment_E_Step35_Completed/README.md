# Experiment E — Step35 recovery policy analysis (completed)

Source: `Inputs/35_01_runs(2).csv`, SHA-256 `53a809726f259fb42937f75075b584a92d322e5ef253b4fec9f5232b5d9898dd`.

Run:

```powershell
python .\55_experiment_e_statistics.py --input-dir .\Inputs --out .\Results --bootstrap 2000 --seed 2026
```

This archive deliberately contains ONLY the Step35 source data. The original Experiment E script reports B1/B2/C as missing for this isolated reproduction; those cohorts were already processed in the user's earlier run. The Step35 status is `analyzed`.

Outputs:
- `Results/E_04_recovery_rates_ci.csv`: 308 policy/scheme/scenario/loss-rate rows, image-cluster exploratory 95% CIs.
- `Results/E_05_recovery_paired_effects.csv`: 770 paired contrast rows (success rate and wire ratio), matched by image, repeat, scheme, scenario and loss rate.
- `Results/E_00_audit.json`: source audit and limitations.

Key constraints:
- 3,696 trials, **four distinct images** (two train, two validation); all CIs exploratory and potentially unstable.
- Per-scheme/condition groups contain 12 observations, only 4 image clusters.
- Failed recoveries have no `completion_ms`. Report success-conditioned completion time descriptively only; do not claim valid unconditional/censored completion-time comparisons.
- No guarantee of common stochastic random numbers across policies. Pairing is by experimental keys, not necessarily identical erasure realization.
- Zero loss-rate conditions and heterogeneous cryptographic schemes are included; pooled descriptive averages should not be interpreted as universal effects.
- Path-failure success is 57.14% for every policy, so no observed policy reliability benefit in this particular configuration.
- Existing source implementation, not a new experiment.
