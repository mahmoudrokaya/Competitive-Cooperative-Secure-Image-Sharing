import unittest,importlib.util
from pathlib import Path
P=Path(__file__).parent/'52_experiment_c_consolidated.py'
s=importlib.util.spec_from_file_location('experiment_c',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Tests(unittest.TestCase):
 def test_grid(self):
  _,g=m.stress_grid();self.assertEqual(len(g),19)
  self.assertTrue(all(x[0] and x[1] for x in g))
 def test_config(self):
  from argparse import Namespace
  c=m.config(Namespace(policy='fec_arq',seed=1),dict(jobs=16,capacity=1))
  self.assertEqual(c.jobs,16);self.assertEqual(c.capacity,1)
 def test_modes(self):self.assertEqual(len(m.MODES),6)
if __name__=='__main__':unittest.main()
