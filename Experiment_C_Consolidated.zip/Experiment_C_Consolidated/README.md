# Experiment C — Consolidated Organizational Stress Testing

This is **one executable script** consolidating the remaining essential organizational stress tests before Experiment D. It calls the **unchanged A3.1 simulator** and its three original dependencies. It does **not** implement new HHO optimization, security admission control, or packet-level multipath splitting. The original four scripts are copied here unchanged.

## Design and economy

The script uses one-factor-at-a-time (OFAT) comparisons across six organizational modes and three network scenarios, with fixed defaults for other factors. It covers 19 condition levels: baseline (1); concurrent jobs 1/2/4/8/16 (5); per-path capacity slots 1/2/4 (3); failure at 0/180/600 ms (3); intervention budget 0/1/3 (3); homogeneous vs heterogeneous paths (2); and spare-capacity *proxy* 1/4 slots (2). The 0 ms failure is before any completed transmission, but the event-driven simulator submits at t=0; it is not a separate pre-admission failure process. Duplicate baseline-equivalent levels are retained for interpretability, not new information.

The capacity-slot sweep is a **proxy for availability**; the original A3.1 does not model individual agent eligibility or assistance-only resource pools. Therefore claims about agent availability or separate assistance capacity are NOT validated. The script identifies such gaps rather than inventing mechanisms.

Default 19 × 3 scenarios × 6 modes × 2 repeats × 1 image = **684 image-level runs**. Six modes and the same image/scenario/repeat settings enable descriptive paired comparisons, but stochastic loss traces are not strictly common across modes. Use image-level paired bootstrap or permutation tests on a larger train/validation sample for inference; avoid declaring statistical significance from one image.

## Run

```powershell
python -m pip install pillow cryptography matplotlib
python -m unittest discover -p "test_experiment_c.py" -v
python .\52_experiment_c_consolidated.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_C_Consolidated_Pilot" `
  --split train --images 1 --pilot
```

If the pilot passes, run the full OFAT experiment on train (e.g. `--images 10 --repeats 3`), then a predeclared validation replication (`--split val --images 10 --repeats 3`). **Do not use test or USC-SIPI for further method selection.** The 10-image setting is exploratory, not a formal power calculation. Consider the runtime before increasing the number of images.

## Outputs

- `C_00_audit.json`: experiment size, code hash, failures, limitations.
- `C_01_runs.csv`: raw simulator metrics including transmitted bytes, recovery, time, interventions and capacity/ownership checks.
- `C_02_summary.csv`: means and intervention costs by condition/mode/scenario.
- `C_03_mode_contrasts.csv`: assistance vs ownership, reassignment vs ownership, full vs reassignment, full vs assistance.
- `C_04_scalability.png`: concurrent-jobs scalability plot for burst loss (if matplotlib installed).
- `C_05_errors.csv`: generated only if exceptions occur.

## Interpretation and remaining critical gaps

1. The script measures *simulation reconstruction*, not cryptographic confidentiality or Section 2.3 compliance; proceed to Experiment D with integrated guard tests for those claims.
2. In A3.1, `full` can behave exactly like reassignment in many conditions. If the difference remains zero, report no additional combined benefit rather than implying synergy.
3. C4.3's multi-path single-fragment AES and J6 instability are excluded from this stress benchmark: A3.1 has fixed fragment-level placement and does not measure J6. If the manuscript asserts continuous allocation, multiobjective HHO gains, or constrained joint optimization, those claims still require implementation/evidence or must be narrowed. This package does not silently solve them.
4. This is a synthetic event-driven model, not an actual distributed network.
5. To attribute assistance vs reassignment causally, a follow-on small controller patch may be needed because current `full` uses assistance first and reassignment only after a subsequent intervention; equal aggregate metrics alone cannot demonstrate adaptive intervention selection.
