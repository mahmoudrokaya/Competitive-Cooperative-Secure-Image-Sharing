#!/usr/bin/env python3
"""Consolidated organizational stress experiment on frozen A3.1; train/val only.
One-factor-at-a-time (OFAT), matched configurations across six organizational modes.
Does NOT establish packet-level allocation, optimizer security, or J1-J6 optimality.
"""
import argparse,csv,json,hashlib,importlib.util,statistics,collections,math
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent
MODES=('static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full')
SCENARIOS=('iid_0.10','burst_0.20','path_failure')

def load(name):
 spec=importlib.util.spec_from_file_location('stress_'+name[:2],HERE/name);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def write_csv(path,rows):
 if not rows:return
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def stress_grid():
 """OFAT around reference configuration; labels are exact simulator controls, not agent counts."""
 base=dict(jobs=4,capacity=4,failure_at_ms=180.,max_interventions_per_job=3,path_rates=(20.,10.,15.),path_delays=(10.,40.,25.),detection_ms=80.)
 grid=[('baseline','reference',{})]
 for x in (1,2,4,8,16):grid.append(('concurrent_jobs',str(x),dict(jobs=x)))
 # Available commitment slots per path, not a model of individual agent eligibility.
 for x in (1,2,4):grid.append(('path_capacity_slots',str(x),dict(capacity=x)))
 for label,t in [('before_commitment',0.),('during_execution',180.),('near_completion',600.)]:grid.append(('failure_timing',label,dict(failure_at_ms=t)))
 for x in (0,1,3):grid.append(('intervention_budget',str(x),dict(max_interventions_per_job=x)))
 grid += [('path_heterogeneity','similar',dict(path_rates=(15.,15.,15.),path_delays=(25.,25.,25.))),('path_heterogeneity','unequal',dict(path_rates=(30.,5.,15.),path_delays=(5.,90.,30.)))]
 # Assistance availability proxy: same capacity is shared by all requests.
 for x in (1,4):grid.append(('spare_capacity_proxy',str(x),dict(capacity=x)))
 return base,grid

def config(args,overrides):
 v=dict(jobs=4,capacity=4,contention_capacity=2,policy=args.policy,mtu=1000,header_bytes=20,fec_group=4,max_retries=3,
 failed_path=1,failure_at_ms=180.,burst_persist=.85,timeout_ms=3000.,detection_ms=80.,queue_penalty_ms=20.,
 duplicate_path_penalty_ms=10.,max_interventions_per_job=3,max_events=100000,seed=args.seed,path_rates=(20.,10.,15.),path_delays=(10.,40.,25.))
 v.update(overrides)
 return argparse.Namespace(**v)

def summarize(rows):
 groups=collections.defaultdict(list)
 for r in rows:groups[(r['factor'],r['level'],r['scenario'],r['mode'])].append(r)
 out=[]
 for (factor,level,scenario,mode),rr in sorted(groups.items()):
  n=len(rr);jobs=sum(int(x['jobs']) for x in rr)
  out.append(dict(factor=factor,level=level,scenario=scenario,mode=mode,runs=n,jobs=jobs,
   success_rate=sum(int(x['successes']) for x in rr)/jobs,
   mean_censored_ms=statistics.mean(float(x['mean_censored_ms']) for x in rr),
   wire_ratio=statistics.mean(float(x['wire_ratio']) for x in rr),
   mean_transmitted_bytes=statistics.mean(float(x['transmitted_bytes']) for x in rr),
   assists_per_job=sum(int(x['assists']) for x in rr)/jobs,
   reassignments_per_job=sum(int(x['reassignments']) for x in rr)/jobs,
   intervention_cost_per_job=sum(int(x['assists'])+int(x['reassignments']) for x in rr)/jobs,
   queued_requests=sum(int(x['queued_requests']) for x in rr),
   ownership_conflicts=sum(int(x['ownership_conflicts']) for x in rr),
   capacity_violations=sum(int(x['capacity_violations']) for x in rr),
   reservation_leaks=sum(int(x['reservation_leaks']) for x in rr)))
 return out

def comparisons(summary):
 groups=collections.defaultdict(dict)
 for r in summary:groups[(r['factor'],r['level'],r['scenario'])][r['mode']]=r
 out=[]
 for (factor,level,scenario),m in sorted(groups.items()):
  if not all(k in m for k in MODES):continue
  for left,right in [('bidding_ownership_assist','bidding_ownership'),('bidding_ownership_reassign','bidding_ownership'),('full','bidding_ownership_reassign'),('full','bidding_ownership_assist')]:
   a,b=m[left],m[right]
   out.append(dict(factor=factor,level=level,scenario=scenario,contrast=left+' minus '+right,
    delta_success_pp=100*(a['success_rate']-b['success_rate']),delta_censored_ms=a['mean_censored_ms']-b['mean_censored_ms'],
    delta_wire_ratio=a['wire_ratio']-b['wire_ratio'],delta_interventions_per_job=a['intervention_cost_per_job']-b['intervention_cost_per_job'],
    interpretation='descriptive only; not a significance test'))
 return out

def figure(summary,out):
 try:
  import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
 except ImportError:return 'matplotlib unavailable; figure skipped'
 subset=[r for r in summary if r['factor']=='concurrent_jobs' and r['scenario']=='burst_0.20']
 if not subset:return 'no scalability data'
 fig,ax=plt.subplots(figsize=(9,5))
 for mode in MODES:
  a=sorted((r for r in subset if r['mode']==mode),key=lambda x:int(x['level']))
  ax.plot([int(r['level']) for r in a],[100*r['success_rate'] for r in a],marker='o',label=mode)
 ax.set(xlabel='Concurrent jobs',ylabel='Reconstruction success (%)',title='Organizational scalability — burst loss 20% (simulation)')
 ax.set_ylim(0,105);ax.grid(alpha=.25);ax.legend(fontsize=7);fig.tight_layout();fig.savefig(out/'C_04_scalability.png',dpi=180);plt.close(fig)
 return 'C_04_scalability.png'

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
 p.add_argument('--split',choices=('train','val'),default='train');p.add_argument('--images',type=int,default=1,help='Number of images from selected split')
 p.add_argument('--repeats',type=int,default=2);p.add_argument('--seed',type=int,default=5201)
 p.add_argument('--method',choices=('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3'),default='AESGCM_XOR_Erasure_2of3')
 p.add_argument('--policy',choices=('arq','fec_arq'),default='fec_arq');p.add_argument('--scenarios',default=','.join(SCENARIOS))
 p.add_argument('--pilot',action='store_true',help='Only reference, 1 and 4 jobs, two scenarios, one repeat')
 args=p.parse_args()
 if args.images<1 or args.repeats<1: p.error('images and repeats must be positive')
 scenarios=args.scenarios.split(',')
 if not set(scenarios)<=set(SCENARIOS):p.error('unsupported scenario')
 a31=load('40_A3_1_capacity_aware.py');s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py')
 entries=[e for e in a31.manifest(args.data,args.images) if e['split']==args.split]
 _,grid=stress_grid()
 if args.pilot:grid=[x for x in grid if x[0]=='baseline' or x[0]=='concurrent_jobs' and x[1] in ('1','4')];scenarios=['burst_0.20','path_failure'];args.repeats=1
 args.out.mkdir(parents=True,exist_ok=True)
 rows=[];errors=[];cases=0
 for factor,level,overrides in grid:
  for entry in entries:
   with Image.open(args.data/entry['relative_path']) as im:rgb=im.convert('RGB').tobytes()
   for scenario in scenarios:
    for rep in range(args.repeats):
     for mode in MODES:
      cases+=1;cfg=config(args,overrides)
      try:
       result=a31.execute(entry,rgb,args.method,mode,scenario,rep,cfg,s33,s34,s35,[])
       result.update(transmitted_bytes=round(result['wire_ratio']*len(rgb)*cfg.jobs,2),factor=factor,level=level,policy=args.policy,capacity=cfg.capacity,failure_at_ms=cfg.failure_at_ms,
        max_interventions_per_job=cfg.max_interventions_per_job,path_rates=json.dumps(cfg.path_rates),path_delays=json.dumps(cfg.path_delays))
       rows.append(result)
      except Exception as exc:errors.append(dict(factor=factor,level=level,scenario=scenario,mode=mode,image=entry['image'],repeat=rep,error=repr(exc)))
  print(f'{factor}: {level} complete',flush=True)
 summary=summarize(rows);contrast=comparisons(summary)
 write_csv(args.out/'C_01_runs.csv',rows);write_csv(args.out/'C_02_summary.csv',summary);write_csv(args.out/'C_03_mode_contrasts.csv',contrast);write_csv(args.out/'C_05_errors.csv',errors)
 fig=figure(summary,args.out)
 audit=dict(stage='Consolidated Experiment C organizational stress',source_sha256=a31.digest(HERE/'40_A3_1_capacity_aware.py'),
 split=args.split,images=len(entries),repeats=args.repeats,scenarios=scenarios,methods=[args.method],policy=args.policy,
 factor_levels=len(grid),modes=len(MODES),expected_runs=cases,completed_runs=len(rows),errors=len(errors),
 capacity_violations=sum(int(r['capacity_violations']) for r in rows),ownership_conflicts=sum(int(r['ownership_conflicts']) for r in rows),
 reservation_leaks=sum(int(r['reservation_leaks']) for r in rows),figure=fig,
 limitations=['OFAT design, not full factorial','No direct agent eligibility or assistance-specific capacity mechanism in original A3.1; capacity proxies are explicitly labeled',
 'No guarantee of common packet-level loss traces across modes','Full mode may behave identically to reassignment; do not infer synergistic gain',
 'No independent test-set evidence','Security constraints and J4 require Experiment D integrated guard','No new optimization or genuine packet-level traffic allocation',
 'Intervention cost measured as intervention counts, not calibrated monetary/energy cost'])
 (args.out/'C_00_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
 print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
