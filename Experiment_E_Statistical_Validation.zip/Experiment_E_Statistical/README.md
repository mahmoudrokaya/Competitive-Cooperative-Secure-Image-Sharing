# Experiment E — Existing-data statistical validation

This package analyzes existing CSV files without running the simulator. It uses the **four-job batch** as the organizational observation and an **image-cluster bootstrap** to account for repeated runs of the same image. All confidence intervals are descriptive/exploratory 95% percentile intervals. Do not claim independent held-out validation: B1/B2 have already been inspected during development.

## Inputs

Place these files in one input directory:

- `B1_01_runs.csv` — BSDS500 B1 (50,400 batches, 200 images).
- `B2_01_runs.csv` — USC-SIPI B2 (9,828 batches, 39 images).
- `CF_01_runs.csv` — final focused C validation (2,880 batches, 10 images).
- `35_01_runs(2).csv` or `35_01_runs.csv` — Step35 packet recovery (3,696 trials, 4 images).

## Run

```powershell
python -m pip install numpy pandas
python .\55_experiment_e_statistics.py --input-dir "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Collected" --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_E" --bootstrap 2000 --seed 2026
```

Change `--input-dir` to the directory where your source CSV files actually reside. If files are distributed across result folders, copy only the four named CSVs into a common analysis input folder. Missing inputs are reported in the audit, not silently invented.

## Outputs

- `E_00_audit.json`: source file checksums and methodological caveats.
- `E_01_organizational_rates_ci.csv`: per-mode batch success fractions, censored time, wire ratios, and image-cluster 95% CIs.
- `E_02_organizational_paired_effects.csv`: matched mode contrasts, including full minus reassignment, for all three metrics; exact-zero indicator.
- `E_03_constraint_observations.csv`: recorded capacity, ownership, and reservation counts (not adversarial constraint validation).
- `E_04_recovery_rates_ci.csv`: Step35 policy success and wire ratio CIs.
- `E_05_recovery_paired_effects.csv`: paired recovery-policy comparisons.

## Important boundaries

- Step35 `completion_ms` is missing when reconstruction fails. Thus it is **not** a valid censored completion-time outcome. This code reports its success-only mean explicitly but does not compare it as though it were a censored metric.
- B1 and B2 are kept separate, as are the final C results; there is no inappropriate pooling of distinct datasets or development stages.
- Image bootstrap resamples all batches of each image together, while paired contrasts are formed at the batch level. This is more conservative than treating each job as independent.
- Different modes may consume different loss traces. Pairing controls observed image/repeat/scenario but is not guaranteed common packet randomness.
- No family-wise multiple-testing correction is provided. Individual confidence intervals are exploratory, especially across many conditions.
- The original manuscript's exact objective equations are not available. No claims about J1–J6 formal compliance are made.
