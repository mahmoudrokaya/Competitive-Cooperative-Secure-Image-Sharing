#!/usr/bin/env python3
"""Experiment E: reanalysis of existing records, no simulations executed.
Batch is the organizational observational unit; image clusters are resampled for CI.
"""
import argparse, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

METRICS=['success_rate','mean_censored_ms','wire_ratio']
MODES=['static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full']
CONTRASTS=[('bidding','static'),('bidding_ownership','bidding'),('bidding_ownership_assist','bidding_ownership'),('bidding_ownership_reassign','bidding_ownership'),('full','bidding_ownership_reassign'),('full','bidding_ownership_assist'),('full','static')]
POLICY_CONTRASTS=[('arq','none'),('fec','none'),('fec_arq','arq'),('fec_arq','fec'),('fec_arq','none')]

def cluster_ci(frame, metrics, cluster, boot, seed):
    """Point estimate over batches; resample image clusters retaining all batches.
    Cluster bootstrap is conservative about repeated image reuse, but not an independent test.
    """
    a=frame[[cluster]+metrics].copy()
    a[cluster]=a[cluster].astype(str)
    group=a.groupby(cluster,sort=True)[metrics].agg(['sum','count'])
    if len(group)==0:return {}
    sums=np.stack([group[(m,'sum')].to_numpy(dtype=float) for m in metrics],axis=1)
    counts=np.stack([group[(m,'count')].to_numpy(dtype=float) for m in metrics],axis=1)
    point=np.nansum(sums,axis=0)/np.maximum(np.nansum(counts,axis=0),1)
    rng=np.random.default_rng(seed)
    samples=[]
    for _ in range(0,boot,200):
        size=min(200,boot-len(samples)*200)
        if size<=0:break
        ids=rng.integers(0,len(group),size=(size,len(group)))
        bs=sums[ids].sum(axis=1)/np.maximum(counts[ids].sum(axis=1),1)
        samples.append(bs)
    draws=np.concatenate(samples,axis=0)
    result={}
    for i,m in enumerate(metrics):
        result[m]=(float(point[i]),float(np.quantile(draws[:,i],.025)),float(np.quantile(draws[:,i],.975)))
    return result

def output_table(rows,path):
    pd.DataFrame(rows).to_csv(path,index=False)

def prepare_org(df,source):
    df=df.copy()
    df['source_cohort']=source
    df['cluster']=df['sha256'].fillna(df['image']) if 'sha256' in df else df['image']
    df['batch_key']=df['cluster'].astype(str)+'|'+df['repeat'].astype(str)
    for m in METRICS:df[m]=pd.to_numeric(df[m],errors='coerce')
    df['successes']=pd.to_numeric(df['successes'],errors='coerce')
    df['jobs']=pd.to_numeric(df['jobs'],errors='coerce')
    df['success_rate']=df['successes']/df['jobs']
    return df

def org_analysis(df,source,boot,seed):
    summaries=[];paired=[];integrity=[]
    dims=['method','scenario']+(['condition'] if 'condition' in df else [])
    for k,g in df.groupby(dims,dropna=False,sort=True):
        ctx=dict(zip(dims,k if isinstance(k,tuple) else (k,)))
        for mode,m in g.groupby('mode'):
            ci=cluster_ci(m,METRICS,'cluster',boot,seed)
            row={'cohort':source,**ctx,'mode':mode,'batches':len(m),'images':m.cluster.nunique(),'jobs_total':int(m.jobs.sum()),'successes_total':int(m.successes.sum()),'assists':int(m.assists.sum()),'reassignments':int(m.reassignments.sum())}
            for metric,(v,lo,hi) in ci.items():row.update({metric:v,metric+'_ci_low':lo,metric+'_ci_high':hi})
            summaries.append(row)
        for target,control in CONTRASTS:
            a=g[g['mode']==target];b=g[g['mode']==control]
            keys=['cluster','repeat','method','scenario']+(['condition'] if 'condition' in g else [])
            cols=keys+METRICS
            merged=a[cols].merge(b[cols],on=keys,suffixes=('_a','_b'),validate='one_to_one')
            for metric in METRICS:
                merged['diff']=merged[metric+'_a']-merged[metric+'_b']
                ci=cluster_ci(merged,['diff'],'cluster',boot,seed)[ 'diff'] if len(merged) else (np.nan,)*3
                paired.append({'cohort':source,**ctx,'target':target,'control':control,'metric':metric,'paired_batches':len(merged),'image_clusters':merged.cluster.nunique(),'mean_paired_difference':ci[0],'ci_low':ci[1],'ci_high':ci[2],'exactly_zero_all_pairs':bool(len(merged)>0 and (merged['diff'].abs()<1e-12).all()),'missing_target':len(a)-len(merged),'missing_control':len(b)-len(merged)})
        integrity.append({'cohort':source,**ctx,'batches':len(g),'capacity_violations':int(g.capacity_violations.sum()),'ownership_conflicts':int(g.ownership_conflicts.sum()),'reservation_leaks':int(g.reservation_leaks.sum())})
    return summaries,paired,integrity

def recovery_analysis(df,boot,seed):
    # Step35 is a separate small early-stage recovery cohort; do not mix with B1/B2.
    df=df.copy();df['cluster']=df['split'].astype(str)+'|'+df['image'].astype(str)
    df['success_rate']=pd.to_numeric(df['recovered'],errors='coerce')
    df['wire_ratio']=pd.to_numeric(df['wire_ratio'],errors='coerce')
    df['completion_ms']=pd.to_numeric(df['completion_ms'],errors='coerce')
    rows=[];comparisons=[]
    for (scheme,scenario,rate),g in df.groupby(['scheme','scenario','loss_rate']):
        ctx=dict(scheme=scheme,scenario=scenario,loss_rate=rate)
        for policy,p in g.groupby('policy'):
            ci=cluster_ci(p,['success_rate','wire_ratio'],'cluster',boot,seed)
            row={**ctx,'policy':policy,'records':len(p),'images':p.cluster.nunique(),'successes':int(p.success_rate.sum()),'completion_success_only_mean_ms':float(p.completion_ms.mean()) if p.completion_ms.notna().any() else np.nan,'completion_note':'Completion missing for failures; no valid censored-time comparison from this file'}
            for metric,(v,lo,hi) in ci.items():row.update({metric:v,metric+'_ci_low':lo,metric+'_ci_high':hi})
            rows.append(row)
        for target,control in POLICY_CONTRASTS:
            keys=['cluster','repeat','scheme','scenario','loss_rate']
            aa=g[g.policy==target][keys+['success_rate','wire_ratio']]
            bb=g[g.policy==control][keys+['success_rate','wire_ratio']]
            m=aa.merge(bb,on=keys,suffixes=('_a','_b'),validate='one_to_one')
            for metric in ['success_rate','wire_ratio']:
                m['diff']=m[metric+'_a']-m[metric+'_b']
                ci=cluster_ci(m,['diff'],'cluster',boot,seed)['diff'] if len(m) else (np.nan,)*3
                comparisons.append({**ctx,'target':target,'control':control,'metric':metric,'paired_records':len(m),'image_clusters':m.cluster.nunique(),'difference':ci[0],'ci_low':ci[1],'ci_high':ci[2]})
    return rows,comparisons

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input-dir',type=Path,default=Path('.'))
    p.add_argument('--out',type=Path,default=Path('Experiment_E_Results'))
    p.add_argument('--bootstrap',type=int,default=1000)
    p.add_argument('--seed',type=int,default=2026)
    args=p.parse_args()
    if args.bootstrap<100: p.error('bootstrap must be >=100')
    args.out.mkdir(parents=True,exist_ok=True)
    summary=[];contrasts=[];checks=[];files={}
    for cohort,filename in [('B1_BSDS500','B1_01_runs.csv'),('B2_USCSIPI','B2_01_runs.csv'),('C_final_validation','CF_01_runs.csv')]:
        path=args.input_dir/filename
        if not path.is_file():files[cohort]={'status':'MISSING','file':filename};continue
        d=prepare_org(pd.read_csv(path),cohort)
        dup=d.duplicated(['method','mode','scenario','repeat','cluster']+(['condition'] if 'condition' in d else [])).sum()
        if dup:raise ValueError(f'{filename}: {dup} duplicate experimental keys')
        s,c,i=org_analysis(d,cohort,args.bootstrap,args.seed)
        summary+=s;contrasts+=c;checks+=i
        files[cohort]={'status':'analyzed','file':filename,'rows':len(d),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'images':int(d.cluster.nunique())}
    output_table(summary,args.out/'E_01_organizational_rates_ci.csv')
    output_table(contrasts,args.out/'E_02_organizational_paired_effects.csv')
    output_table(checks,args.out/'E_03_constraint_observations.csv')
    path=args.input_dir/'35_01_runs(2).csv'
    if not path.exists():path=args.input_dir/'35_01_runs.csv'
    if path.exists():
        d=pd.read_csv(path)
        s,c=recovery_analysis(d,args.bootstrap,args.seed)
        output_table(s,args.out/'E_04_recovery_rates_ci.csv')
        output_table(c,args.out/'E_05_recovery_paired_effects.csv')
        files['Step35_recovery']={'status':'analyzed','file':path.name,'rows':len(d),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    else:files['Step35_recovery']={'status':'MISSING'}
    audit={'stage':'Experiment E statistical reanalysis','bootstrap_draws':args.bootstrap,'cluster_resampling':'image SHA/image identity, keeping complete matched batches','observational_unit':'four-job batch for organizational results; Step35 single-image scheme-policy trial','pairing':'image, repeat, method, scenario and condition where applicable','files':files,'limitations':['No fresh simulations; B1/B2 test/external cohorts were previously inspected in development','No common-random-number guarantee across policy or mode','Image cluster bootstrap is exploratory; no multiplicity adjustment','Step35 completion_ms is missing for failed reconstructions; cannot estimate censored-time differences without timeout rule','Batch success rates are means over batches, not independent per-job Bernoulli trials','Comparisons are within cohort only; never pool B1, B2 and C final','Sensitivity to resource levels is descriptive from C final; no factorial interaction estimates']}
    (args.out/'E_00_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
    print(json.dumps({'output':str(args.out),'cohorts':files,'organizational_summary_rows':len(summary),'organizational_contrasts':len(contrasts)},indent=2))
if __name__=='__main__':main()
