#!/usr/bin/env python3
"""C2: image-clustered paired organizational ablations, Python 3.10+."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

MODES=['static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full']
CONTRASTS=[('bidding','static','bidding_vs_static'),('bidding_ownership','bidding','ownership_increment'),('bidding_ownership_assist','bidding_ownership','assistance_increment'),('bidding_ownership_reassign','bidding_ownership','reassignment_increment'),('full','bidding_ownership_assist','full_vs_assistance'),('full','bidding_ownership_reassign','full_vs_reassignment'),('full','bidding_ownership','full_vs_base'),('full','static','full_vs_static')]
METRICS=['success_rate','wire_ratio','mean_censored_ms','queued_requests']
KEY=['sha256','method','scenario','repeat']

def locate(root,phase):
    for path in [root/phase/f'{phase}_01_runs.csv',root/f'{phase}_01_runs.csv']:
        if path.is_file(): return path
    raise FileNotFoundError(f'Cannot find {phase}_01_runs.csv in {root} or {root/phase}')

def holm(p):
    a=np.asarray(p,float); order=np.argsort(a); out=np.empty(len(a)); last=0.
    for i,idx in enumerate(order):
        last=max(last,min(1.,a[idx]*(len(a)-i)));out[idx]=last
    return out

def inference(x,rng,nboot,nperm):
    x=np.asarray(x,float);n=len(x);effect=float(x.mean())
    if np.all(x==0):return effect,0.,0.,1.,'exact_zero'
    bs=x[rng.integers(0,n,size=(nboot,n))].mean(axis=1)
    lo,hi=np.quantile(bs,[.025,.975]);
    # Image-level paired sign-flip randomization, Monte Carlo two-sided.
    extreme=0
    for _ in range(0,nperm,250):
        k=min(250,nperm-_);signs=rng.choice(np.array([-1.,1.]),size=(k,n))
        extreme+=np.count_nonzero(np.abs((signs*x).mean(axis=1))>=abs(effect)-1e-12)
    return effect,float(lo),float(hi),(extreme+1)/(nperm+1),'permutation'

def run(root,out,nboot,seed,nperm):
    out.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(seed)
    all_inf=[];all_desc=[];all_integrity=[];all_scen=[];all_img=[];paths={}
    for phase in ('B1','B2'):
        path=locate(root,phase);paths[phase]=str(path);d=pd.read_csv(path)
        required=set(KEY+['mode','jobs','successes']+METRICS+['assists','reassignments','blocked_interventions','committed','released','capacity_violations','ownership_conflicts','reservation_leaks','exposure_violations'])
        missing=required-set(d.columns)
        if missing:raise ValueError(f'{phase}: missing columns {sorted(missing)}')
        if d.duplicated(KEY+['mode']).any():raise ValueError(f'{phase}: duplicate matched observation keys')
        if set(d['mode'])!=set(MODES):raise ValueError(f'{phase}: unexpected modes {set(d["mode"])}')
        nimg=d.sha256.nunique();methods=d.method.unique();scens=d.scenario.unique();reps=d.repeat.unique()
        expected=nimg*len(methods)*len(scens)*len(reps)*len(MODES)
        if len(d)!=expected:raise ValueError(f'{phase}: incomplete grid {len(d)} != {expected}')
        if not (d['committed']==d['released']).all():raise ValueError(f'{phase}: unmatched commitments')
        all_integrity.append(dict(dataset=phase,images=nimg,rows=len(d),jobs=int(d.jobs.sum()),methods=len(methods),scenarios=len(scens),repetitions=len(reps),commitment_release_mismatch=int((d.committed!=d.released).sum()),capacity_violations=int(d.capacity_violations.sum()),ownership_conflicts=int(d.ownership_conflicts.sum()),reservation_leaks=int(d.reservation_leaks.sum()),exposure_violations=int(d.exposure_violations.sum()),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        for (method,mode),sub in d.groupby(['method','mode']):
            all_desc.append(dict(dataset=phase,method=method,mode=mode,n_images=sub.sha256.nunique(),batches=len(sub),jobs=int(sub.jobs.sum()),successes=int(sub.successes.sum()),success_rate=float(sub.successes.sum()/sub.jobs.sum()),wire_ratio=float(sub.wire_ratio.mean()),mean_censored_ms=float(sub.mean_censored_ms.mean()),queued_requests=int(sub.queued_requests.sum()),assists=int(sub.assists.sum()),reassignments=int(sub.reassignments.sum()),blocked_interventions=int(sub.blocked_interventions.sum())))
        # Matched within image, scenario and repeat; image is inferential unit.
        wide=d.set_index(KEY+['mode'])[METRICS].unstack('mode')
        if wide.isna().any().any():raise ValueError(f'{phase}: incomplete paired keys')
        for method in methods:
            w=wide.xs(method,level='method')
            for treatment,control,label in CONTRASTS:
                for metric in METRICS:
                    diff=(w[(metric,treatment)]-w[(metric,control)])
                    im=diff.groupby(level='sha256').mean().sort_index()
                    effect,lo,hi,p,ptype=inference(im.to_numpy(),rng,nboot,nperm)
                    all_inf.append(dict(dataset=phase,method=method,contrast=label,treatment=treatment,control=control,metric=metric,n_images=len(im),effect=effect,ci95_low=lo,ci95_high=hi,p_unadjusted=p,p_method=ptype,exact_zero=bool(np.all(im==0)),n_bootstrap=nboot,n_permutations=nperm))
                    if metric=='success_rate':
                        for sha,v in im.items():all_img.append(dict(dataset=phase,method=method,contrast=label,sha256=sha,success_rate_delta=float(v)))
                        for scen in scens:
                            ss=diff.xs(scen,level='scenario')
                            all_scen.append(dict(dataset=phase,method=method,contrast=label,scenario=scen,success_rate_delta=float(ss.mean())))
    infer=pd.DataFrame(all_inf)
    # Predefined family: all C2 exploratory contrasts, per metric; conservative Holm across datasets/methods/contrasts.
    infer['p_holm_by_metric']=np.nan
    for metric,ids in infer.groupby('metric').groups.items():infer.loc[ids,'p_holm_by_metric']=holm(infer.loc[ids,'p_unadjusted'])
    infer['significant_0_05']=infer.p_holm_by_metric<.05
    desc=pd.DataFrame(all_desc)
    # Exact rowwise mode equality is stronger than an insignificant test.
    eq=[]
    for phase in ('B1','B2'):
        d=pd.read_csv(paths[phase]);w=d.set_index(KEY+['mode'])[METRICS].unstack('mode')
        for method in d.method.unique():
            sub=w.xs(method,level='method')
            for a,b,name in [('bidding','static','bidding_vs_static'),('bidding_ownership','bidding','ownership_increment')]:
                eq.append(dict(dataset=phase,method=method,contrast=name,identical_all_metrics_all_matched_batches=bool(all((sub[(metric,a)]==sub[(metric,b)]).all() for metric in METRICS))))
    for name,df in [('C2_00_integrity.csv',pd.DataFrame(all_integrity)),('C2_01_descriptive.csv',desc),('C2_02_ablation_inference.csv',infer),('C2_03_scenario_reliability.csv',pd.DataFrame(all_scen)),('C2_04_image_reliability_differences.csv',pd.DataFrame(all_img)),('C2_05_exact_equivalence.csv',pd.DataFrame(eq))]:df.to_csv(out/name,index=False)
    metadata={'stage':'C2 organizational ablation','seed':seed,'bootstrap_reps':nboot,'permutation_reps':nperm,'sampling_unit':'image SHA-256; average within image over scenarios and repeats','test':'paired image-level sign-flip randomization; Monte Carlo p-values','confidence_interval':'percentile image-cluster bootstrap','multiplicity':'Holm separately by metric across all 2 datasets x 2 methods x 8 contrasts','interpretation':'Observational simulation contrasts between fixed configurations; not randomized causal attribution; ownership is abstract; latency timeout-censored; no joint optimizer evaluation','inputs':paths}
    (out/'C2_06_methodology.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print('PASS',len(infer),'inference rows; output:',out)
    print(infer[(infer.metric=='success_rate')&(infer.contrast.isin(['assistance_increment','reassignment_increment','full_vs_static','ownership_increment']))][['dataset','method','contrast','effect','ci95_low','ci95_high','p_holm_by_metric']].to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--bootstrap',type=int,default=3000);p.add_argument('--permutations',type=int,default=5000);p.add_argument('--seed',type=int,default=4401);a=p.parse_args()
    if a.bootstrap<100 or a.permutations<100: p.error('At least 100 bootstrap/permutation repetitions required')
    run(a.input,a.out,a.bootstrap,a.seed,a.permutations)
