# Stage C2 — Organizational Ablation Analysis

## Purpose
Evaluate organizational configuration contrasts on frozen B1 and B2 results without modifying A3.1 or rerunning image experiments.

## Inputs
B1_01_runs.csv and B2_01_runs.csv, either in `<input>/B1/` and `<input>/B2/` or directly in `<input>/`.

## Windows execution
```powershell
python -m pip install numpy pandas
python .\44_C2_organizational_ablation.py `
  --input "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C2" `
  --bootstrap 3000 --permutations 5000 --seed 4401
```

## Outputs
- C2_00_integrity.csv — dataset completeness and simulator invariants.
- C2_01_descriptive.csv — mode-level aggregate success, overhead, latency and intervention counts.
- C2_02_ablation_inference.csv — paired image-cluster effects, percentile bootstrap confidence intervals, image-level paired sign-flip p-values and Holm correction per metric.
- C2_03_scenario_reliability.csv — scenario-specific reliability contrasts (descriptive only).
- C2_04_image_reliability_differences.csv — image-level paired success-rate differences.
- C2_05_exact_equivalence.csv — exact equivalence of modes across four primary metrics.
- C2_06_methodology.json — reproducibility and limitations.

## Methodological safeguards
Each image SHA-256 is one independent statistical unit. Paired differences are first computed at the image/scenario/repetition level, then averaged within image. Bootstrap samples images with replacement. Monte Carlo sign-flip tests operate on image-level paired differences; 5000 randomizations impose a minimum attainable unadjusted p-value of ~0.0002, so adjusted p-values near 0.0064 are resolution-limited. Holm adjustment is applied separately per outcome metric over all 32 contrasts (2 datasets x 2 protection methods x 8 contrasts). Confidence intervals are percentile bootstrap intervals and are **not multiplicity-adjusted**. The tests assume independent images within each dataset and sign-exchangeability under the null. Repeated scenarios/repetitions are not treated as independent samples.

The contrasts compare observed fixed simulator configurations, not isolated randomized interventions. Assistance and reassignment use a shared transport; ownership is abstract and lacks an independent enforcement protocol. Zero conflicts or exposure violations are simulator invariants, not a security proof. Completion time is timeout-censored. Results are from a simulated network, not physical experiments. B2 image provenance is user-attested, not independently certified. The complete J1–J6 optimizer is not assessed.
