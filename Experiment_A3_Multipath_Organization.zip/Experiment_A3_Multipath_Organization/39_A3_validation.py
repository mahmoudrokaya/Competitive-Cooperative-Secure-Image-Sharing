#!/usr/bin/env python3
"""A3: paired multipath and organizational mechanism validation (development only).

This is a packet-loss simulator, NOT a proof of cryptographic secrecy, global
optimality, physical-network performance, or complete Section 2.3 implementation.
"""
import argparse,csv,hashlib,importlib.util,itertools,json,math,platform,statistics,sys,time
from collections import Counter,defaultdict
from pathlib import Path
from PIL import Image

HERE=Path(__file__).resolve().parent
MODES=('static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full')
METHODS=('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')
SCENARIOS=('iid_0.01','iid_0.10','iid_0.20','burst_0.10','burst_0.20','path_failure','contention')

def module(name,alias):
    spec=importlib.util.spec_from_file_location(alias,HERE/name)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def hash_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def stable(*parts):return int.from_bytes(hashlib.sha256('|'.join(map(str,parts)).encode()).digest()[:8],'big')

def manifest(root,n):
    base=root/'BSR'/'BSDS500'/'data'/'images';rows=[];seen=set()
    for split in ('train','val'):
        folder=base/split
        if not folder.is_dir():raise FileNotFoundError(folder)
        candidates=sorted((p for p in folder.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png')))
        if len(candidates)<n:raise ValueError(f'Need {n} images in {folder}')
        for p in candidates[:n]:
            digest=hash_file(p)
            if digest in seen:raise ValueError('Duplicate development images')
            seen.add(digest)
            with Image.open(p) as im:w,h=im.size;mode=im.mode;im.verify()
            rows.append(dict(split=split,image=p.name,relative_path=p.relative_to(root).as_posix(),sha256=digest,width=w,height=h,mode=mode))
    return rows

def scenario_params(name):
    if name=='path_failure':return 'iid',0.,True
    if name=='contention':return 'iid',.10,False
    kind,loss=name.split('_');return kind,float(loss),False

def eligible(path,failed):return not(failed and path==1)

def feasible(paths,loads,cap,failed=False):
    count=Counter(paths)
    return all(eligible(p,failed) and loads[p]+v<=cap[p] for p,v in count.items())

def pick_assignment(n,mode,loads,cap,a,failed=False):
    static=tuple(i%3 for i in range(n))
    if mode=='static':return static if feasible(static,loads,cap,failed=False) else None
    choices=itertools.product(range(3),repeat=n)
    options=[]
    for assignment in choices:
        if not feasible(assignment,loads,cap,failed=False):continue
        # Candidate evaluation sees path rate, delay and current commitment load,
        # but never realized future losses or the future failure event.
        score=max(a.path_delays[p]+loads[p]*a.queue_penalty_ms+1000/pow(a.path_rates[p],1) for p in assignment)
        # Prefer path diversity in ties, not an artificially mandated multipath benefit.
        score+=a.duplicate_path_penalty_ms*(n-len(set(assignment)))
        options.append((score,assignment))
    return min(options)[1] if options else None

def send(s35,blob,path,policy,scenario,loss,rep,a,seed_key):
    kind,_,failed=scenario_params(scenario)
    if failed and path==1:return None,0.,a.timeout_ms,True
    # Seeds depend on image/scenario/repetition/job/fragment/path/attempt, NOT arm.
    # Thus matched actions experience the same pseudo-random network draw.
    seed=(a.seed+stable(*seed_key))%2000000000
    got,wire,_,_,_,_,ms=s35.transport(blob,path,policy,kind,loss,seed,a)
    return got,float(wire),float(ms),got is None

def execute_batch(entry,rgb,method,mode,scenario,rep,a,s33,s34,s35,trace):
    _,loss,failed=scenario_params(scenario)
    cap=[a.capacity]*3
    if scenario=='contention':cap=[a.contention_capacity]*3
    loads=[0,0,0]; plans=[];rejections=0;bid_count=0
    # All jobs commit before any transmission, modeling concurrent reservations.
    for j in range(a.jobs):
        shares,decoder,target,k=s34.make_shares(s33,method,rgb,b'')
        assign=pick_assignment(len(shares),mode,loads,cap,a)
        if mode!='static':bid_count+=3**len(shares)
        if assign is None:
            rejections+=1;plans.append((j,None,None,None,None,None));continue
        for p in assign:loads[p]+=1
        plans.append((j,shares,decoder,target,k,list(assign)))
    results=[];assist_count=0;reassign_count=0;blocked=0;failed_fragments=0;security_violations=0
    for j,shares,decoder,target,k,active in plans:
        if shares is None:
            results.append((0,0.,a.timeout_ms,0));continue
        received={};arrivals=[];wire=0.;interventions=0;fail_list=[]
        exposure=defaultdict(set)
        for (sid,blob),path in zip(shares,active):
            exposure[sid].add(path)
            got,w,ms,miss=send(s35,blob,path,a.policy,scenario,loss,rep,a,(entry['sha256'],scenario,rep,j,sid,path,'initial'))
            wire+=w
            if miss:failed_fragments+=1;fail_list.append((sid,blob,path))
            else:received[sid]=got;arrivals.append(ms)
            trace.append(dict(image=entry['image'],scenario=scenario,repeat=rep,method=method,mode=mode,job=j,fragment=sid,event='initial',from_path='',to_path=path,success=int(not miss),wire_bytes=w,latency_ms=ms))
        can_assist=mode in ('bidding_ownership_assist','full')
        can_reassign=mode in ('bidding_ownership_reassign','full')
        if len(received)<k and (can_assist or can_reassign):
            for sid,blob,old in fail_list:
                if len(received)>=k:break
                # Cooperative help uses temporary capacity; ownership remains with old path.
                # Reassignment transfers the active commitment to the new path.
                for action in (('assist' if can_assist else None),('reassign' if can_reassign else None)):
                    if action is None or sid in received:continue
                    alternatives=sorted((p for p in range(3) if p!=old and eligible(p,failed)),key=lambda p:(a.path_delays[p]+loads[p]*a.queue_penalty_ms,p))
                    chosen=next((p for p in alternatives if loads[p]<cap[p]),None)
                    if chosen is None:
                        blocked+=1;trace.append(dict(image=entry['image'],scenario=scenario,repeat=rep,method=method,mode=mode,job=j,fragment=sid,event=action+'_blocked',from_path=old,to_path='',success=0,wire_bytes=0,latency_ms=0));continue
                    if action=='assist':
                        loads[chosen]+=1;assist_count+=1
                    else:
                        loads[old]-=1;loads[chosen]+=1
                        active[[s for s,_ in shares].index(sid)]=chosen;reassign_count+=1
                    exposure[sid].add(chosen)
                    # AES-GCM is assumed to protect fragment contents; no plaintext
                    # threshold-share exposure claim is made for this method.
                    got,w,ms,miss=send(s35,blob,chosen,a.policy,scenario,loss,rep,a,(entry['sha256'],scenario,rep,j,sid,chosen,action))
                    wire+=w;interventions+=1
                    if action=='assist':loads[chosen]-=1
                    if not miss:received[sid]=got;arrivals.append(a.detection_ms+ms)
                    trace.append(dict(image=entry['image'],scenario=scenario,repeat=rep,method=method,mode=mode,job=j,fragment=sid,event=action,from_path=old,to_path=chosen,success=int(not miss),wire_bytes=w,latency_ms=a.detection_ms+ms))
        ok=len(received)>=k
        if ok:
            try:ok=decoder(received)==target
            except Exception:ok=False
        duration=max(sorted(arrivals)[:k]) if ok else a.timeout_ms
        results.append((int(ok),wire,duration,interventions))
    # Batch reservations are released at the end; verify capacity invariants.
    # Assistance reservations have already been released after transmission.
    for j,shares,decoder,target,k,active in plans:
        if active is not None:
            for p in active:loads[p]-=1
    if any(load!=0 for load in loads):raise AssertionError(('reservation leak',loads))
    return dict(split=entry['split'],image=entry['image'],sha256=entry['sha256'],method=method,mode=mode,scenario=scenario,repeat=rep,
                jobs=a.jobs,successes=sum(x[0] for x in results),success_rate=sum(x[0] for x in results)/a.jobs,
                wire_ratio=sum(x[1] for x in results)/(len(rgb)*a.jobs),mean_censored_ms=statistics.mean(x[2] for x in results),
                assists=assist_count,reassignments=reassign_count,blocked_interventions=blocked,
                infeasible_jobs=rejections,failed_fragments=failed_fragments,bid_candidates=bid_count,
                reservation_leaks=0,exposure_violations=security_violations,
                trace_key=f'{entry["sha256"]}|{method}|{scenario}|{rep}')

def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def self_test(a,s33,s34,s35):
    s33.selftest();a.jobs=2;a.capacity=10;a.contention_capacity=10
    a.path_rates=(20.,10.,15.);a.path_delays=(10.,40.,25.)
    payload=bytes(range(256))*4;entry={'split':'synthetic','image':'synthetic','sha256':'synthetic'}
    for method in METHODS:
        for mode in MODES:
            r=execute_batch(entry,payload,method,mode,'iid_0.01',0,a,s33,s34,s35,[])
            assert r['successes']==2,(method,mode,r)
            assert r['reservation_leaks']==0
    assert not feasible((0,0),[0,0,0],[1,1,1])
    assert feasible((0,1),[0,0,0],[1,1,1])
    print('PASS: 12 loss-free/low-loss method-mode tests and capacity checks')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data'))
    p.add_argument('--out',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A3'))
    p.add_argument('--max-images',type=int,default=2,help='Images per train/val partition')
    p.add_argument('--repeats',type=int,default=3);p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--seed',type=int,default=3901);p.add_argument('--capacity',type=int,default=4)
    p.add_argument('--contention-capacity',type=int,default=2)
    p.add_argument('--policy',choices=('none','fec','arq','fec_arq'),default='fec_arq')
    p.add_argument('--mtu',type=int,default=1000);p.add_argument('--header-bytes',type=int,default=20)
    p.add_argument('--fec-group',type=int,default=4);p.add_argument('--max-retries',type=int,default=3)
    p.add_argument('--failed-path',type=int,default=1);p.add_argument('--burst-persist',type=float,default=.85)
    p.add_argument('--timeout-ms',type=float,default=3000);p.add_argument('--detection-ms',type=float,default=80)
    p.add_argument('--queue-penalty-ms',type=float,default=20);p.add_argument('--duplicate-path-penalty-ms',type=float,default=10)
    p.add_argument('--self-test',action='store_true')
    a=p.parse_args();a.path_rates=(20.,10.,15.);a.path_delays=(10.,40.,25.)
    if min(a.jobs,a.max_images,a.repeats,a.capacity,a.contention_capacity,a.mtu,a.fec_group)<1:p.error('Counts must be positive')
    if not 0<=a.burst_persist<1:p.error('Invalid burst persistence')
    s33=module('33_expanded_baseline.py','a3_s33');s34=module('34_multipath_loss_simulator.py','a3_s34');s35=module('35_packet_recovery.py','a3_s35')
    if a.self_test:self_test(a,s33,s34,s35);return
    entries=manifest(a.data,a.max_images);a.out.mkdir(parents=True,exist_ok=True)
    write_csv(a.out/'A3_00_manifest.csv',entries)
    runs=[];trace=[]
    for entry in entries:
        path=a.data/entry['relative_path']
        if hash_file(path)!=entry['sha256']:raise RuntimeError('Dataset changed')
        with Image.open(path) as im:rgb=im.convert('RGB').tobytes()
        for scenario in SCENARIOS:
            for rep in range(a.repeats):
                for method in METHODS:
                    for mode in MODES:
                        row=execute_batch(entry,rgb,method,mode,scenario,rep,a,s33,s34,s35,trace)
                        runs.append(row)
                print(f'{entry["image"]}: {scenario} repeat={rep} done',flush=True)
    write_csv(a.out/'A3_01_runs.csv',runs)
    write_csv(a.out/'A3_02_event_traces.csv',trace)
    summary=[]
    for method in METHODS:
        for mode in MODES:
            rr=[r for r in runs if r['method']==method and r['mode']==mode]
            summary.append(dict(method=method,mode=mode,batches=len(rr),jobs=sum(x['jobs'] for x in rr),
                                success_rate=sum(x['successes'] for x in rr)/sum(x['jobs'] for x in rr),
                                mean_wire_ratio=statistics.mean(x['wire_ratio'] for x in rr),
                                mean_censored_ms=statistics.mean(x['mean_censored_ms'] for x in rr),
                                assists=sum(x['assists'] for x in rr),reassignments=sum(x['reassignments'] for x in rr),
                                blocked_interventions=sum(x['blocked_interventions'] for x in rr),
                                infeasible_jobs=sum(x['infeasible_jobs'] for x in rr)))
    write_csv(a.out/'A3_03_summary.csv',summary)
    meta=dict(status='development-only paired mechanism validation; not final joint optimizer',python=sys.version,platform=platform.platform(),
              root=str(a.data),images=len(entries),modes=MODES,methods=METHODS,scenarios=SCENARIOS,repeats=a.repeats,jobs=a.jobs,
              policy=a.policy,seed=a.seed,capacity=a.capacity,contention_capacity=a.contention_capacity,
              rows=len(runs),event_rows=len(trace),manifest_sha256=hash_file(a.out/'A3_00_manifest.csv'),
              limitations=['Simulated rather than physical network','Fixed method/policy within each arm; this is an ablation, not the full optimizer',
              'AES-GCM confidentiality assumes uncompromised encryption keys','Ownership is represented by capacity reservations, not a distributed consensus protocol',
              'No persistent queueing; all jobs hold commitments until batch end','Assistance and reassignment are distinct reservation semantics but use identical packet transport',
              'Only initial transmissions use matched per-fragment-path seeds; interventions are distinct stochastic actions',
              'Path failure occurs during transmission after initial commitment; controller does not anticipate failure',
              'Completion time is modeled latency with timeout censoring; simultaneous path scheduling is idealized'])
    (a.out/'A3_04_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(f'COMPLETE: {len(runs)} batch records and {len(trace)} trace events at {a.out}')
if __name__=='__main__':main()
