# Experiment A3 — Multipath and Organizational Validation

This is a **development-only, paired ablation** built on the original Step 33–35 modules. It is **not** the final Section 2.3 optimizer or a physical-network experiment.

## Dataset and output

- Input: `D:\48\481\New Papers\Progressive_HHO_Cryptography\Data`
- Output: `D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A3`
- Selects exactly `--max-images` images **from each** of `BSR\BSDS500\data\images\train` and `val`. Never reads `test`, `bench`, or `misc`.

## Install and verify (PowerShell)

```powershell
cd "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Experiment_A3_Multipath_Organization"
python -m pip install -r requirements.txt
python .\39_A3_validation.py --self-test
```

## Development run (PowerShell)

```powershell
python .\39_A3_validation.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A3" `
  --max-images 2 `
  --repeats 3 `
  --jobs 4
```

## Outputs

- `A3_00_manifest.csv`: SHA-256 checked selected images.
- `A3_01_runs.csv`: paired method/mode/scenario/repetition batch outcomes.
- `A3_02_event_traces.csv`: initial fragment transmissions, assistance, reassignment and blocked interventions.
- `A3_03_summary.csv`: descriptive aggregate outcomes.
- `A3_04_metadata.json`: settings, environment and limitations.

## Interpretation

The two protection mechanisms are **not cryptographically equivalent**: single-path AES-GCM is authenticated encryption; AES-GCM with (2,3) XOR erasure coding is encrypted redundancy, **not** a (2,3) threshold secret-sharing confidentiality guarantee. No requirement is imposed that the multipath option must win.

The `bidding` and `bidding_ownership` modes currently use the same capacity-aware assignment algorithm, and their outcomes may be identical. The implementation represents ownership by reservations, **not** by a separate distributed consensus protocol. The `full` mode uses assistance first, then reassignment only if assistance fails. Assistance temporarily consumes helper capacity while retaining the original commitment; reassignment transfers that commitment.

Path failure is not known to the initial selector. Identical initial method/fragment/path/scenario/job/repetition combinations use the same pseudo-random network draw across modes. The packet transport, cryptography and recovery are reused from the existing Step 33–35 modules.

A3 does not test reliability forecast calibration, cumulative plaintext-share compromise, cryptographic key compromise, or the fully dynamic joint optimizer. Those require separate experiments.

## Checks performed during packaging

- Self-test of 12 method/mode combinations: PASS.
- End-to-end synthetic-image smoke run (2 images, 7 scenarios, 2 jobs, 1 repetition): PASS, 168 batch records.
- Full BSDS500 development run on the user's computer: **not yet executed**.
