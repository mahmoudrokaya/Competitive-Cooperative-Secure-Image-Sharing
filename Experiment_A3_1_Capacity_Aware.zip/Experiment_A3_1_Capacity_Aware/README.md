# Experiment A3.1 — Capacity-Aware Multipath Recovery

## Purpose
A development-stage follow-up to A3.1's predecessor (A3), testing event-driven fragment-slot release, waiting for capacity, threshold-aware recovery, observed path failures, and traceable assistance/reassignment under matched scenarios. This is **not** a complete distributed protocol or physical-network benchmark.

## Files
- `40_A3_1_capacity_aware.py` — primary experiment script
- `33_expanded_baseline.py`, `34_multipath_loss_simulator.py`, `35_packet_recovery.py` — existing source protection/transport modules
- `requirements.txt` — Python dependencies

## Installation and PowerShell execution

Extract this folder into `D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code`.

```powershell
cd "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Experiment_A3_1_Capacity_Aware"
python -m pip install -r requirements.txt
python .\40_A3_1_capacity_aware.py --self-test
python .\40_A3_1_capacity_aware.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A3_1" `
  --max-images 2 `
  --repeats 3 `
  --jobs 4
```

The default run has 4 development images × 7 scenarios × 3 repetitions × 2 methods × 6 modes = **1008 batch records** (4032 jobs). Only BSDS500 `train` and `val` are loaded. Test and other datasets are excluded.

## Output files
- `A31_00_manifest.csv`: selected images and SHA-256 hashes
- `A31_01_runs.csv`: batch metrics, capacity and intervention counters
- `A31_02_event_traces.csv`: request/commit/release/intervention/threshold events
- `A31_03_summary.csv`: per-method/per-mode aggregates
- `A31_04_metadata.json`: parameters and scientific limitations

## Important interpretation limitations

1. Capacity means simultaneous fragment-transmission slots, not CPU processing capacity. Queued requests wait for an available slot; this is an idealized event queue, not a validated queueing network.
2. Failure is observed only at the configured timestamp. A transmission ending after failure on the failed path is considered lost. The failure does not retroactively invalidate a completed transmission.
3. Both assistance and reassignment use the same packet transport. They are labeled interventions; distinct real-world protocols, agent bidding messages, and durable ownership transfer are not established by these results.
4. Packet-loss draws for equivalent actions use stable scenario/image/job/fragment/path seeds, but different interventions have distinct random draws.
5. AES-GCM confidentiality assumes uncompromised keys; exposure counters do not establish information-theoretic secrecy.
6. The static baseline obeys the same capacity limits as adaptive configurations.
7. The simulator records timeout-censored completion times; unsuccessful jobs contribute the timeout value.
8. Do not claim A3.1 proves the complete joint optimizer or physical-network performance.

## Acceptance checks before Experiment B
- All 1008 combinations exist, and the manifest contains no test images.
- `reservation_leaks`, `capacity_violations` and `ownership_conflicts` are zero.
- Event traces show paired `commit_*` and `release_*` records.
- Under contention, queued requests eventually proceed (or are explicitly rejected with a reason).
- Multipath threshold recovery is evaluated using *distinct fragment IDs*, not total packet count.
- Review method-specific scenario tables, especially path failure and contention, rather than relying on pooled means.
