#!/usr/bin/env python3
"""C4 exploratory HHO search on measured C3.1 finite candidate grid.
IMPORTANT: six provisional objectives are NOT the manuscript's J1-J6 definitions.
No new packet simulation or continuous allocation; all fitness is TRAIN-only.
"""
import argparse, json, math, hashlib, csv
from pathlib import Path
import numpy as np
import pandas as pd

METHODS=['AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3']
MODES=['static','bidding_ownership_assist','bidding_ownership_reassign','full']
POLICIES=['arq','fec_arq']

def grid_id(x):
    z=np.clip(np.rint(x).astype(int),[0,0,0],[1,3,1])
    return 'C%03d'%(1+(z[0]*4+z[1])*2+z[2])

def safe_write(path,records):
    pd.DataFrame(records).to_csv(path,index=False)

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def hawks(fitness,seed,pop=12,iterations=40):
    """Continuous Harris Hawks Optimization positions, rounded to 2x4x2 discrete grid.
    Uses exploration, soft/hard besiege, and progressive rapid dives with Levy steps.
    Returns best visited configuration, trace, and evaluation count.
    """
    rng=np.random.default_rng(seed);lo=np.zeros(3);hi=np.array([1.,3.,1.]);
    X=rng.uniform(lo,hi,size=(pop,3));best=None;bestfit=float('inf');trace=[];calls=0
    def evaluate(v):
        nonlocal best,bestfit,calls
        v=np.clip(v,lo,hi);f=fitness(grid_id(v));calls+=1
        if f<bestfit-1e-14:
            bestfit=f;best=v.copy()
        return f
    for x in X:evaluate(x)
    for t in range(iterations):
        rabbit=best.copy(); E1=2*(1-(t+1)/iterations)
        avg=X.mean(axis=0)
        for i in range(pop):
            x=X[i].copy();E0=rng.uniform(-1,1);E=E1*E0;q=rng.random();r=rng.random();J=2*(1-rng.random())
            if abs(E)>=1:
                if q<.5:
                    peer=X[rng.integers(pop)];new=peer-rng.random(3)*abs(peer-2*rng.random(3)*x)
                else:new=(rabbit-avg)-rng.random(3)*(lo+rng.random(3)*(hi-lo))
            elif r>=.5:
                new=rabbit-E*abs(J*rabbit-x) if abs(E)>=.5 else rabbit-E*abs(rabbit-x)
            else:
                base=rabbit-E*abs(J*rabbit-x) if abs(E)>=.5 else rabbit-E*abs(J*rabbit-avg)
                base=np.clip(base,lo,hi)
                if evaluate(base)<fitness(grid_id(x)):
                    new=base
                else:
                    beta=1.5; sigma=(math.gamma(1+beta)*math.sin(math.pi*beta/2)/(math.gamma((1+beta)/2)*beta*2**((beta-1)/2)))**(1/beta)
                    levy=(rng.normal(0,sigma,3)/(abs(rng.normal(0,1,3))**(1/beta)+1e-12))
                    dive=np.clip(base+rng.normal(0,1,3)*levy*.01,lo,hi)
                    new=dive if evaluate(dive)<fitness(grid_id(x)) else x
            X[i]=np.clip(new,lo,hi);evaluate(X[i])
        trace.append(dict(iteration=t+1,best_candidate=grid_id(best),best_loss=bestfit,evaluations=calls))
    return grid_id(best),bestfit,trace,calls

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True,help='Directory containing C3_01_candidates.csv and C3_03_aggregate.csv')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--runs',type=int,default=30);p.add_argument('--population',type=int,default=12);p.add_argument('--iterations',type=int,default=40);p.add_argument('--seed',type=int,default=4701)
    p.add_argument('--max-wire',type=float,default=2.5);p.add_argument('--max-time-ms',type=float,default=3000)
    p.add_argument('--weights',type=float,nargs=6,default=[.65,.20,.15,0.,0.,0.],help='provisional weights: failure, latency, wire, violations, mode complexity, redundancy')
    a=p.parse_args()
    if a.runs<1 or a.population<2 or a.iterations<1 or a.max_wire<=0 or a.max_time_ms<=0 or min(a.weights)<0 or sum(a.weights)<=0:p.error('Invalid numeric arguments')
    a.out.mkdir(parents=True,exist_ok=True)
    cand=pd.read_csv(a.input/'C3_01_candidates.csv');agg=pd.read_csv(a.input/'C3_03_aggregate.csv')
    expected={f'C{i:03}' for i in range(1,17)}
    if set(cand.candidate_id)!=expected or len(cand)!=16:raise ValueError('Expected exactly the 16 canonical C3 candidates')
    for _,r in cand.iterrows():
        idx=1+(METHODS.index(r['method'])*4+MODES.index(r['mode']))*2+POLICIES.index(r['policy'])
        if r['candidate_id']!=f'C{idx:03}':raise ValueError('Candidate mapping does not match C3 order')
    needed=['split','scenario','candidate_id','success_rate','wire_ratio','censored_ms','capacity_violations','ownership_conflicts','reservation_leaks','exposure_violations']
    if agg.duplicated(['split','scenario','candidate_id']).any():raise ValueError('Duplicate aggregate keys')
    if agg[needed].isnull().any().any():raise ValueError('Missing aggregate values')
    if set(agg.split)!={'train','val'}:raise ValueError('Expected train and val splits')
    scenarios=sorted(agg.scenario.unique());weights=np.array(a.weights)/sum(a.weights)
    objective=[];selected=[];traces=[];restarts=[];comparison=[]
    for sc in scenarios:
        train=agg[(agg.split=='train')&(agg.scenario==sc)].set_index('candidate_id')
        val=agg[(agg.split=='val')&(agg.scenario==sc)].set_index('candidate_id')
        if set(train.index)!=expected or set(val.index)!=expected:raise ValueError('Incomplete candidate grid for '+sc)
        costs={}
        for cid,row in train.iterrows():
            c=cand.set_index('candidate_id').loc[cid]
            # J4 measured integrity violation count, zero in prior runs; J5/J6 structural proxies.
            violation=sum(float(row[k]) for k in ['capacity_violations','ownership_conflicts','reservation_leaks','exposure_violations'])
            mode_complexity={'static':0.,'bidding_ownership_assist':.5,'bidding_ownership_reassign':.5,'full':1.}[c['mode']]
            redundancy=float(c['method']=='AESGCM_XOR_Erasure_2of3')*.5+float(c['policy']=='fec_arq')*.5
            j=np.array([1-float(row.success_rate),float(row.censored_ms)/a.max_time_ms,float(row.wire_ratio)/a.max_wire, min(violation,1),mode_complexity,redundancy])
            feasible=(float(row.wire_ratio)<=a.max_wire and float(row.censored_ms)<=a.max_time_ms and violation==0)
            loss=float(weights@j) if feasible else 1e6+float(weights@j)
            costs[cid]=loss
            objective.append(dict(scenario=sc,candidate_id=cid,**{f'P{i+1}':float(v) for i,v in enumerate(j)},feasible=int(feasible),weighted_loss=loss))
        oracle=min(costs,key=lambda c:(costs[c],int(c[1:])))
        for k in range(a.runs):
            cid,loss,trace,calls=hawks(lambda key:costs[key],a.seed+10000*scenarios.index(sc)+k,a.population,a.iterations)
            restarts.append(dict(scenario=sc,run=k+1,seed=a.seed+10000*scenarios.index(sc)+k,selected_id=cid,loss=loss,oracle_id=oracle,oracle_loss=costs[oracle],oracle_match=int(abs(loss-costs[oracle])<1e-12),fitness_evaluations=calls))
            for v in trace:traces.append(dict(scenario=sc,run=k+1,**v))
        # Choose best restart based on training fitness only.
        best=min((r for r in restarts if r['scenario']==sc),key=lambda r:(r['loss'],int(r['selected_id'][1:])))
        cid=best['selected_id'];selected.append(dict(scenario=sc,hho_selected=cid,exhaustive_oracle=oracle,matched_oracle=int(abs(costs[cid]-costs[oracle])<1e-12),train_hho_loss=costs[cid],train_oracle_loss=costs[oracle],restart_success_rate=sum(r['oracle_match'] for r in restarts if r['scenario']==sc)/a.runs))
        for metric in ['success_rate','wire_ratio','censored_ms']:
            v=float(val.loc[cid,metric]);b=float(val.loc['C002',metric]);o=float(val.loc[oracle,metric])
            comparison.append(dict(scenario=sc,metric=metric,hho_id=cid,baseline_id='C002',oracle_id=oracle,hho_validation=v,baseline_validation=b,oracle_validation=o,hho_minus_baseline=v-b))
    safe_write(a.out/'C4_00_provisional_objectives.csv',objective)
    safe_write(a.out/'C4_01_hho_restarts.csv',restarts)
    safe_write(a.out/'C4_02_convergence.csv',traces)
    safe_write(a.out/'C4_03_train_selected.csv',selected)
    safe_write(a.out/'C4_04_validation_descriptive.csv',comparison)
    meta={'status':'exploratory_discrete_HHO_on_existing_C3_grid','not_formal_manuscript_J1_J6':True,'not_new_joint_allocation':True,'not_new_simulations':True,'fitness_split':'train only','validation':'descriptive only, not used for selection','objectives':['P1 failure rate (measured)','P2 normalized censored completion time (measured)','P3 normalized wire ratio (measured)','P4 any simulator integrity violation (measured)','P5 organizational mode complexity (structural proxy, NOT measured cost)','P6 redundancy complexity (structural proxy, NOT measured cost)'],'weights_normalized':weights.tolist(),'constraints':{'max_wire':a.max_wire,'max_time_ms':a.max_time_ms,'zero_integrity_violations':True},'seed':a.seed,'runs':a.runs,'population':a.population,'iterations':a.iterations,'inputs_sha256':{f:sha(a.input/f) for f in ['C3_01_candidates.csv','C3_03_aggregate.csv']},'limitations':['Requires author-confirmed mathematical J1-J6 definitions before labeling as formal implementation','Discrete rounded HHO search on 16 previously evaluated configurations, not continuous path allocation or fresh packet simulation','Exhaustive oracle over 16 configurations is exact and should be preferred for this small grid','Validation is previously examined development validation, not new independent evidence','Packet policies may change random loss traces','Mode and redundancy complexity are transparent proxies, not empirical measurements']}
    (a.out/'C4_05_methodology.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps({'status':'COMPLETE','selected':selected,'out':str(a.out)},indent=2))
if __name__=='__main__':main()
