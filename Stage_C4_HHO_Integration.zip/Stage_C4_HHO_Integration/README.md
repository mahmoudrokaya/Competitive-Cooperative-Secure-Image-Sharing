# Stage C4 — exploratory HHO integration (NOT the formal manuscript J1–J6 optimizer)

This reproducible implementation applies a continuous-position Harris Hawks Optimization (HHO) search, discretized to the **16 measured C3.1 candidate configurations**. It compares HHO with an exact exhaustive-search oracle and uses **training results only** for fitness and selection. It does not run new network simulations. The validation results are displayed descriptively, never used in selection. The BSDS500 test and USC-SIPI external images are not accessed.

## Inputs

Copy these two files from your Stage_C3_1_Full results into the same folder:
- `C3_01_candidates.csv`
- `C3_03_aggregate.csv`

## Windows PowerShell

```powershell
python -m pip install -r .\requirements.txt
python .\47_C4_hho_grid_integration.py `
  --input "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C3_1_Full" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C4" `
  --runs 30 --population 12 --iterations 40 --seed 4701
```

The C4 script can reside in any folder; it requires only the two CSV inputs. No A3.1 simulator files or raw image data are needed.

## Outputs

- `C4_00_provisional_objectives.csv`: all 16 configurations and six provisional normalized objectives, feasibility, and loss.
- `C4_01_hho_restarts.csv`: each independent HHO restart, exact exhaustive optimum and optimal-fitness match.
- `C4_02_convergence.csv`: best-so-far objective at each iteration.
- `C4_03_train_selected.csv`: scenario-specific best HHO selection and exact oracle.
- `C4_04_validation_descriptive.csv`: pre-existing validation results for selected, baseline, and oracle configurations (not a new test).
- `C4_05_methodology.json`: precise methods, input hashes and limitations.

## Scientific limitations

**This is not the full formal J1–J6 optimizer.** The author's exact J1–J6 equations and variable/constraint definitions have not been supplied. P1–P4 are measured; P5 and P6 are transparent complexity proxies and **not independently measured resource or security metrics**. Default weights `[0.65, 0.20, 0.15, 0, 0, 0]` intentionally assign zero weight to unsupported complexity proxies. The HHO searches discrete method/mode/policy combinations only; it does not optimize packet-level path allocation, cryptographic parameters, or physical-network scheduling. The loss landscape has only 16 candidates, so exhaustive search is a more efficient exact solver. Do not present HHO convergence as superiority over exhaustive search or present these results as independent held-out evaluation. Distinct candidate IDs can have identical optimum objective values; use `matched_oracle` for fitness equivalence, not ID equality.

Before implementing manuscript J1–J6, supply their six mathematical definitions, variables, constraints and required measurements.
