import importlib.util,unittest
from pathlib import Path
p=Path(__file__).with_name('49_C4_2_instrumented_simulator.py')
s=importlib.util.spec_from_file_location('sim',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
D={'method':'AES128_GCM_PSK','mode':'static','allocation':'[1,0,0]','fec_parity':'0','arq_limit':'1','assistance':'0','reassignment':'0'}
class Tests(unittest.TestCase):
 def test_reproducibility(self):self.assertEqual(m.simulate(D,'iid_0.10',10),m.simulate(D,'iid_0.10',10))
 def test_j4_unmeasured(self):self.assertIsNone(m.simulate(D,'iid_0.10',10)['J4_security_risk'])
 def test_path_allocation_changes_load(self):
  d=dict(D,allocation='[0.5,0.5,0]');self.assertNotEqual(m.simulate(D,'iid_0.10',10)['path_loads'],m.simulate(d,'iid_0.10',10)['path_loads'])
 def test_retries_change_traffic(self):
  d=dict(D,arq_limit='0');a=m.simulate(D,'path_failure',8);b=m.simulate(d,'path_failure',8);self.assertGreaterEqual(a['wire_packets'],b['wire_packets'])
 def test_invalid_scenario(self):
  with self.assertRaises(ValueError):m.simulate(D,'bad',10)
if __name__=='__main__':unittest.main()
