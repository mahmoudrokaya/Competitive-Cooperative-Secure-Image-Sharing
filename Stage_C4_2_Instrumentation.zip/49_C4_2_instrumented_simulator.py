#!/usr/bin/env python3
"""C4.2 independently implemented, explicitly synthetic instrumented reference model.
NOT a modification or validation of the original A3.1 simulator.
"""
import argparse,csv,hashlib,json,math,random
from pathlib import Path

def simulate(d, scenario, seed, capacity=(1.0,0.8,0.6), timeout_ms=3000.0):
    """One reproducible job; simplified packet/queue model, not physical network."""
    rng=random.Random(seed)
    a=json.loads(d['allocation']) if isinstance(d['allocation'],str) else d['allocation']
    active=[i for i,v in enumerate(a) if v>1e-9]
    if not active: raise ValueError('no active paths')
    for i in active:
        if capacity[i]<=0: raise ValueError('active path with zero capacity')
    n=24  # fixed number of payload chunks
    parity=int(d['fec_parity']); retries=int(d['arq_limit'])
    mode=d['mode']; multi=d['method']=='AESGCM_XOR_Erasure_2of3'
    # Explicit assumptions: 2-of-3 block-level erasure recovery approximated by one extra parity chunk.
    # No cryptographic confidentiality inference is made from this model.
    extra=parity+(1 if multi else 0)
    packets=n+extra
    weights=[a[i] for i in active]
    assignments=rng.choices(active,weights=weights,k=packets)
    wire=0; completed=0; elapsed=0.; control_messages=0; handoffs=0
    delivered=[]; per_path=[0]*3; attempts=[0]*3; losses=[0]*3
    for j,p in enumerate(assignments):
        ok=False
        for k in range(retries+1):
            q=p
            if k and d['reassignment']=='1' or (k and d['reassignment']==1):
                q=max(active,key=lambda t:capacity[t]/(1+attempts[t])); handoffs+=int(q!=p); control_messages+=int(q!=p)*2
            loss={'iid_0.10':0.10,'burst_0.20':0.20,'path_failure':0.04}.get(scenario)
            if loss is None:raise ValueError('unknown scenario')
            if scenario=='path_failure' and q==2:loss=1.0
            if scenario=='burst_0.20' and (j//5)%3==1:loss=0.65
            if d['assistance'] in ('1',1):
                control_messages+=1
                loss=max(0.0,loss-0.015) # modeled assistance gain, not empirical
            attempts[q]+=1; per_path[q]+=1; wire+=1
            elapsed+=4.0+3.0/capacity[q]+1.0*max(0,attempts[q]-1)/capacity[q]
            if rng.random()>=loss:
                ok=True;break
            losses[q]+=1
        delivered.append(ok)
    # Toy decoding rule; not an implementation of an erasure codec.
    successes=sum(delivered)
    recovered=successes>=n
    # Aggregate offered load, and capacity feasibility as explicit model checks.
    utilization=[per_path[i]/(max(1,packets)*capacity[i]) for i in active]
    mean=sum(utilization)/len(utilization)
    imbalance=sum((u-mean)**2 for u in utilization)/len(utilization)
    capacity_violation=int(any(u>1.5 for u in utilization))
    completion=min(elapsed,timeout_ms)
    # Security is not measurable from this toy transport. Return null, never a zero risk.
    return {'success':int(recovered),'censored_time_ms':round(completion,6),
            'wire_ratio':round(wire/n,6),'payload_packets':n,'wire_packets':wire,
            'integrity_violations':0,'capacity_violation':capacity_violation,
            'control_messages':control_messages,'handoffs':handoffs,
            'path_loads':per_path,'path_attempts':attempts,'path_losses':losses,
            'imbalance':round(imbalance,8),'J1_failure':int(not recovered),
            'J2_time_normalized':round(completion/timeout_ms,8),
            'J3_wire_ratio':round(wire/n,8),'J4_security_risk':None,
            'J5_control_messages_per_payload':round(control_messages/n,8),
            'J6_load_imbalance':round(imbalance,8)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--decisions',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--repeats',type=int,default=3);ap.add_argument('--seed',type=int,default=4901)
    ap.add_argument('--limit',type=int,default=0,help='0 means all feasible decisions')
    args=ap.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    with open(args.decisions,newline='',encoding='utf-8-sig') as f:
        rows=[r for r in csv.DictReader(f) if r['feasible']=='1']
    if args.limit:rows=rows[:args.limit]
    results=[]
    for row in rows:
        for scenario in ('iid_0.10','burst_0.20','path_failure'):
            for repeat in range(args.repeats):
                # Same random seed for same scenario/repeat across candidates (partial CRN only).
                seed=int.from_bytes(hashlib.sha256(f'{args.seed}|{scenario}|{repeat}'.encode()).digest()[:8],'big')
                result=simulate(row,scenario,seed)
                results.append({'candidate_id':row['candidate_id'],'scenario':scenario,'repeat':repeat,'seed':seed,**result})
    with (out/'C42_01_runs.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=results[0].keys());w.writeheader()
        for r in results:
            r=r.copy()
            for k in ('path_loads','path_attempts','path_losses'):r[k]=json.dumps(r[k])
            w.writerow(r)
    audit={'stage':'C4.2 reference instrumented simulation','status':'REFERENCE_MODEL_ONLY',
           'original_A3_1_integrated':False,'formal_manuscript_J1_J6_confirmed':False,
           'cryptographic_security_measured':False,'J4_security_risk':'unmeasured_null',
           'jobs':len(results),'candidates':len(rows),'repeats':args.repeats,
           'scenarios':['iid_0.10','burst_0.20','path_failure'],
           'assumptions':['synthetic independent RNG streams seeded by scenario/repeat',
                          'loss model and control effects are illustrative',
                          'toy packet recovery is not cryptographic erasure decoding',
                          'capacity threshold is an illustrative utilization bound',
                          'shared seeds do not guarantee identical packet-level traces across policies'],
           'next_step':'adapt original A3.1 with hooks and validate packet-level equivalence'}
    (out/'C42_00_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
