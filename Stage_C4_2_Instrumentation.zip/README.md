# Stage C4.2 — Instrumented reference simulation (NOT original A3.1 integration)

The original `40_A3_1_capacity_aware.py` source is not included in the accessible inputs. Consequently this package supplies an **independent, illustrative simulator** and instrumentation contract, **not** a patch to the A3.1 experiment or evidence of formal J1–J6 optimization.

## Run

```powershell
python .\49_C4_2_instrumented_simulator.py `
  --decisions "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C4_1\C41_01_decision_space.csv" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C4_2" `
  --repeats 3 --seed 4901
python -m unittest discover -p "test_c42.py" -v
```

`--limit 5` provides a smoke test; omit or use `--limit 0` for all 120 feasible candidates.

## Instrumentation

- J1: empirical failed reconstruction indicator.
- J2: timeout-censored completion time / timeout.
- J3: wire packets / payload packets.
- J4: **NULL** (security is not measured; a zero integrity counter is not a security test).
- J5: modeled coordination/control messages per payload packet.
- J6: modeled per-path utilization variance.

All measures except J4 are outputs of this **synthetic** model. J5/J6 are model measurements, not observations from the original A3.1 implementation. The simulated XOR-erasure recovery is only a toy packet threshold, not an actual codec. No key management, AES-GCM encryption, cryptographic authentication, physical queueing, or real network path is implemented here.

## Integration gate

To perform **genuine A3.1 integration**, provide the original `40_A3_1_capacity_aware.py` and its imports (`33_expanded_baseline.py`, `34_multipath_loss_simulator.py`, `35_packet_recovery.py`). Then instrument original packet events for path selection, parity, retry limits, assistance, reassignment, control messages, per-path load/capacity, security-policy assertions, and shared exogenous loss traces. Compare original defaults against frozen A3.1 baseline to ensure no unintended changes. Do not call C4.2 complete or run formal six-objective HHO until that integration passes.
