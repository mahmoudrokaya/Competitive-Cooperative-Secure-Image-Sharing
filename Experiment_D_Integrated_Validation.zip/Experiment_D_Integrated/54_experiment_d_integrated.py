#!/usr/bin/env python3
"""Experiment D: security-gated A3.1 runtime, adversarial tests, and audit.
The original A3.1 file is never modified. The guarded function is created in memory.
This is a prototype policy enforcement test, NOT proof of Section 2.3 equivalence.
"""
import argparse,csv,hashlib,importlib.util,inspect,json,statistics,textwrap
from collections import Counter,defaultdict
from pathlib import Path
from types import SimpleNamespace
from cryptography.exceptions import InvalidTag
HERE=Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location('d_'+name[:2],HERE/name)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

class SecurityState:
    """Per-job exposure history, monotone across resource releases.
    Threat model: explicitly compromised paths reveal the carried fragment to one adversary.
    This is a *policy constraint*, not a cryptographic secrecy theorem for XOR erasure.
    """
    def __init__(self,eligible=(0,1,2),capacity=2,threshold=2,compromised=()):
        self.eligible=set(eligible);self.capacity={p:int(capacity) for p in range(3)}
        self.threshold=int(threshold);self.compromised=set(compromised)
        self.exposure=defaultdict(set);self.rejected=Counter();self.attempts=0;self.accepted=0
        self.max_exposure=0
    def admit(self,job,sid,path,active,owner=None):
        self.attempts+=1
        if path not in self.eligible: reason='unauthorized_path'
        elif owner is not None:reason='ownership_conflict'
        elif active[path]>=self.capacity[path]:reason='capacity'
        elif path in self.compromised and sid not in self.exposure[job] and len(self.exposure[job])>=self.threshold-1:reason='cumulative_exposure'
        else:
            self.accepted+=1
            if path in self.compromised:self.exposure[job].add(sid)
            self.max_exposure=max(self.max_exposure,len(self.exposure[job]))
            return True
        self.rejected[reason]+=1;return False
    def invariant(self,active=None):
        return all(len(s)<self.threshold for s in self.exposure.values()) and (active is None or all(active[p]<=self.capacity[p] for p in range(3)))

def guarded_execute(a31,guard):
    """Patch *only* the original execute function in memory, before commitment.
    Guard denies forbidden placements; it does not rewrite packet transport or recovery.
    """
    src=textwrap.dedent(inspect.getsource(a31.execute))
    needle="    active[path]+=1;max_active[path]=max(max_active[path],active[path]);committed+=1"
    # Original file uses one-space indentation, preserve indentation from source.
    lines=src.splitlines()
    idx=next(i for i,line in enumerate(lines) if 'active[path]+=1;max_active[path]' in line)
    original=lines[idx];indent=original[:len(original)-len(original.lstrip())]
    injection=[indent+'if not security_guard.admit(j,sid,path,active,ownership.get((j,sid))):',
               indent+" emit(t,j,sid,'security_rejected',path,old,0,detail='admission_denied');continue"]
    lines[idx:idx]=injection
    namespace=dict(a31.__dict__);namespace['security_guard']=guard
    exec(compile('\n'.join(lines)+'\n','<guarded A3.1 execute>','exec'),namespace)
    return namespace['execute']

def arguments(jobs=4,capacity=2,failed_path=1,failure_at_ms=1.0,interventions=3):
    return SimpleNamespace(jobs=jobs,capacity=capacity,contention_capacity=1,policy='arq',mtu=128,header_bytes=20,
      fec_group=4,max_retries=1,failed_path=failed_path,failure_at_ms=failure_at_ms,burst_persist=.85,timeout_ms=3000.,
      detection_ms=80.,queue_penalty_ms=20.,duplicate_path_penalty_ms=10.,max_interventions_per_job=interventions,
      max_events=100000,seed=5401,path_rates=(20.,10.,15.),path_delays=(10.,40.,25.))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=HERE/'Results');args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py');a31=load('40_A3_1_capacity_aware.py')
    data=bytes(range(256))*4;e=dict(split='synthetic',image='synthetic',sha256=hashlib.sha256(data).hexdigest())
    checks=[];runs=[]
    def check(name,ok,scope,detail):checks.append(dict(test=name,passed=int(bool(ok)),scope=scope,detail=str(detail)))
    # Actual cryptographic primitives
    shamir=s33.shamir_2of3_split(data)
    try:s33.shamir_2of3_join({1:shamir[1]});ok=False
    except (ValueError,KeyError):ok=True
    check('insufficient_shamir',ok,'original cryptography','1 of 2 shares rejected')
    enc=s33.encrypted_erasure_split(data)
    try:s33.encrypted_erasure_join(enc[0],(0,));ok=False
    except (ValueError,KeyError):ok=True
    check('insufficient_erasure',ok,'original cryptography','1 of 2 ciphertext fragments rejected; not threshold secrecy')
    (key,nonce,ct),_=s33.aes_encrypt(data)
    for label,bad in [('ciphertext',bytes([ct[0]^1])+ct[1:]),('tag',ct[:-1]+bytes([ct[-1]^1]))]:
        try:s33.AESGCM(key).decrypt(nonce,bad,None);ok=False
        except InvalidTag:ok=True
        check('tampered_'+label,ok,'original cryptography','AES-GCM InvalidTag')
    # Direct adversarial tests of *same guard class* used by patched runtime
    g=SecurityState(eligible=(0,1),capacity=1,threshold=2,compromised=(0,1));active=[0,0,0]
    check('unauthorized_assignment',not g.admit(0,0,2,active),'integrated guard primitive',dict(g.rejected))
    assert g.admit(0,0,0,active);active[0]+=1
    check('capacity_excess',not g.admit(1,0,0,active),'integrated guard primitive',dict(g.rejected))
    check('ownership_conflict',not g.admit(0,0,1,active,owner=0),'integrated guard primitive',dict(g.rejected))
    active[0]-=1
    check('cumulative_exposure',not g.admit(0,1,1,active),'integrated guard primitive',dict(g.rejected))
    check('exposure_persistence',g.exposure[0]=={0},'integrated guard primitive','History retained after release')
    check('reassignment_after_compromise',g.admit(0,0,1,active) and g.exposure[0]=={0},'integrated guard primitive','Same exposed fragment can move without resetting history')
    check('guard_invariant',g.invariant(active),'integrated guard primitive','No threshold or capacity exceedance')
    # Runtime integration: compare original with patched version when no security restrictions
    baseargs=arguments();trace=[]
    original=a31.execute(e,data,'AESGCM_XOR_Erasure_2of3','bidding_ownership_reassign','path_failure',0,baseargs,s33,s34,s35,trace)
    permissive=SecurityState(capacity=baseargs.capacity,threshold=4)
    trace2=[];adapted=guarded_execute(a31,permissive)(e,data,'AESGCM_XOR_Erasure_2of3','bidding_ownership_reassign','path_failure',0,baseargs,s33,s34,s35,trace2)
    keys=('successes','wire_ratio','mean_censored_ms','committed','released','assists','reassignments','failed_fragments')
    check('permissive_runtime_equivalence',all(original[k]==adapted[k] for k in keys),'patched original A3.1', {k:[original[k],adapted[k]] for k in keys})
    # Active guard in real A3.1 event scheduler, including adversarial ineligible paths
    for label,mode,eligible,compromised,cap in [
      ('restricted_eligibility','static',(0,),(),2),
      ('capacity_rejection','static',(0,1,2),(),0),
      ('cumulative_exposure','bidding_ownership_reassign',(0,1,2),(0,1,2),2),
      ('persistent_failure_static','static',(0,1,2),(),2),
      ('persistent_failure_assist','bidding_ownership_assist',(0,1,2),(),2),
      ('persistent_failure_reassign','bidding_ownership_reassign',(0,1,2),(),2),
      ('persistent_failure_full','full',(0,1,2),(),2)]:
        ga=SecurityState(eligible,cap,2,compromised)
        a=arguments(capacity=max(1,cap),failure_at_ms=1.0)
        events=[]
        try:
            r=guarded_execute(a31,ga)(e,data,'AESGCM_XOR_Erasure_2of3',mode,'path_failure',0,a,s33,s34,s35,events)
            valid=(r['committed']==r['released'] and r['capacity_violations']==0 and ga.invariant())
            if label=='restricted_eligibility':valid=valid and ga.rejected['unauthorized_path']>0
            if label=='capacity_rejection':valid=valid and ga.rejected['capacity']>0
            if label=='cumulative_exposure':valid=valid and ga.rejected['cumulative_exposure']>0
            inflight=sum(1 for x in events if x['event'].startswith('commit_') and x['path']==a.failed_path and x['time_ms']<a.failure_at_ms)
            runs.append(dict(test=label,mode=mode,successes=r['successes'],jobs=r['jobs'],assists=r['assists'],reassignments=r['reassignments'],failed_fragments=r['failed_fragments'],committed=r['committed'],released=r['released'],security_rejections=sum(ga.rejected.values()),rejection_detail=json.dumps(ga.rejected),exposure_max=ga.max_exposure,inflight_commit_probes=inflight,capacity_violations=r['capacity_violations'],passed=int(valid)))
            check(label,valid,'security-gated A3.1 runtime',runs[-1])
        except Exception as exc:
            runs.append(dict(test=label,mode=mode,passed=0,error=repr(exc)))
            check(label,False,'security-gated A3.1 runtime',repr(exc))
    # Targeted, demonstrably intervention-triggering in-flight failure: single-fragment AES-GCM.
    # Failure of path 0 at 1 ms disrupts initial static placement; compare controllers.
    targeted={}
    for mode in ('static','bidding_ownership_assist','bidding_ownership_reassign','full'):
        ga=SecurityState(capacity=2,threshold=2)
        a=arguments(failed_path=0,failure_at_ms=1.0)
        events=[]
        r=guarded_execute(a31,ga)(e,data,'AES128_GCM_PSK',mode,'path_failure',0,a,s33,s34,s35,events)
        targeted[mode]=r
        commits=[x for x in events if x['event'].startswith('commit_') and x['path']==0 and x['time_ms']<1.0]
        valid=(len(commits)>0 and r['failed_fragments']>0 and r['committed']==r['released'] and ga.invariant())
        if mode=='bidding_ownership_assist':valid=valid and r['assists']>0 and r['successes']>targeted['static']['successes']
        if mode=='bidding_ownership_reassign':valid=valid and r['reassignments']>0 and r['successes']>targeted['static']['successes']
        if mode=='full':valid=valid and r['assists']+r['reassignments']>0 and r['successes']>targeted['static']['successes']
        runs.append(dict(test='targeted_failure_'+mode,mode=mode,successes=r['successes'],jobs=r['jobs'],assists=r['assists'],reassignments=r['reassignments'],failed_fragments=r['failed_fragments'],committed=r['committed'],released=r['released'],security_rejections=sum(ga.rejected.values()),rejection_detail=json.dumps(ga.rejected),exposure_max=ga.max_exposure,inflight_commit_probes=len(commits),capacity_violations=r['capacity_violations'],passed=int(valid)))
        check('targeted_failure_'+mode,valid,'security-gated A3.1 runtime','AES-GCM path 0 failed at 1ms; '+str(runs[-1]))
    def write_csv(name,records):
        if not records:return
        cols=list(dict.fromkeys(k for row in records for k in row))
        with (args.out/name).open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(records)
    write_csv('D_01_security_validation.csv',checks);write_csv('D_02_integrated_runtime.csv',runs)
    audit=dict(stage='Experiment D integrated A3.1 security admission prototype',tests=len(checks),passed=sum(x['passed'] for x in checks),failed=[x['test'] for x in checks if not x['passed']],
       integrated_runtime_tests=len(runs),runtime_rejections=sum(x.get('security_rejections',0) for x in runs),
       source_sha256=a31.digest(HERE/'40_A3_1_capacity_aware.py'),source_modified_on_disk=False,
       security_mechanism='runtime guard inserted in memory before original A3.1 commitments',
       limitations=['Original A3.1 is not secured unless this guarded execution path is used','Reference threat model treats specified compromised paths as fragment exposure; no adversarial indistinguishability proof','XOR erasure fragments are encrypted ciphertext, not threshold-secret shares','A3.1 is simulated; no deployment, authenticated agent identities or real key management','Exact Section 2.3 constraints not supplied; no claim of formal equivalence','Synthetic probes, not image-dataset estimates','Failure-in-flight proxy does not by itself prove intervention was necessary'])
    (args.out/'D_00_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps(audit,indent=2));return 0 if not audit['failed'] else 1
if __name__=='__main__':raise SystemExit(main())
