# Experiment D — Integrated security admission and failure resilience

## Scope
This package executes original Step33 cryptography and a **security-gated variant** of the original A3.1 `execute` function. The guard is inserted **in memory before resource commitment**, without changing the original source on disk. Tests intentionally submit forbidden assignments and verify rejections. This is an experimental prototype, not a deployed security system.

## Run (Windows PowerShell)
From the extracted `Experiment_D_Integrated` folder:

```powershell
python -m pip install pillow cryptography
python .\54_experiment_d_integrated.py --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_D_Integrated"
```

No BSDS500 dataset is needed: security tests use synthetic bytes to avoid repeating image-based Experiment C. Results are `D_00_audit.json`, `D_01_security_validation.csv`, and `D_02_integrated_runtime.csv`.

## Explicit threat and implementation boundaries
- The security state assumes that a compromised path exposes a fragment to **one cumulative adversary**. Exposure is monotone across releases and reassignments. The exposure limit is a **proposed policy** (`distinct exposed fragment IDs < threshold`), not an independently proven confidentiality bound for encrypted XOR erasure.
- Original AES-GCM operations are exercised. Modified ciphertext and authentication tags must raise `InvalidTag`. XOR-erasure ciphertext fragments do **not** provide Shamir threshold secrecy. AES key management is external.
- Eligibility is modeled at the path level, **not verified agent identities**. Guard checks execute before A3.1 commitment; the unmodified original A3.1 does not enforce them.
- Capacity, ownership, and cumulative exposure are checked using deliberately invalid admission attempts and integrated runtime probes. Runtime guard rejection counters are reported. Original A3.1 has its own capacity queuing logic; the security guard adds a hard rejection policy in the adversarial test.
- Persistent failure uses a forced single-fragment AES-GCM scenario: path 0 fails during an in-flight commitment at 1 ms. Static is compared with assistance, reassignment, and full. This tests intervention necessity rather than assuming any 2-of-3 erasure resilience proves organizational recovery.
- The 23 checks are **synthetic validation tests**, not independent-image estimates. No network deployment, security proof, real credential validation, or formal verification of Section 2.3 is claimed.
- C4.1 decision-space counts (120 structurally feasible / 24 infeasible) remain a **separate structural audit**. This package does not claim integrated-optimizer candidate feasibility counts; it reports guard admission attempts and rejections instead.

## Interpreting output
`D_01_security_validation.csv` contains the pass/fail test table with evidence scope. `D_02_integrated_runtime.csv` contains committed/released, recovery interventions, exposure and rejection counts. Do not equate 0 *post-enforcement* violations with lack of adversarial testing; consult nonzero rejected attempts.
