# Experiment E, Part B — Sensitivity Analysis

This is a reanalysis of the existing Experiment C final validation (`CF_01_runs.csv`). No network simulations are rerun.

## Run on Windows PowerShell

```powershell
python -m pip install pandas numpy
python .\56_experiment_e_sensitivity.py `
  --input "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_E_Inputs\CF_01_runs.csv" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_E_PartB" `
  --bootstrap 2000 `
  --seed 2026
```

## Outputs
- `EB_00_audit.json`: data integrity, statistical design, limitations
- `EB_01_condition_summary.csv`: 96 condition × scenario × mode cells
- `EB_02_ofat_paired_effects.csv`: 864 one-factor-at-a-time contrasts (8 × 2 × 6 × 9)
- `EB_03_mode_paired_effects.csv`: 720 organizational contrasts (8 × 2 × 5 × 9)
- `EB_04_scenario_descriptive.csv`: 48 burst-versus-failure descriptive comparisons

## Interpretation
- Each CSV row of the source is a batch; do not treat jobs as independent trials.
- Paired differences use matching image SHA and repeat, with image-cluster bootstrap CIs.
- Pairing by identity does not establish common random-number streams between modes/conditions.
- Confidence intervals are exploratory (10 validation images; no multiplicity adjustment).
- Failure timing applies meaningfully to `path_failure`, not to burst-loss controls.
- `CF_01_runs.csv` only includes burst_0.20 and path_failure. Independent loss and separate contention scenarios cannot be inferred from this file.
- Comparisons involving changed job counts use per-batch success rates rather than raw successes.
- Completion time is the existing censored-time metric, not success-only latency.
- `EB_03` directly compares `full` and `bidding_ownership_reassign` for each condition/scenario.
