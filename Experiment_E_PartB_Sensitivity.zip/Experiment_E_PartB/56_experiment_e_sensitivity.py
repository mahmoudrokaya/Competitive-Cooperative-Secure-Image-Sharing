#!/usr/bin/env python3
"""Experiment E Part B: observational, OFAT sensitivity reanalysis; no simulations."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

METRICS=['success_rate','mean_censored_ms','wire_ratio','assists','reassignments','failed_fragments','queued_requests','blocked_interventions','inflight_failure_commitments']
MODES=['static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full']
CONTRASTS=[('jobs_8','jobs_4','concurrency 8 vs 4'),('jobs_16','jobs_8','concurrency 16 vs 8'),('jobs_16','jobs_4','concurrency 16 vs 4'),('scarce_slots_16','jobs_16','capacity 1 vs 4'),('budget_0_16','jobs_16','intervention budget 0 vs 3'),('budget_1_16','jobs_16','intervention budget 1 vs 3'),('failure_at_0_16','jobs_16','failure time 0 vs 180 ms'),('failure_at_600_16','jobs_16','failure time 600 vs 180 ms')]
MODE_CONTRASTS=[('full','bidding_ownership_reassign'),('full','bidding_ownership_assist'),('bidding_ownership_reassign','bidding_ownership'),('bidding_ownership_assist','bidding_ownership'),('bidding_ownership','static')]

def bootstrap_paired(a,b,clusters,n,seed):
    diff=np.asarray(a,dtype=float)-np.asarray(b,dtype=float)
    ids,inv=np.unique(np.asarray(clusters),return_inverse=True)
    k=len(ids)
    sums=np.bincount(inv,weights=diff,minlength=k)
    counts=np.bincount(inv,minlength=k)
    rng=np.random.default_rng(seed)
    draws=rng.integers(0,k,size=(n,k))
    bs=sums[draws].sum(axis=1)/counts[draws].sum(axis=1)
    return float(diff.mean()),float(np.quantile(bs,.025)),float(np.quantile(bs,.975)),bool(np.allclose(diff,0,rtol=0,atol=1e-12))

def paired(df,by,target,control,dimension,n,seed):
    out=[]
    for label,group in df.groupby(by,dropna=False):
        if not isinstance(label,tuple):label=(label,)
        a=group[group[dimension]==target];b=group[group[dimension]==control]
        key=['sha256','repeat']
        a=a.set_index(key);b=b.set_index(key)
        if a.index.has_duplicates or b.index.has_duplicates: raise ValueError(f'duplicate pairing keys for {label}: {dimension}')
        idx=a.index.intersection(b.index)
        if len(idx)==0:continue
        for metric in METRICS:
            av=a.loc[idx,metric].to_numpy();bv=b.loc[idx,metric].to_numpy()
            good=np.isfinite(av)&np.isfinite(bv)
            if not good.any():continue
            ids=idx.get_level_values('sha256').to_numpy()[good]
            effect,lo,hi,zero=bootstrap_paired(av[good],bv[good],ids,n,seed)
            row=dict(zip(by,label));row.update(target=target,control=control,metric=metric,paired_batches=int(good.sum()),image_clusters=int(len(set(ids))),difference=effect,ci_low=lo,ci_high=hi,exactly_zero_all_pairs=zero)
            out.append(row)
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,help='CF_01_runs.csv');p.add_argument('--out',required=True);p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--seed',type=int,default=2026)
    args=p.parse_args();src=Path(args.input);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    if args.bootstrap<100:raise ValueError('bootstrap must be >=100')
    df=pd.read_csv(src)
    required=set(METRICS+['condition','scenario','mode','sha256','repeat','jobs','capacity','failure_at_ms','max_interventions_per_job','ownership_conflicts','capacity_violations','reservation_leaks','exposure_violations','committed','released'])
    missing=sorted(required-set(df.columns));
    if missing:raise ValueError(f'missing columns: {missing}')
    df=df[df['split'].eq('val')].copy() if 'split' in df else df.copy()
    if df.duplicated(['sha256','repeat','scenario','condition','mode']).any():raise ValueError('nonunique batch identifiers')
    if not df['success_rate'].between(0,1).all():raise ValueError('invalid success rate')
    summaries=[]
    for (condition,scenario,mode),g in df.groupby(['condition','scenario','mode']):
        d={'condition':condition,'scenario':scenario,'mode':mode,'batches':len(g),'images':g.sha256.nunique(),'jobs':int(g.jobs.sum()),'successes':int(g.successes.sum()),'success_rate':float(g.successes.sum()/g.jobs.sum()),'capacity_violations':int(g.capacity_violations.sum()),'ownership_conflicts':int(g.ownership_conflicts.sum()),'reservation_leaks':int(g.reservation_leaks.sum()),'exposure_violations':int(g.exposure_violations.sum())}
        for metric in METRICS[1:]:d[metric+'_mean_per_batch']=float(g[metric].mean())
        summaries.append(d)
    pd.DataFrame(summaries).to_csv(out/'EB_01_condition_summary.csv',index=False)
    sensitivity=[]
    for target,control,label in CONTRASTS:
        subset=df[df.condition.isin([target,control])].copy()
        rows=paired(subset,['scenario','mode'],target,control,'condition',args.bootstrap,args.seed)
        for r in rows:r['contrast_label']=label
        sensitivity+=rows
    pd.DataFrame(sensitivity).to_csv(out/'EB_02_ofat_paired_effects.csv',index=False)
    modes=[]
    for target,control in MODE_CONTRASTS:
        subset=df[df['mode'].isin([target,control])]
        modes+=paired(subset,['condition','scenario'],target,control,'mode',args.bootstrap,args.seed)
    pd.DataFrame(modes).to_csv(out/'EB_03_mode_paired_effects.csv',index=False)
    # Scenario comparison is descriptive only: scenario-specific random streams not proven matched.
    scen=[]
    for (condition,mode),g in df.groupby(['condition','mode']):
        x=g[g.scenario.eq('burst_0.20')];y=g[g.scenario.eq('path_failure')]
        if x.empty or y.empty:continue
        scen.append({'condition':condition,'mode':mode,'burst_success':x.successes.sum()/x.jobs.sum(),'path_failure_success':y.successes.sum()/y.jobs.sum(),'burst_minus_failure_pp':100*(x.successes.sum()/x.jobs.sum()-y.successes.sum()/y.jobs.sum()),'burst_censored_ms':x.mean_censored_ms.mean(),'failure_censored_ms':y.mean_censored_ms.mean(),'burst_wire_ratio':x.wire_ratio.mean(),'failure_wire_ratio':y.wire_ratio.mean(),'interpretation':'descriptive; scenarios not established as paired common-random-number trials'})
    pd.DataFrame(scen).to_csv(out/'EB_04_scenario_descriptive.csv',index=False)
    audit={'stage':'Experiment E Part B — existing-data sensitivity analysis','input':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'rows':len(df),'images':df.sha256.nunique(),'conditions':sorted(df.condition.unique().tolist()),'scenarios':sorted(df.scenario.unique().tolist()),'modes':sorted(df['mode'].unique().tolist()),'bootstrap_draws':args.bootstrap,'statistical_unit':'one complete batch (jobs within batch not independent)','bootstrap_clusters':'image SHA; preserve repeat-level matched batches','paired_key':['sha256','repeat','scenario','mode for condition contrasts; condition for mode contrasts'],'summary_rows':len(summaries),'ofat_rows':len(sensitivity),'mode_rows':len(modes),'scenario_rows':len(scen),'limitations':['Observational one-factor-at-a-time comparisons within the existing validation experiment; no new simulations','Only burst_0.20 and path_failure available in CF; iid and contention-specific sensitivity require other source records','10 validation images: bootstrap intervals are exploratory and potentially unstable','No common random numbers guaranteed between conditions/modes; pairing matches batch identities, not stochastic realizations','No multiplicity correction; do not interpret individual 95% intervals as confirmatory significance','Failure timing is relevant primarily to path_failure; burst rows are negative controls, not evidence of failure-timing response','A zero intervention budget can yield zero activation by construction; compare actual event counts','Different concurrency means success_rate is normalized per batch, not raw successful-job counts','Full vs reassignment can differ by condition; report observed zero differences as such','Capacity/resource effects are conditional on this simulator, not factorial interactions']}
    (out/'EB_00_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(out),'rows':len(df),'summary':len(summaries),'ofat':len(sensitivity),'mode':len(modes),'scenario':len(scen)},indent=2))
if __name__=='__main__':main()
