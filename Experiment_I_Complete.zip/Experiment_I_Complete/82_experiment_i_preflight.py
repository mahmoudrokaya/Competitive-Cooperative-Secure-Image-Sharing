#!/usr/bin/env python3
"""Fast validation of source, locked settings, and local simulation interfaces."""
import importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
cfg=json.loads((HERE/'experiment_i_config.json').read_text())
assert cfg['evaluation_locked'] and cfg['partition']=='test'
assert cfg['max_test_images']==0 and cfg['repeats']>0
assert cfg['modes']==[0,1,2,4,8,15]
assert len(set(cfg['modes']))==len(cfg['modes'])
for file in ('33_expanded_baseline.py','34_multipath_loss_simulator.py','35_packet_recovery.py','70_h_security.py','71_h_guarded_simulator.py','h_security.py'):
 assert (HERE/file).is_file(),file
spec=importlib.util.spec_from_file_location('crypto',HERE/'33_expanded_baseline.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.selftest()
print('PREFLIGHT PASS: locked settings, source files, cryptographic selftest. Holdout overlap validation runs with --preflight-only.')
