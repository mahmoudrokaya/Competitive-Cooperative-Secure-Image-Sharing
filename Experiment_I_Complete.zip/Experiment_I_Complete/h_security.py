from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
p=Path(__file__).with_name('70_h_security.py');s=spec_from_file_location('h_guard',p);m=module_from_spec(s);s.loader.exec_module(m)
Monitor=m.Monitor
