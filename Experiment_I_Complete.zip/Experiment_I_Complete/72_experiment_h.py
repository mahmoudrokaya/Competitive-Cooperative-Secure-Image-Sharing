#!/usr/bin/env python3
"""Integrated security and commitment validation in the real G event scheduler.
Preflight is mandatory; run --mode preflight or --mode full. No source patching.
"""
import argparse,csv,hashlib,importlib.util,json,platform,sys
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
from h_security import Monitor
import h_guarded_simulator as sim
HERE=Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location(name[:2],HERE/name);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def args_for(cfg):
    a=SimpleNamespace(**cfg)
    a.path_rates=tuple(cfg['path_rates']);a.path_delays=tuple(cfg['path_delays'])
    a.path_caps=tuple(cfg['path_caps']);a.agent_caps=tuple(cfg['agent_caps'])
    a.eligibility={int(k):tuple(v) for k,v in cfg['eligibility'].items()}
    a.compromised=tuple(cfg['compromised'])
    a.capacity=min(a.path_caps);a.contention_capacity=min(a.path_caps)
    return a

def save_csv(path,rows):
    if not rows:return
    cols=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(rows)

def preflight(cfg,s33,s34,s35):
    tests=[]
    def check(name,condition,details=''):
        tests.append(dict(test=name,passed=int(bool(condition)),details=str(details)))
        if not condition:raise AssertionError(name+': '+str(details))
    s33.selftest()
    m=Monitor([1,1,1],[1,1,1],{0:(0,),1:(1,),2:(2,)},(0,1),2,1)
    check('reject_unauthorized',not m.admit(0,0,1,0,'initial',0))
    check('admit_initial',m.admit(0,0,0,0,'initial',0))
    check('reject_duplicate_owner',not m.admit(0,0,0,0,'initial',0))
    check('reject_path_capacity',not m.admit(1,0,0,0,'initial',0))
    check('reject_agent_capacity',not m.admit(1,0,0,0,'initial',0))
    m.release(0,0,0,0)
    check('exposure_survives_release',m.exposed[0]=={0})
    check('reject_cumulative_exposure',not m.admit(0,1,1,1,'initial',1))
    check('allow_same_exposed_fragment',m.admit(0,0,1,1,'assist',2))
    m.release(0,0,1,1)
    check('reject_budget',not m.admit(0,0,1,1,'assist',3))
    check('final_balanced',m.final())
    # Functional actual simulator: two methods, 16 modes, 7 scenarios, active guard.
    cfg2=dict(cfg);cfg2.update(path_caps=[2,2,2],agent_caps=[2,2,2],eligibility={'0':[0,1,2],'1':[0,1,2],'2':[0,1,2]},compromised=[],exposure_threshold=2,max_interventions_per_job=3)
    a=args_for(cfg2)
    rgb=bytes(range(256))*4;entry={'split':'synthetic','image':'synthetic','sha256':hashlib.sha256(rgb).hexdigest()}
    runs=[];events=[]
    for method in ('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3'):
      for mode in range(16):
       for scenario in ('iid_0.01','path_failure','contention'):
        trace=[]
        r=sim.execute(entry,rgb,method,mode,scenario,0,a,s33,s34,s35,trace)
        audit=r.pop('security_audit');runs.append(r);events.extend(trace)
        check(f'actual_scheduler_{method}_{mode}_{scenario}',r['committed']==r['released'] and not r['capacity_violations'] and not r['exposure_violations'],r)
    check('all_16_modes',len({r['mode'] for r in runs})==16)
    # Targeted adversarial runtime: every path compromised => at most k-1 distinct fragments per job.
    for method in ('AESGCM_XOR_Erasure_2of3',):
      c=dict(cfg2);c['compromised']=[0,1,2];c['exposure_threshold']=2
      a=args_for(c);trace=[]
      r=sim.execute(entry,rgb,method,15,'iid_0.01',0,a,s33,s34,s35,trace)
      check('runtime_exposure_guard',r['rejected_exposure']>0 and r['max_cumulative_exposure']<2,r)
    # Capacity rejection in runtime: path0 has zero slots, must reject before transport.
    c=dict(cfg2);c['path_caps']=[0,2,2];a=args_for(c);trace=[]
    r=sim.execute(entry,rgb,'AES128_GCM_PSK',0,'iid_0.01',0,a,s33,s34,s35,trace)
    check('runtime_capacity_guard',r['rejected_capacity']>0,r)
    # Unauthorized path in runtime.
    c=dict(cfg2);c['eligibility']={'0':[1,2],'1':[1,2],'2':[1,2]};a=args_for(c);trace=[]
    r=sim.execute(entry,rgb,'AES128_GCM_PSK',0,'iid_0.01',0,a,s33,s34,s35,trace)
    check('runtime_eligibility_guard',r['rejected_unauthorized']>0,r)
    return tests,runs

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('preflight','full'),default='preflight')
    p.add_argument('--config',type=Path,default=HERE/'experiment_h_config.json');p.add_argument('--data',type=Path)
    p.add_argument('--out',type=Path,default=HERE/'Results');o=p.parse_args()
    cfg=json.loads(o.config.read_text(encoding='utf-8'));o.out.mkdir(parents=True,exist_ok=True)
    s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py')
    tests,smoke=preflight(cfg,s33,s34,s35)
    save_csv(o.out/'H_00_preflight.csv',tests)
    if o.mode=='preflight':print('PREFLIGHT PASS',len(tests),'checks');return
    if o.data is None:raise ValueError('--data required for full run')
    entries=sim.manifest(o.data,int(cfg['max_images_per_split']))
    save_csv(o.out/'H_01_manifest.csv',entries)
    a=args_for(cfg);runs=[];events=[];audits=[]
    for e in entries:
      fp=o.data/e['relative_path']
      if sim.digest(fp)!=e['sha256']:raise RuntimeError('Image changed')
      with Image.open(fp) as im:rgb=im.convert('RGB').tobytes()
      for method in cfg['methods']:
       for sc in cfg['scenarios']:
        for rep in range(int(cfg['repeats'])):
         for mode in cfg['modes']:
          trace=[];r=sim.execute(e,rgb,method,int(mode),sc,rep,a,s33,s34,s35,trace)
          audit=r.pop('security_audit');runs.append(r)
          for item in trace:item.update(split=e['split']);events.append(item)
          for item in audit:item.update(image=e['image'],sha256=e['sha256'],method=method,mode=mode,scenario=sc,repeat=rep);audits.append(item)
      print(e['image'],'complete',flush=True)
    save_csv(o.out/'H_02_runs.csv',runs);save_csv(o.out/'H_03_events.csv',events);save_csv(o.out/'H_04_security_admissions.csv',audits)
    assert all(r['committed']==r['released'] and r['capacity_violations']==0 and r['exposure_violations']==0 for r in runs)
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in HERE.glob('*.py')}
    (o.out/'H_05_metadata.json').write_text(json.dumps(dict(config=cfg,rows=len(runs),images=len(entries),events=len(events),admissions=len(audits),preflight=len(tests),python=sys.version,platform=platform.platform(),source_sha256=hashes,limitations=['Policy security only, not formal cryptographic security','Actual simulated event scheduler instrumented; not physical distributed implementation','No live key distribution or network sockets','Denied requests can reduce liveness','Compromised paths are assumed known for configured threat model','Shared assistance/reassignment transport primitive','Failed packet transmissions are simulated deterministically']),indent=2),encoding='utf-8')
    print('COMPLETE',len(runs),'runs',len(audits),'security decisions')
if __name__=='__main__':main()
