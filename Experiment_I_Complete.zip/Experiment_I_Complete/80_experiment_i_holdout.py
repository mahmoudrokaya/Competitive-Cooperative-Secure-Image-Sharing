#!/usr/bin/env python3
"""Locked holdout evaluation using the guarded H event simulator. No tuning."""
import argparse,csv,hashlib,importlib.util,json,platform,sys,time
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
HERE=Path(__file__).resolve().parent

def load(filename):
 spec=importlib.util.spec_from_file_location('module_'+filename[:2],HERE/filename);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def rows(p):
 with p.open(newline='',encoding='utf-8-sig') as f:yield from csv.DictReader(f)

def manifest(data,previous,max_images):
 test=data/'BSR'/'BSDS500'/'data'/'images'/'test'
 if not test.is_dir():raise FileNotFoundError(f'Holdout partition not found: {test}')
 files=sorted(p for p in test.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png'))
 if max_images>0:files=files[:max_images]
 if not files:raise ValueError('Empty holdout')
 known_hashes=set();known_names=set();references=[]
 for f in previous:
  if not f.is_file():raise FileNotFoundError(f'Missing mandatory prior manifest: {f}')
  entries=list(rows(f));references.append({'file':str(f),'sha256':sha(f),'rows':len(entries)})
  for r in entries:
   if r.get('sha256'):known_hashes.add(r['sha256'].lower())
   if r.get('image'):known_names.add(r['image'].lower())
 out=[];seen=set()
 for p in files:
  digest=sha(p)
  if digest in known_hashes or p.name.lower() in known_names:raise RuntimeError(f'HOLDOUT LEAKAGE: {p} matches previous manifest by content or filename')
  if digest in seen:raise RuntimeError(f'Duplicate holdout image content: {p}')
  seen.add(digest)
  with Image.open(p) as im:
   w,h=im.size;mode=im.mode;im.verify()
  out.append({'split':'test','image':p.name,'relative_path':p.relative_to(data).as_posix(),'sha256':digest,'width':w,'height':h,'mode':mode})
 return out,references

def csv_writer(path,columns):
 f=path.open('w',newline='',encoding='utf-8-sig');w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();return f,w

def args_for(c):
 a=SimpleNamespace(**c)
 a.path_rates=tuple(c['path_rates']);a.path_delays=tuple(c['path_delays'])
 a.path_caps=tuple(c['path_caps']);a.agent_caps=tuple(c['agent_caps'])
 a.eligibility={int(k):tuple(v) for k,v in c['eligibility'].items()}
 a.compromised=tuple(c['compromised']);a.capacity=min(a.path_caps);a.contention_capacity=min(a.path_caps)
 return a

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
 p.add_argument('--config',type=Path,default=HERE/'experiment_i_config.json')
 p.add_argument('--prior-manifest',type=Path,action='append',required=True,help='Supply H and G manifests, and any earlier BSDS500 test manifest')
 p.add_argument('--preflight-only',action='store_true')
 o=p.parse_args();c=json.loads(o.config.read_text(encoding='utf-8'))
 if c['partition']!='test':raise ValueError('Independent partition must be test')
 if not c.get('evaluation_locked',False):raise ValueError('Evaluation must be locked')
 if len(o.prior_manifest)<2:raise ValueError('At least H and G prior manifests required')
 entries,refs=manifest(o.data,o.prior_manifest,int(c['max_test_images']))
 o.out.mkdir(parents=True,exist_ok=True)
 mfile,mwriter=csv_writer(o.out/'I_00_holdout_manifest.csv',list(entries[0]))
 for e in entries:mwriter.writerow(e)
 mfile.close()
 meta={'status':'PREFLIGHT_ONLY' if o.preflight_only else 'STARTED','partition':'BSDS500 test','holdout_images':len(entries),'previous_manifests':refs,'config':c,'python':sys.version,'platform':platform.platform(),'source_hashes':{p.name:sha(p) for p in HERE.glob('*.py')},'limitations':['The BSDS500 test partition may have been used in older experiments not represented by the supplied manifests; user must certify historical non-use','Simulation is not a deployed network','Shared assistance and reassignment primitive','No hyperparameter tuning on holdout','No cryptographic proof']}
 metadata=o.out/'I_03_metadata.json';metadata.write_text(json.dumps(meta,indent=2),encoding='utf-8')
 if o.preflight_only:print('HOLDOUT PREFLIGHT PASS',len(entries),'images; manifest hashes and filenames disjoint');return
 s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py');sim=load('71_h_guarded_simulator.py')
 s33.selftest();a=args_for(c)
 runfile=None;eventfile=None;adfile=None;n=0;ne=0;na=0
 try:
  for ix,e in enumerate(entries):
   fp=o.data/e['relative_path']
   if sha(fp)!=e['sha256']:raise RuntimeError(f'Holdout image changed: {fp}')
   with Image.open(fp) as im:rgb=im.convert('RGB').tobytes()
   for method in c['methods']:
    for scenario in c['scenarios']:
     for rep in range(int(c['repeats'])):
      for mode in c['modes']:
       trace=[];r=sim.execute(e,rgb,method,int(mode),scenario,rep,a,s33,s34,s35,trace)
       audit=r.pop('security_audit')
       if r['committed']!=r['released'] or r['capacity_violations'] or r['exposure_violations'] or r['reservation_leaks']:raise AssertionError(f'Invariant failure {e["image"]} {scenario} {mode}')
       if runfile is None:runfile,rw=csv_writer(o.out/'I_01_runs.csv',list(r))
       rw.writerow(r);n+=1
       if c.get('save_events',False):
        for item in trace:
         item['split']='test'
         if eventfile is None:eventfile,ew=csv_writer(o.out/'I_02_events.csv',list(item))
         ew.writerow(item);ne+=1
       if c.get('save_admissions',False):
        for item in audit:
         item.update(image=e['image'],sha256=e['sha256'],method=method,mode=mode,scenario=scenario,repeat=rep)
         if adfile is None:adfile,aw=csv_writer(o.out/'I_04_security_admissions.csv',list(item))
         aw.writerow(item);na+=1
   if runfile:runfile.flush()
   print(f'{ix+1}/{len(entries)} {e["image"]}: {n} runs',flush=True)
 finally:
  for f in (runfile,eventfile,adfile):
   if f:f.close()
 expected=len(entries)*len(c['methods'])*len(c['scenarios'])*int(c['repeats'])*len(c['modes'])
 if n!=expected:raise AssertionError((n,expected))
 meta.update(status='COMPLETE',records=n,events=ne,admissions=na,manifest_sha256=sha(o.out/'I_00_holdout_manifest.csv'))
 metadata.write_text(json.dumps(meta,indent=2),encoding='utf-8')
 print('COMPLETE',n,'records; independent-test status conditional on historical-use certification')
if __name__=='__main__':main()
