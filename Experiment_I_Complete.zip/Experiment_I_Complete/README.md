# Experiment I — Independent evaluation and generalization

This package reuses the **guarded Experiment H event simulator**, without altering the protection, transport, security guard, or organizational mechanism implementations. It does not rerun F, G, or H. The evaluation protocol is fixed before opening the candidate test partition.

## Scientific boundary: independent means unused

BSDS500 `test` contains 200 images, but **older Experiment B1 reportedly used these images**. Consequently, the partition is NOT demonstrably untouched, even if there is no overlap with G and H. The script checks filename and SHA-256 overlaps against supplied prior manifests. This is a necessary, not sufficient, independence check. **Do not describe BSDS500 test as an independent held-out set unless you can certify it was not used in model selection, tuning, manuscript revisions, or earlier experiments.** If used previously, report it as a *separate-partition external-to-G/H evaluation*, not a genuinely untouched holdout. For a genuinely independent test, acquire a new source dataset and adapt the manifest input; avoid treating the same corpus as new data.

## Experimental design

- Full BSDS500 test split (200 images), `max_test_images=0`.
- 2 protection methods × 7 scenarios × 3 repetitions × 6 preselected organizational modes = **50,400 records**.
- Modes: 0 no switches; 1 bidding; 2 ownership; 4 assistance; 8 reassignment; 15 all four.
- All settings copied from Experiment H and fixed in JSON; no tuning on test data.
- Matched runs within image × method × scenario × repetition.
- Failure/success, censored completion time, wire ratio, and runtime invariants.
- Image-cluster bootstrap (2,000 draws), paired contrasts against mode 0.
- This does **not** evaluate J1–J6 optimizer quality or establish cross-domain generalization.

## Windows PowerShell

Extract the ZIP to `D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code`.

```powershell
$root = 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments'
$code = "$root\Code\Experiment_I_Complete"
$data = 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data'
$out = "$root\Results\Experiment_I_Complete"
python "$code\82_experiment_i_preflight.py"
python "$code\80_experiment_i_holdout.py" --data "$data" --out "$out" --preflight-only --prior-manifest "$root\Results\Experiment_G_Complete\G_00_manifest.csv" --prior-manifest "$root\Results\Experiment_H_Complete\H_01_manifest.csv"
python "$code\80_experiment_i_holdout.py" --data "$data" --out "$out" --prior-manifest "$root\Results\Experiment_G_Complete\G_00_manifest.csv" --prior-manifest "$root\Results\Experiment_H_Complete\H_01_manifest.csv"
python "$code\81_experiment_i_statistics.py" --input "$out\I_01_runs.csv" --out "$out" --bootstrap 2000 --seed 2026
```

**IMPORTANT:** Add every available prior B1/B2/F test manifest with another `--prior-manifest` argument. G and H alone are insufficient to certify historical non-use. Check full test image content against all earlier used images. If any overlap is found, the script intentionally stops.

## Outputs

- `I_00_holdout_manifest.csv` — image SHA-256 and provenance
- `I_01_runs.csv` — 50,400 paired records
- `I_03_metadata.json` — fixed protocol, sources, warnings, prior-manifest hashes
- `I_05_descriptive.csv` — descriptive outcome means
- `I_06_paired_effects.csv` — matched contrasts and image-cluster bootstrap intervals
- `I_07_analysis_metadata.json` — inference scope and method

Event and security-admission logs are disabled by default to keep the large experiment manageable. Turn them on only if necessary; Experiment H already evaluated these invariants.

## Scope

This is an **out-of-development-partition generalization evaluation**, conditional on historical use. It does not claim causal novelty or real-network transfer. No outcome values have been fabricated or predicted.
