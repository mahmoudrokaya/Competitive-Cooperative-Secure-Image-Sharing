"""Experiment H reference monitor: admission and atomic resource/ownership ledger.
Exposure is an access-policy abstraction; no secrecy proof or key management.
"""
from collections import Counter,defaultdict

class Denied(Exception):
    pass

class Monitor:
    def __init__(self, path_caps, agent_caps, eligibility, compromised, threshold, budget):
        self.pc=tuple(path_caps); self.ac=tuple(agent_caps)
        self.elig={int(a):set(v) for a,v in eligibility.items()}
        self.comp=set(compromised); self.k=int(threshold);self.budget=int(budget)
        self.pa=[0]*len(self.pc);self.aa=[0]*len(self.ac)
        self.owner={};self.exposed=defaultdict(set);self.actions=Counter()
        self.rejections=Counter();self.accepted=Counter();self.max_pa=[0]*len(self.pc);self.max_aa=[0]*len(self.ac)
        self.audit=[]
        if self.k<1 or self.budget<0:raise ValueError('Invalid threshold or budget')
    def check(self,job,sid,path,agent,action):
        key=(job,sid)
        if not (0<=path<len(self.pc) and 0<=agent<len(self.ac)) or path not in self.elig.get(agent,set()):return 'unauthorized'
        if key in self.owner:return 'ownership'
        if self.pa[path]>=self.pc[path] or self.aa[agent]>=self.ac[agent]:return 'capacity'
        if action!='initial' and self.actions[job]>=self.budget:return 'budget'
        if path in self.comp and sid not in self.exposed[job] and len(self.exposed[job])>=self.k-1:return 'exposure'
        return None
    def admit(self,job,sid,path,agent,action,t):
        reason=self.check(job,sid,path,agent,action)
        if reason:
            self.rejections[reason]+=1
            self.audit.append(dict(t=t,job=job,fragment=sid,path=path,agent=agent,action=action,decision='reject',reason=reason))
            return False
        key=(job,sid)
        self.owner[key]=(path,agent);self.pa[path]+=1;self.aa[agent]+=1
        self.max_pa[path]=max(self.max_pa[path],self.pa[path]);self.max_aa[agent]=max(self.max_aa[agent],self.aa[agent])
        if path in self.comp:self.exposed[job].add(sid)
        if action!='initial':self.actions[job]+=1
        self.accepted[action]+=1
        self.audit.append(dict(t=t,job=job,fragment=sid,path=path,agent=agent,action=action,decision='accept',reason=''))
        self.invariant()
        return True
    def release(self,job,sid,path,agent):
        key=(job,sid)
        if self.owner.get(key)!=(path,agent):raise AssertionError('Invalid release or ownership transfer')
        del self.owner[key];self.pa[path]-=1;self.aa[agent]-=1
        self.invariant()
    def invariant(self):
        assert all(0<=x<=c for x,c in zip(self.pa,self.pc))
        assert all(0<=x<=c for x,c in zip(self.aa,self.ac))
        assert all(len(s)<self.k for s in self.exposed.values())
        assert all(v<=self.budget for v in self.actions.values())
        assert sum(self.pa)==sum(self.aa)==len(self.owner)
        return True
    def final(self):
        self.invariant()
        assert not self.owner and not any(self.pa) and not any(self.aa),'Commitment leak'
        return True
