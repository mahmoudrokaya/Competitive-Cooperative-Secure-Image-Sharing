#!/usr/bin/env python3
"""Paired, image-cluster bootstrap for locked Experiment I holdout."""
import argparse,csv,json,random,statistics
from collections import defaultdict
from pathlib import Path

def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def save(p,rs):
 if not rs:return
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)

def metric(r,name):
 if name=='success_rate':return float(r['successes'])/float(r['jobs'])
 return float(r[name])

def percentile(xs,q):
 xs=sorted(xs);pos=q*(len(xs)-1);lo=int(pos);hi=min(lo+1,len(xs)-1);return xs[lo]+(xs[hi]-xs[lo])*(pos-lo)

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--seed',type=int,default=2026)
 a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True);rs=read(a.input)
 if not rs:raise ValueError('Empty input')
 meta=a.input.parent/'I_03_metadata.json'
 if not meta.is_file() or json.loads(meta.read_text())['status']!='COMPLETE':raise RuntimeError('Completed metadata required')
 if any(r.get('split') not in ('','test') for r in rs):raise RuntimeError('Non-test records in holdout')
 modes=sorted({int(r['mode']) for r in rs});methods=sorted({r['method'] for r in rs});scenarios=sorted({r['scenario'] for r in rs})
 if 0 not in modes:raise RuntimeError('Mode 0 baseline required')
 metrics=['success_rate','mean_censored_ms','wire_ratio']
 keys=['sha256','method','scenario','repeat'];blocks=defaultdict(dict)
 for r in rs:
  k=tuple(r[x] for x in keys);m=int(r['mode'])
  if m in blocks[k]:raise RuntimeError(f'Duplicate matched record {k,m}')
  blocks[k][m]=r
 if any(set(b)!=set(modes) for b in blocks.values()):raise RuntimeError('Incomplete paired blocks')
 summary=[]
 for method in methods:
  for scenario in scenarios+['ALL']:
   bb=[b for k,b in blocks.items() if k[1]==method and (scenario=='ALL' or k[2]==scenario)]
   for mode in modes:
    for metric_name in metrics:
     vals=[metric(b[mode],metric_name) for b in bb]
     summary.append(dict(method=method,scenario=scenario,mode=mode,metric=metric_name,n_blocks=len(vals),mean=statistics.mean(vals)))
 save(a.out/'I_05_descriptive.csv',summary)
 rng=random.Random(a.seed);effects=[]
 for method in methods:
  for scenario in scenarios+['ALL']:
   selected=[(k,b) for k,b in blocks.items() if k[1]==method and (scenario=='ALL' or k[2]==scenario)]
   imgs=sorted({k[0] for k,b in selected});byimg=defaultdict(list)
   for k,b in selected:byimg[k[0]].append(b)
   for mode in modes:
    if mode==0:continue
    for metric_name in metrics:
     per_image={im:statistics.mean(metric(b[mode],metric_name)-metric(b[0],metric_name) for b in byimg[im]) for im in imgs}
     # Equal image weighting avoids treating correlated repetitions as independent images.
     observed=statistics.mean(per_image.values())
     boot=[statistics.mean(per_image[im] for im in rng.choices(imgs,k=len(imgs))) for _ in range(a.bootstrap)]
     effects.append(dict(method=method,scenario=scenario,contrast=f'{mode}-0',metric=metric_name,images=len(imgs),effect=observed,ci95_low=percentile(boot,.025),ci95_high=percentile(boot,.975),fraction_images_positive=sum(v>0 for v in per_image.values())/len(imgs),fraction_images_zero=sum(abs(v)<1e-12 for v in per_image.values())/len(imgs),direction='higher_better' if metric_name=='success_rate' else 'lower_better'))
 save(a.out/'I_06_paired_effects.csv',effects)
 (a.out/'I_07_analysis_metadata.json').write_text(json.dumps({'seed':a.seed,'bootstrap':a.bootstrap,'independent_cluster':'image_sha256','matching':keys,'confidence_interval':'image cluster percentile bootstrap','multiple_testing':'unadjusted exploratory intervals; no multiplicity correction','causal_scope':'within deterministic simulation and fixed policies only','records':len(rs),'images':len({r['sha256'] for r in rs}),'modes':modes},indent=2))
 print('ANALYSIS COMPLETE',len(rs),'runs',len(effects),'contrasts')
if __name__=='__main__':main()
