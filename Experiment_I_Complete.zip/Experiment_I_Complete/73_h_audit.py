#!/usr/bin/env python3
"""Fail-closed consistency audit of Experiment H outputs."""
import argparse,csv,json,collections
from pathlib import Path

def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 runs=read(a.out/'H_02_runs.csv');ad=read(a.out/'H_04_security_admissions.csv');ev=read(a.out/'H_03_events.csv')
 issues=[]
 if not runs:issues.append('No experimental runs')
 for i,r in enumerate(runs):
  for field in ('capacity_violations','reservation_leaks','exposure_violations','ownership_conflicts'):
   if int(r[field]):issues.append(f'Run {i}: {field}={r[field]}')
  if int(r['committed'])!=int(r['released']):issues.append(f'Run {i}: unbalanced commitments')
  if int(r['max_cumulative_exposure'])>=2:issues.append(f'Run {i}: exposure threshold reached')
 keys=('sha256','method','mode','scenario','repeat')
 by=collections.defaultdict(list)
 for d in ad:by[tuple(d[k] for k in keys)].append(d)
 for r in runs:
  k=tuple(r[x] for x in keys);items=by[k]
  accepted=sum(x['decision']=='accept' for x in items)
  if accepted!=int(r['committed']):issues.append(f'{k}: accepted={accepted}, committed={r["committed"]}')
  rejected=sum(x['decision']=='reject' for x in items)
  if rejected!=int(r['security_rejections']):issues.append(f'{k}: rejection mismatch')
 reasons=collections.Counter(x['reason'] for x in ad if x['decision']=='reject')
 summary={'status':'PASS' if not issues else 'FAIL','runs':len(runs),'admission_decisions':len(ad),'event_records':len(ev),'accepted':sum(x['decision']=='accept' for x in ad),'rejected':sum(x['decision']=='reject' for x in ad),'rejections_by_reason':dict(reasons),'issues':issues[:100]}
 (a.out/'H_06_audit.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 print(json.dumps(summary,indent=2))
 if issues:raise SystemExit(1)
if __name__=='__main__':main()
