from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
p=Path(__file__).with_name('71_h_guarded_simulator.py');s=spec_from_file_location('h_sim',p);m=module_from_spec(s);s.loader.exec_module(m)
for k,v in vars(m).items():
 if not k.startswith('__'):globals()[k]=v
