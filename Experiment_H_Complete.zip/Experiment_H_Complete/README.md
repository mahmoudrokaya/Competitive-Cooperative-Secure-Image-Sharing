# Experiment H — Integrated Security and Commitment Validation

## Scope
This package instruments the **same event-driven simulator used in Experiment G**, copied as `71_h_guarded_simulator.py`. The existing Step 33/34/35 crypto, share serialization, and FEC/ARQ transport functions are called during actual events. It does **not** patch source code in memory or rewrite your existing A–G project files.

The monitor in `70_h_security.py` checks every attempted commitment *before* invoking transport. It enforces agent–path eligibility, path capacity, agent capacity, exclusive active fragment ownership, cumulative distinct-fragment exposure across release/reassignment, and per-job intervention budgets. Atomic release and final ledger reconciliation are mandatory. Invalid actions are rejected and recorded. Every security admission has a structured record.

**Threat model:** The configured set of compromised paths is assumed known and colluding. A compromised path exposes the identity of the fragment it carries. Exposure policy limits distinct exposed fragment IDs to fewer than `exposure_threshold`. This is a conservative **policy-level** constraint, not a cryptographic secrecy proof. In particular, ciphertext erasure fragments are not Shamir shares and exposure constraints do not model compromised encryption keys.

## Install
Extract the archive to:
`D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code\Experiment_H_Complete`

Install requirements: `python -m pip install pillow cryptography`.

## Preflight (mandatory)
```powershell
$root = 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments'
$code = "$root\Code\Experiment_H_Complete"
$out = "$root\Results\Experiment_H_Complete"
python "$code\72_experiment_h.py" --mode preflight --out "$out"
```

Preflight checks cryptographic primitives, unauthorized assignments, duplicate ownership, capacity, exposure persistence, threshold violation, budget exhaustion, commitment balance, and all 16 modes with both methods across selected network scenarios, plus **adversarial rejections inside the actual scheduler**. Stop on any failure.

## Full development experiment
```powershell
python "$code\72_experiment_h.py" --mode full --data 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data' --out "$out"
python "$code\73_h_audit.py" --out "$out"
```

Default configuration: 8 images, 2 methods, 7 network scenarios, 3 repetitions, 16 organizational configurations = **5,376 runs**. Set `max_images_per_split` to another positive integer to change scope. No test split is accessed.

## Outputs
- `H_00_preflight.csv` — detailed tests, fail-closed.
- `H_01_manifest.csv` — image hashes and splits.
- `H_02_runs.csv` — per-run outcomes, capacity/ownership/exposure/rejection diagnostics.
- `H_03_events.csv` — actual transport/commit/release/recovery events.
- `H_04_security_admissions.csv` — every accepted/rejected security decision.
- `H_05_metadata.json` — parameters, assumptions, source hashes.
- `H_06_audit.json` — cross-file reconciliation, pass/fail.

## Interpretation and limitations
1. **Security enforcement can reduce liveness**. A blocked request is a valid safety outcome, not a network recovery success.
2. Agent assignment defaults to agent index equal to path index; capacities are tracked independently but agent choice is not optimized. The optional `agent_assignment` value `eligible_least_loaded` selects among eligible agents.
3. Security guard is active for all configurations; organizational switches only change allowed bidding/ownership preferences/assistance/reassignment actions. The guard's exclusive commitment policy remains universal for scientific comparability.
4. The simulator does not implement physical distributed messages, deployed authorization credentials, real sockets, compromised-key attacks, or formal cryptographic proofs.
5. No retrospective change to Experiment G is made. H establishes enforcement of explicitly modeled invariants, not causal organizational synergy or global optimality.
6. A failure to admit an action is recorded as an explicit rejection; no violation counters are set to zero in lieu of enforcement.
