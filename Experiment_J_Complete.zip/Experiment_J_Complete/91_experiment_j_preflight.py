#!/usr/bin/env python3
"""Experiment J acceptance checks, including nontrivial constraint tests."""
import importlib.util,json,subprocess,sys,tempfile,csv
from pathlib import Path
HERE=Path(__file__).resolve().parent

def load(p):
 s=importlib.util.spec_from_file_location('fmod',HERE/p);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m

def main():
 j=load('90_experiment_j_optimizer.py');f=load('56_experiment_f_integrated.py');s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py')
 c=f.config(HERE/'experiment_f_config.json');c['_loss']=.2;c['_payload_bytes']=4096
 blob=bytes(range(256))*16
 pre={m:s34.make_shares(s33,m,blob,b'') for m in ('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')}
 tests=[]
 def check(name,condition):
  if not condition:raise AssertionError(name)
  tests.append(name)
 c['methods']=list(pre);c['require_authentication']=True
 x=j.solver(pre,c,f,'exact',128,2026);check('exact_feasible',x['status']=='FEASIBLE')
 for name in ('bounded','greedy','random','static'):
  r=j.solver(pre,c,f,name,128,2026)
  check(name+'_never_better_than_oracle',r['status']!='FEASIBLE' or float(r['objective'])>=float(x['objective'])-1e-9)
 c['path_capacity']=[0,0,0];r=j.solver(pre,c,f,'exact',128,2026)
 check('zero_capacity_infeasible',r['status']=='INFEASIBLE')
 c['path_capacity']=[4,4,4];c['agent_path_eligibility']=[[],[],[]]
 
 try:
  r=j.solver(pre,c,f,'exact',128,2026)
  check('ineligible_assignment_infeasible',r['status']=='INFEASIBLE')
 except ValueError:
  check('ineligible_assignment_rejected',True)
 with tempfile.TemporaryDirectory() as d:
  subprocess.run([sys.executable,str(HERE/'90_experiment_j_optimizer.py'),'--preflight','--out',d],check=True)
  with open(Path(d)/'J_01_runs.csv',encoding='utf-8-sig',newline='') as fcsv:rows=list(csv.DictReader(fcsv))
  check('end_to_end_15_records',len(rows)==15)
  check('end_to_end_oracle_present',sum(r['strategy']=='exact' for r in rows)==3)
 print('PREFLIGHT PASS',len(tests),'checks')
if __name__=='__main__':main()
