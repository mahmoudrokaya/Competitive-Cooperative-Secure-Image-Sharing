# Experiment J — Optimizer Quality and Computational Efficiency

## Scope and scientific interpretation

This package benchmarks the **actual candidate scoring and feasibility functions** in `56_experiment_f_integrated.py`, reused unchanged, for a *single-job initial planning problem*. The decision variables are protection method, recovery policy, and fragment-to-agent/path assignment. It compares:

- `exact`: exhaustive enumeration over every allowed assignment and four recovery policies, for each configured method. This is an **exact finite-space oracle for this one-job surrogate**, not for multi-job scheduling or dynamic network optimization.
- `bounded`: deterministic beam heuristic with candidate budget controlling beam width.
- `greedy`: lowest nominal path delay/rate heuristic, followed by policy evaluation.
- `random`: fixed-budget seeded random search.
- `static`: fixed first-method, first-policy, round-robin option assignment.

All five methods use identical security/capacity feasibility checks and identical normalized predicted objective. Comparisons are paired by content SHA256, forecast loss rate and repetition. The exact oracle establishes a lower bound for this **specified finite one-job planning problem only**. No claim of global optimality for the paper's full dynamic multi-job optimization is supported.

### Critical limitations

1. The existing F predictor computes per-fragment reliability without modeling path-specific loss heterogeneity, so some assignments and strategies may tie. **Zero regret is not proof of a better optimizer**; it may indicate an insensitive objective.
2. `planning_ms` measures Python solver execution and excludes encoding, image I/O, network simulation, encryption, scheduler execution and statistical uncertainty in timing. Report machine/OS/Python details from metadata.
3. This is not an independent holdout or realized end-to-end delivery experiment. Prior F/G/H/I evidence addresses other questions.
4. Synthetic payload bytes are deterministic random data. To use real images, pass `--data` pointing to a folder; the first N sorted image paths are read. Image source provenance must be reported separately.
5. If the full system has event-triggered changes, those are not covered by this initial-plan benchmark.
6. For small differences in millisecond-level timings, rerun on a stable machine and report medians/percentiles, not formal speedup claims from a single run.

## Windows PowerShell

Extract the archive under `D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code`.

```powershell
$root = 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments'
$code = "$root\Code\Experiment_J_Complete"
$out = "$root\Results\Experiment_J_Complete"
python "$code\91_experiment_j_preflight.py"
python "$code\90_experiment_j_optimizer.py" --out "$out"
```

Optional real image input:

```powershell
python "$code\90_experiment_j_optimizer.py" --data 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data\BSR\BSDS500\data\images\val' --out "$out"
```

Default full run: 4 synthetic payload sizes × 3 loss forecasts × 5 repetitions × 5 strategies = **300 records**. It deliberately does **not** rerun 50,400 image-network trials.

## Output files

- `J_01_runs.csv`: objective, predicted reliability/time/wire, feasibility, candidate counts, elapsed planner time and rejected-candidate reasons.
- `J_02_paired.csv`: matched objective regret against the finite exact oracle.
- `J_03_summary.csv`: per-strategy feasibility rate, mean regret, median and p95 planning time, average candidates.
- `J_04_metadata.json`: code hashes, software environment, configuration, scientific limitations.

## Suggested paper claims

Only after inspecting real runs: report oracle-relative predicted-objective regret, feasibility and measured planner runtime **for the bounded single-job decision problem**. Do not conflate predicted score with actual throughput, latency, failure or network efficiency. Do not assert a speedup or optimality result for the entire adaptive architecture from this experiment alone.
