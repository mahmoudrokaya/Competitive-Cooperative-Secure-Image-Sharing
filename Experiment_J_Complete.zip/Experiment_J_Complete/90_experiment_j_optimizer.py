#!/usr/bin/env python3
"""Experiment J: exact-oracle and budgeted optimizer benchmark of Experiment F's objective.
No network execution is claimed. Compares predicted objective under identical feasibility.
"""
import argparse,csv,hashlib,importlib.util,itertools,json,math,random,statistics,time,platform,sys
from pathlib import Path
from collections import Counter
from PIL import Image
HERE=Path(__file__).resolve().parent

def load(file):
 spec=importlib.util.spec_from_file_location('j_'+file[:2],HERE/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def write(path,rows):
 if not rows:return
 with open(path,'w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def placements(n,options):return itertools.product(options,repeat=n)

def evaluate(preencoded,method,policy,placement,state,c,f):
 shares,_,_,k=preencoded[method]
 ids=[sid for sid,_ in shares]
 ok,reason=f.allowed(0,method,ids,placement,state,c)
 if not ok:return None,reason
 score,r,t,w=f.predict(shares,k,placement,policy,c['_loss'],c)
 if r<c['min_predicted_reliability']:return None,'reliability'
 return (float(score),float(r),float(t),float(w)) ,''

def solver(preencoded,c,f,strategy,budget,seed):
 state=f.State();options=tuple((a,p) for a,paths in enumerate(c['agent_path_eligibility']) for p in paths if p in c['allowed_paths'])
 methods=tuple(m for m in c['methods'] if not c['require_authentication'] or m in f.AUTH)
 policies=tuple(f.POLICIES)
 if not methods or not options:raise ValueError('No available method/placement')
 rng=random.Random(seed);nchoices=0;feasible=0;rejected=Counter();best=None;start=time.perf_counter_ns()
 def consider(m,pol,place):
  nonlocal nchoices,feasible,best
  nchoices+=1
  result,reason=evaluate(preencoded,m,pol,place,state,c,f)
  if result is None:rejected[reason]+=1;return
  feasible+=1
  key=(result[0],m,pol,place)
  if best is None or key<best[0]:best=(key,result)
 if strategy=='exact':
  for m in methods:
   n=len(preencoded[m][0])
   for place in placements(n,options):
    for pol in policies:consider(m,pol,place)
 elif strategy=='static':
  for m in methods[:1]:
   n=len(preencoded[m][0]);place=tuple(options[i%len(options)] for i in range(n))
   for pol in policies[:1]:consider(m,pol,place)
 elif strategy=='greedy':
  for m in methods:
   n=len(preencoded[m][0]);place=tuple(min(options,key=lambda ap:(c['path_delays'][ap[1]]+1000/c['path_rates'][ap[1]],ap)) for _ in range(n))
   for pol in policies:consider(m,pol,place)
 elif strategy=='random':
  for _ in range(budget):
   m=rng.choice(methods);pol=rng.choice(policies);place=tuple(rng.choice(options) for _ in preencoded[m][0]);consider(m,pol,place)
 elif strategy=='bounded':
  # Deterministic heuristic ordering; objective remains the unmodified Experiment F score.
  for m in methods:
   n=len(preencoded[m][0]);order=sorted(options,key=lambda ap:(c['path_delays'][ap[1]]+1000/c['path_rates'][ap[1]],ap))
   # Prefix beam expands each fragment while enforcing per-plan resource bounds.
   beam=[((),[0]*len(c['path_capacity']),[0]*len(c['agent_capacity']),0.)]
   width=max(1,budget//max(1,len(methods)*len(policies)*len(order)))
   for sid in range(n):
    expanded=[]
    for prefix,pcounts,acounts,h in beam:
     for a,p in order:
      if pcounts[p]>=c['path_capacity'][p] or acounts[a]>=c['agent_capacity'][a]:continue
      pc=pcounts.copy();ac=acounts.copy();pc[p]+=1;ac[a]+=1
      expanded.append((prefix+((a,p),),pc,ac,h+c['path_delays'][p]+1000/c['path_rates'][p]))
    beam=sorted(expanded,key=lambda z:(z[3],z[0]))[:width]
   for place,_,_,_ in beam:
    for pol in policies:consider(m,pol,place)
 else:raise ValueError(strategy)
 ms=(time.perf_counter_ns()-start)/1e6
 if best is None:return dict(status='INFEASIBLE',objective='',reliability='',predicted_time_ms='',predicted_wire_bytes='',method='',policy='',placement='',evaluated=nchoices,feasible=feasible,planning_ms=ms,rejections=json.dumps(rejected))
 key,res=best
 return dict(status='FEASIBLE',objective=res[0],reliability=res[1],predicted_time_ms=res[2],predicted_wire_bytes=res[3],method=key[1],policy=key[2],placement=json.dumps(key[3]),evaluated=nchoices,feasible=feasible,planning_ms=ms,rejections=json.dumps(rejected))

def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,default=HERE/'experiment_j_config.json');p.add_argument('--out',type=Path,required=True);p.add_argument('--data',type=Path,help='Optional real image directory, recursively searched');p.add_argument('--preflight',action='store_true');o=p.parse_args()
 j=json.loads(o.config.read_text());f=load('56_experiment_f_integrated.py');s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s33.selftest()
 c=f.config(HERE/'experiment_f_config.json');c['methods']=list(j['methods']);c['require_authentication']=True;c['min_predicted_reliability']=0.;c['path_capacity']=list(j['path_capacity']);c['agent_capacity']=list(j['agent_capacity']);c['agent_path_eligibility']=list(j['eligibility']);c['allowed_paths']=list(j['allowed_paths'])
 # This experiment scores a single job at a time, so no misleading batch-admission comparisons.
 cases=[]
 if o.data:
  paths=sorted(p for p in o.data.rglob('*') if p.suffix.lower() in ('.jpg','.jpeg','.png'))[:j['max_images']]
  if not paths:raise ValueError('No images found')
  for path in paths:
   with Image.open(path) as im:blob=im.convert('RGB').tobytes()
   cases.append((path.name,hashfile(path),blob))
 else:
  for size in j['synthetic_payload_bytes']:
   # Fixed deterministic payload; no assertion of representative image compression.
   blob=random.Random(j['seed']+size).randbytes(size)
   cases.append((f'synthetic_{size}',hashlib.sha256(blob).hexdigest(),blob))
 if o.preflight:cases=cases[:1]
 o.out.mkdir(parents=True,exist_ok=True);runs=[]
 for name,h,blob in cases:
  pre={}
  for m in j['methods']:pre[m]=s34.make_shares(s33,m,blob,b'')
  for loss in j['loss_rates']:
   c['_payload_bytes']=len(blob);c['_loss']=loss
   for rep in range(1 if o.preflight else j['repeats']):
    for method in j['strategies']:
     r=solver(pre,c,f,method,j['candidate_budget'],j['seed']+rep+int(loss*10000))
     runs.append(dict(case=name,sha256=h,payload_bytes=len(blob),loss_rate=loss,repeat=rep,strategy=method,**r))
  print(name,'complete',flush=True)
 write(o.out/'J_01_runs.csv',runs)
 # Exact optimum is only over the enumerated one-job, finite decision space.
 by={(r['sha256'],r['loss_rate'],r['repeat']):r for r in runs if r['strategy']=='exact'}
 paired=[]
 for r in runs:
  oracle=by[(r['sha256'],r['loss_rate'],r['repeat'])]
  gap=(float(r['objective'])-float(oracle['objective'])) if r['status']=='FEASIBLE' and oracle['status']=='FEASIBLE' else None
  if gap is not None and gap < -1e-9:raise AssertionError('Optimizer scored better than exhaustive oracle')
  paired.append(dict(case=r['case'],sha256=r['sha256'],loss_rate=r['loss_rate'],repeat=r['repeat'],strategy=r['strategy'],status=r['status'],oracle_objective=oracle['objective'],objective=r['objective'],absolute_regret=gap,relative_regret=gap/max(1e-12,float(oracle['objective'])) if gap is not None else None,planning_ms=r['planning_ms'],oracle_ms=oracle['planning_ms'],evaluated=r['evaluated']))
 write(o.out/'J_02_paired.csv',paired)
 summary=[]
 for strategy in j['strategies']:
  rr=[r for r in paired if r['strategy']==strategy];valid=[r for r in rr if r['absolute_regret'] is not None]
  summary.append(dict(strategy=strategy,n=len(rr),feasible=len(valid),feasibility_rate=len(valid)/len(rr),mean_absolute_regret=statistics.mean(float(r['absolute_regret']) for r in valid) if valid else '',mean_relative_regret=statistics.mean(float(r['relative_regret']) for r in valid) if valid else '',median_planning_ms=statistics.median(float(r['planning_ms']) for r in rr),p95_planning_ms=sorted(float(r['planning_ms']) for r in rr)[math.ceil(.95*len(rr))-1],mean_candidates=statistics.mean(int(r['evaluated']) for r in rr)))
 write(o.out/'J_03_summary.csv',summary)
 meta=dict(status='PREFLIGHT' if o.preflight else 'COMPLETE',cases=len(cases),records=len(runs),config=j,python=sys.version,platform=platform.platform(),sources={p.name:hashfile(p) for p in HERE.glob('*.py')},limitations=['Exact oracle applies only to a single-job finite decision space and this prediction model','Planner timing excludes image encoding, network execution and cryptographic runtime','Predicted objective is not realized transport quality','Experiment F initial planning, not the H/I event scheduler or mid-flight adaptation','No global optimality claim for multi-job scheduling','Synthetic payloads are not image quality evidence'])
 (o.out/'J_04_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
 print('COMPLETE',len(runs),'records',len(cases),'cases',o.out)
if __name__=='__main__':main()
