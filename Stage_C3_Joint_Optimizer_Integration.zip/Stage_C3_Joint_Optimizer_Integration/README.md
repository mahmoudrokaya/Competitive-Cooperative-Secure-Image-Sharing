# C3 — Joint Configuration Optimization Integration Prototype

This stage **integrates** A3.1 capacity-aware organizational simulation, packet-level FEC/ARQ, and encryption/erasure alternatives into a **constrained finite-grid multi-objective configuration selector**. It does **not** implement or validate the proposed J1–J6 objective definitions or an HHO optimizer. Do not describe this as a completed J1–J6/HHO experiment.

## Decision variables

- Protection/fragmentation method: `AES128_GCM_PSK` or `AESGCM_XOR_Erasure_2of3`.
- Organizational recovery mode: `static`, `bidding_ownership_assist`, `bidding_ownership_reassign`, `full` (configurable).
- Packet recovery policy: `arq` or `fec_arq` (configurable).

Path assignment, capacity, transport rates, packet sizes, and loss scenarios remain simulator-defined/fixed. The optimizer is **not** a full path scheduler.

## Selection and constraints

Only BSDS500 **train** images are used for model/configuration selection, with a separate **val** reporting split. Neither BSDS500 test nor `misc` external images are read. Each scenario gets one selected configuration. Maximize `wR*success - wW*(wire_ratio/max_wire) - wT*(timeout_censored_ms/max_time_ms)` subject to minimum success, maximum wire ratio, maximum censored time, and zero resource-integrity violations. Pareto flags are computed on training results. Training choice is deterministic and frozen before validation comparison. These are fixed engineering weights, not derived from J1–J6.

## Run (PowerShell)

```powershell
python -m pip install -r .\requirements.txt
python .\45_C3_joint_optimizer_integration.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C3" `
  --train-images 10 --val-images 10 --repeats 3 --jobs 4
```

Use `--train-images 0 --val-images 0` for the full 200/100 development partitions (considerably slower). The default two images per split is only a smoke test and **not** publishable evidence. `--scenarios` can be extended to all seven A3.1 scenarios. The program never reads test/external images, even with full development mode.

## Outputs

`C3_00_manifest.csv`, `C3_01_candidates.csv`, `C3_02_runs.csv`, `C3_03_aggregate.csv`, `C3_04_train_selected.csv`, `C3_05_validation_comparison.csv`, `C3_06_methodology.json`.

## Key limitations

The frozen A3.1 simulator uses simulated network events, not physical network measurements. Ownership is abstract; bidding and ownership were not independently validated in C2. Packet policy comparisons may not be perfectly matched on identical random-loss traces because A3.1 seeds depend on path/action and packet transport. This integration prototype is a prerequisite to, not a substitute for, a fully specified J1–J6 joint optimizer and subsequent unbiased final evaluation.
