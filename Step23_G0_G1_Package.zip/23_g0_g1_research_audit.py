#!/usr/bin/env python3
"""Step 23: evidence-linked G0 reading dossier and testable G1 specification. Offline; no novelty certification."""
import argparse,csv,collections,datetime,hashlib,json,pathlib,re
PIDS=['OI0001','OI0002','OI0003','OI0005','OI0010','OI0013','OI0020','OI0027','OI0028','OI0031','OI0035','RW0072','RW0180','RW0199']
MECHANISMS={
 'capability_evaluation':r'capabilit|skill|competenc|suitabilit|self.estimat|cost.effectiveness',
 'competitive_preference':r'bid|auction|contract.net|competit|negotiat|preference',
 'assignment':r'allocat|assign|award|coalition|role.select',
 'commitment':r'commit|responsib|obligation|intention|accept',
 'post_assignment_assistance':r'assist|help|support|cooperat|collaborat|subcontract',
 'global_utility':r'global|joint.utility|team.utility|overall|collective|social.welfare',
 'reassignment':r'reassign|reallocat|failure|dynamic|adaptiv|recover',
 'counterfactual_assistance':r'counterfactual|marginal.contribut|opportunity.cost|difference.reward|value.of.help',
 'commitment_guarantee':r'feasib|guarantee|deadline|constraint|violation|bound',
}
def rows(p):
 with open(p,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write_csv(path,data,fields):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(data)
def main():
 a=argparse.ArgumentParser();a.add_argument('--organization-catalog',type=pathlib.Path,required=True);a.add_argument('--organization-evidence',type=pathlib.Path,required=True);a.add_argument('--vc-catalog',type=pathlib.Path,required=True);a.add_argument('--vc-evidence',type=pathlib.Path,required=True);a.add_argument('--output-dir',type=pathlib.Path,required=True);args=a.parse_args()
 out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
 oc=rows(args.organization_catalog);oe=rows(args.organization_evidence);vc=rows(args.vc_catalog);ve=rows(args.vc_evidence)
 cats={r['id']:r for r in oc+vc if r.get('id')}; ev=collections.defaultdict(list)
 for r in oe+ve:ev[r.get('id','')].append(r)
 summary=[];candidates=[]
 for rank,pid in enumerate(PIDS,1):
  meta=cats.get(pid,{}); passages=ev[pid]; combined=' '.join((p.get('passage') or p.get('passage_verbatim_extracted') or '') for p in passages)
  hits={k:len(re.findall(v,combined,re.I)) for k,v in MECHANISMS.items()}
  summary.append({'priority':rank,'id':pid,'title':meta.get('title','MISSING'), 'year':meta.get('year',''),'doi':meta.get('doi',''),'pdf_status':meta.get('pdf_status',meta.get('status','')),'evidence_passages':len(passages),'pdf_pages':meta.get('pdf_pages',''),'candidate_mechanisms':'; '.join(k for k,n in hits.items() if n),'manual_review_status':'NOT_REVIEWED','fulltext_verified':'NO','required_next_action':'Read full original methods and pseudocode; record exact pages; distinguish author method from cited related work'})
  for p in passages:
   s=p.get('passage') or p.get('passage_verbatim_extracted') or ''
   if not s:continue
   mh=[k for k,v in MECHANISMS.items() if re.search(v,s,re.I)]
   if not mh:continue
   candidates.append({'id':pid,'title':meta.get('title',''),'page':p.get('page',''),'evidence_id':p.get('evidence_id',f'{pid}-unindexed'), 'mechanism_candidates':';'.join(mh),'passage_excerpt':re.sub(r'\s+',' ',s)[:750],'interpretation':'UNVERIFIED; may be abstract, introduction, citation or mixed PDF columns','pdf_path':p.get('pdf_path',meta.get('pdf_path',''))})
 write_csv(out/'G0_priority_methods_review.csv',summary,list(summary[0]))
 write_csv(out/'G0_traceable_evidence_candidates.csv',candidates,list(candidates[0]))
 rubric=[]
 for s in summary:
  for m in MECHANISMS:
   rubric.append({'id':s['id'],'mechanism':m,'finding':'UNDETERMINED','exact_method_equation_or_pseudocode':'','supporting_pdf_page':'','supporting_evidence_id':'','source_section':'','author_method_vs_related_work':'UNDETERMINED','reviewer_note':'','verified_by':'','verified_date':''})
 write_csv(out/'G0_manual_method_verification_template.csv',rubric,list(rubric[0]))
 plan=r'''# Step 23: G0/G1 Evidence-Gated Algorithmic Research Specification

Generated from the user's local crawler catalogs and extracted passages. **This is a candidate research design, not a novelty certification or a claim of experimental performance.**

## A. User-defined organizational principle
Agents evaluate their suitability for available tasks and actively seek responsibility. An organization assigns feasible responsibilities; agents then accept their primary commitments, execute them, and help peers when beneficial to collective performance. Competition may reopen on an event such as failure or changing conditions. Agents are not maximizing a permanent personal payoff at the expense of teammates.

## B. G0: What the literature must establish
Read the actual method and pseudocode of each priority paper in `G0_priority_methods_review.csv`. Complete all fields in `G0_manual_method_verification_template.csv` using source pages. The extracted passage file is only a locator. A word occurring in a bibliography, introduction, or cited paper **does not demonstrate implementation**. `UNDETERMINED` is the default; `ABSENT_AFTER_FULL_REVIEW` requires reading the complete relevant method and appendix.

The decisive prior-art comparisons are (i) contract-net and multi-round auctions, (ii) dynamic reassignment and coalition/team formation, (iii) assistance with opportunity-cost or marginal-global-utility decisions, and (iv) commitments under uncertain execution. The security transfer is secondary until the general algorithm passes tests.

## C. G1: Formal problem model
Let agents A={1,...,n}, tasks T={1,...,m}, decision epochs t=0,...,H, task dependencies D, heterogeneous capability estimates q_ij(t), available capacity b_i(t), task remaining workload w_j(t), deadlines d_j, and organizational utility J(trajectory). Assignment x_ij(t) in {0,1} denotes primary responsibility. Assistance h_ikj(t) >=0 denotes agent i's resources assisting task j assigned to agent k. Constraints include per-agent capacity, prerequisite order, permissible helpers, deadline and commitment risk bounds, and application-specific hard security policies.

Agents **propose** task preferences from local estimates; the allocator resolves competing claims into a feasible team assignment. After award, an agent has a primary-task commitment with a measurable service-level obligation, not a psychological state called satisfaction.

## D. Candidate mechanism: Commitment-Preserving Organizational Assistance (CPOA)
1. **Preference**: each agent estimates the feasible marginal team value of owning each task, including skill, load and uncertainty, and submits ranked proposals. Distinguish strategic bidding from truthful capability reports.
2. **Allocation**: choose a feasible assignment maximizing predicted organizational utility, with bounded computation. Explicitly record assignments and commitments.
3. **Cooperative execution**: agents execute assigned work. A potential helper evaluates *joint* predicted trajectories with and without assistance, including its own foregone work, communication overhead, uncertainty and downstream task dependencies.
4. **Assistance decision**: allow help only if the conservative expected global improvement is positive **and** the helper's primary commitment remains feasible. With confidence lower bound L_ij on utility gain, require L_ij > overhead_ij. Feasibility checks must use conservative bounds or an exact deterministic commitment model; estimates alone cannot guarantee constraints.
5. **Reorganization**: trigger reconsideration only on a defined event (predicted commitment breach, task completion, major capability change), subject to switching cost and cooldown to avoid thrashing.

**Candidate optimization:**

max_(x,h) E[J(x,h)] - lambda * C_coord(x,h) - mu * C_switch(x,h)

subject to sum_j (primary_load_ij + help_load_ij) <= b_i, assignment coverage, dependency and security constraints, and Pr(primary_commitment_i satisfied | x,h) >= 1-epsilon_i under a stated uncertainty model.

**Counterfactual aid:** Δ_ij = E[J | feasible help i->j] - E[J | no help i->j] - coordination_cost_ij. This expression by itself is *not* novel; novelty would require a distinctive feasible decision procedure, interaction between assignment and assistance, or a nontrivial demonstrated property.

## E. What would constitute an algorithmic contribution?
A defensible claim needs all of the following: (1) a specific operational decision rule not equivalent to known auction+greedy-help or joint assignment methods; (2) a mathematical feasibility or performance property under explicit assumptions; (3) meaningful improvement over a strong sequential auction+greedy assistance baseline under paired tests; (4) measured runtime and message overhead; (5) honest limitations and failure cases.

Candidate difference to investigate: **commitment-preserving assistance using risk-adjusted counterfactual global gain plus event-triggered reorganization with explicit switching cost**. The combination may be known; G0 must check this before claiming novelty.

## F. G2 algorithm pseudocode (design, not validated implementation)
```
initialize capabilities, tasks, commitments, risk budgets
for each decision epoch t:
    if unassigned tasks or reorganization event:
        agents score feasible responsibilities and submit proposals
        allocator computes feasible team assignment
        agents accept explicit primary commitments
    execute primary assignments
    each agent proposes bounded, permissible peer-help actions
    for each proposal:
        estimate joint outcome with-help and without-help
        reject if any hard constraint or primary commitment is violated
        compute conservative global marginal gain minus aid and switching cost
    coordinate selection of non-conflicting positive-gain help actions
    execute selected help; observe outcomes; update capability beliefs
    log event trace and computational / communication overhead
```

## G. G3 theoretical questions and limits
- **Deterministic feasibility preservation**: if the initial schedule is feasible and every accepted help action is checked against the *actual* remaining resource/deadline constraints, induction can preserve feasibility at each epoch. This does not guarantee task completion under random failures.
- **Monotonic predicted team utility**: if the estimator is exact, every accepted action is feasible, and predicted gain includes all costs, sequential accepted help steps cannot decrease the *predicted* utility relative to the evaluated no-help alternative. This does not prove actual realized utility increases or global optimality.
- **Uncertain outcomes**: if confidence bounds are valid and jointly calibrated, derive a probabilistic statement with explicit union bound; do not claim distribution-free guarantees without assumptions.
- **Complexity**: measure number of proposals, candidate evaluations, allocation solver time, and total communications; document exponential worst cases of exact joint optimization.

## H. G4–G6 experiments and decisive baselines
Baseline B0: static skill matching, no help. B1: contract-net/auction allocation, independent execution. B2: cooperative assignment without competition. B3: auction followed by **greedy marginal-gain assistance** (mandatory strong baseline). B4: joint MILP optimization for small deterministic instances. B5: event-triggered reassignment without counterfactual help. Candidate B6: CPOA. Ablations: no commitments, no counterfactual, no peer help, no reorganization, no switching cost, no risk adjustment.

Generate paired scenarios with heterogeneous agents, task dependencies, capacity bottlenecks, failure correlations, noisy capability estimates, varying task-to-agent ratios, help costs, and late-arriving tasks. Predefine training/development/test splits and random seeds. Report collective utility, task success, makespan, commitment violations, regret/optimality gap (where computable), fairness, control overhead, runtime, messages, and worst-case performance. Use paired bootstrap intervals, effect sizes and appropriate multiple-comparison control. A negative result against B3/B4 means the novelty/performance claim must be narrowed or redesigned.

## I. G7 secure multipath transfer
Map task ownership to share generation, permitted path delivery, integrity checking and recovery. A (2,2) XOR sharing construction is confidential against one-share observation with fresh uniform randomness, but is neither intrinsically authenticated nor resilient to permanent loss of a share. Keep cryptographic privacy, authentication, correlated compromise and reconstruction guarantees separate from organizational scheduling performance. Do not use security-sensitive shares in ordinary agent coordination messages.

## J. Acceptance gates
G0: complete page-supported review of critical original methods. G1: formal variables, constraints, objectives and threat model. G2: implement distinguishable policy and strong baselines. G3: prove only supported properties. G4: deterministic reproducible simulation. G5: ablations and optimality references. G6: paired statistical evidence. G7: security-constrained transfer. G8: novelty re-audit and claim wording.

## K. Source and reproducibility limits
Only local metadata and PDF-extracted passages were processed. The 35 organizational and 73 network/VC distinct PDFs are **not supplied as PDF files in this package**, and their extracted passages can contain reference-list citations or multi-column mixing. The `pdf_path` values are paths on the user's Windows machine, not files opened in this execution. Source excerpts should be verified against original PDF pages before making specific method claims.
'''
 (out/'G1_algorithmic_research_specification.md').write_text(plan,encoding='utf-8')
 stats={'organization_records':len(oc),'organization_passages':len(oe),'vc_records':len(vc),'vc_passages':len(ve),'priority_papers':len(summary),'evidence_candidates':len(candidates),'manual_review_rows':len(rubric),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':{k:str(v) for k,v in vars(args).items() if k!='output_dir'}}
 (out/'G0_G1_run_manifest.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
 print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
