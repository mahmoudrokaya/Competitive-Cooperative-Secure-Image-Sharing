# Step 23: G0/G1 Evidence-Gated Algorithmic Research Specification

Generated from the user's local crawler catalogs and extracted passages. **This is a candidate research design, not a novelty certification or a claim of experimental performance.**

## A. User-defined organizational principle
Agents evaluate their suitability for available tasks and actively seek responsibility. An organization assigns feasible responsibilities; agents then accept their primary commitments, execute them, and help peers when beneficial to collective performance. Competition may reopen on an event such as failure or changing conditions. Agents are not maximizing a permanent personal payoff at the expense of teammates.

## B. G0: What the literature must establish
Read the actual method and pseudocode of each priority paper in `G0_priority_methods_review.csv`. Complete all fields in `G0_manual_method_verification_template.csv` using source pages. The extracted passage file is only a locator. A word occurring in a bibliography, introduction, or cited paper **does not demonstrate implementation**. `UNDETERMINED` is the default; `ABSENT_AFTER_FULL_REVIEW` requires reading the complete relevant method and appendix.

The decisive prior-art comparisons are (i) contract-net and multi-round auctions, (ii) dynamic reassignment and coalition/team formation, (iii) assistance with opportunity-cost or marginal-global-utility decisions, and (iv) commitments under uncertain execution. The security transfer is secondary until the general algorithm passes tests.

## C. G1: Formal problem model
Let agents A={1,...,n}, tasks T={1,...,m}, decision epochs t=0,...,H, task dependencies D, heterogeneous capability estimates q_ij(t), available capacity b_i(t), task remaining workload w_j(t), deadlines d_j, and organizational utility J(trajectory). Assignment x_ij(t) in {0,1} denotes primary responsibility. Assistance h_ikj(t) >=0 denotes agent i's resources assisting task j assigned to agent k. Constraints include per-agent capacity, prerequisite order, permissible helpers, deadline and commitment risk bounds, and application-specific hard security policies.

Agents **propose** task preferences from local estimates; the allocator resolves competing claims into a feasible team assignment. After award, an agent has a primary-task commitment with a measurable service-level obligation, not a psychological state called satisfaction.

## D. Candidate mechanism: Commitment-Preserving Organizational Assistance (CPOA)
1. **Preference**: each agent estimates the feasible marginal team value of owning each task, including skill, load and uncertainty, and submits ranked proposals. Distinguish strategic bidding from truthful capability reports.
2. **Allocation**: choose a feasible assignment maximizing predicted organizational utility, with bounded computation. Explicitly record assignments and commitments.
3. **Cooperative execution**: agents execute assigned work. A potential helper evaluates *joint* predicted trajectories with and without assistance, including its own foregone work, communication overhead, uncertainty and downstream task dependencies.
4. **Assistance decision**: allow help only if the conservative expected global improvement is positive **and** the helper's primary commitment remains feasible. With confidence lower bound L_ij on utility gain, require L_ij > overhead_ij. Feasibility checks must use conservative bounds or an exact deterministic commitment model; estimates alone cannot guarantee constraints.
5. **Reorganization**: trigger reconsideration only on a defined event (predicted commitment breach, task completion, major capability change), subject to switching cost and cooldown to avoid thrashing.

**Candidate optimization:**

max_(x,h) E[J(x,h)] - lambda * C_coord(x,h) - mu * C_switch(x,h)

subject to sum_j (primary_load_ij + help_load_ij) <= b_i, assignment coverage, dependency and security constraints, and Pr(primary_commitment_i satisfied | x,h) >= 1-epsilon_i under a stated uncertainty model.

**Counterfactual aid:** Δ_ij = E[J | feasible help i->j] - E[J | no help i->j] - coordination_cost_ij. This expression by itself is *not* novel; novelty would require a distinctive feasible decision procedure, interaction between assignment and assistance, or a nontrivial demonstrated property.

## E. What would constitute an algorithmic contribution?
A defensible claim needs all of the following: (1) a specific operational decision rule not equivalent to known auction+greedy-help or joint assignment methods; (2) a mathematical feasibility or performance property under explicit assumptions; (3) meaningful improvement over a strong sequential auction+greedy assistance baseline under paired tests; (4) measured runtime and message overhead; (5) honest limitations and failure cases.

Candidate difference to investigate: **commitment-preserving assistance using risk-adjusted counterfactual global gain plus event-triggered reorganization with explicit switching cost**. The combination may be known; G0 must check this before claiming novelty.

## F. G2 algorithm pseudocode (design, not validated implementation)
```
initialize capabilities, tasks, commitments, risk budgets
for each decision epoch t:
    if unassigned tasks or reorganization event:
        agents score feasible responsibilities and submit proposals
        allocator computes feasible team assignment
        agents accept explicit primary commitments
    execute primary assignments
    each agent proposes bounded, permissible peer-help actions
    for each proposal:
        estimate joint outcome with-help and without-help
        reject if any hard constraint or primary commitment is violated
        compute conservative global marginal gain minus aid and switching cost
    coordinate selection of non-conflicting positive-gain help actions
    execute selected help; observe outcomes; update capability beliefs
    log event trace and computational / communication overhead
```

## G. G3 theoretical questions and limits
- **Deterministic feasibility preservation**: if the initial schedule is feasible and every accepted help action is checked against the *actual* remaining resource/deadline constraints, induction can preserve feasibility at each epoch. This does not guarantee task completion under random failures.
- **Monotonic predicted team utility**: if the estimator is exact, every accepted action is feasible, and predicted gain includes all costs, sequential accepted help steps cannot decrease the *predicted* utility relative to the evaluated no-help alternative. This does not prove actual realized utility increases or global optimality.
- **Uncertain outcomes**: if confidence bounds are valid and jointly calibrated, derive a probabilistic statement with explicit union bound; do not claim distribution-free guarantees without assumptions.
- **Complexity**: measure number of proposals, candidate evaluations, allocation solver time, and total communications; document exponential worst cases of exact joint optimization.

## H. G4–G6 experiments and decisive baselines
Baseline B0: static skill matching, no help. B1: contract-net/auction allocation, independent execution. B2: cooperative assignment without competition. B3: auction followed by **greedy marginal-gain assistance** (mandatory strong baseline). B4: joint MILP optimization for small deterministic instances. B5: event-triggered reassignment without counterfactual help. Candidate B6: CPOA. Ablations: no commitments, no counterfactual, no peer help, no reorganization, no switching cost, no risk adjustment.

Generate paired scenarios with heterogeneous agents, task dependencies, capacity bottlenecks, failure correlations, noisy capability estimates, varying task-to-agent ratios, help costs, and late-arriving tasks. Predefine training/development/test splits and random seeds. Report collective utility, task success, makespan, commitment violations, regret/optimality gap (where computable), fairness, control overhead, runtime, messages, and worst-case performance. Use paired bootstrap intervals, effect sizes and appropriate multiple-comparison control. A negative result against B3/B4 means the novelty/performance claim must be narrowed or redesigned.

## I. G7 secure multipath transfer
Map task ownership to share generation, permitted path delivery, integrity checking and recovery. A (2,2) XOR sharing construction is confidential against one-share observation with fresh uniform randomness, but is neither intrinsically authenticated nor resilient to permanent loss of a share. Keep cryptographic privacy, authentication, correlated compromise and reconstruction guarantees separate from organizational scheduling performance. Do not use security-sensitive shares in ordinary agent coordination messages.

## J. Acceptance gates
G0: complete page-supported review of critical original methods. G1: formal variables, constraints, objectives and threat model. G2: implement distinguishable policy and strong baselines. G3: prove only supported properties. G4: deterministic reproducible simulation. G5: ablations and optimality references. G6: paired statistical evidence. G7: security-constrained transfer. G8: novelty re-audit and claim wording.

## K. Source and reproducibility limits
Only local metadata and PDF-extracted passages were processed. The 35 organizational and 73 network/VC distinct PDFs are **not supplied as PDF files in this package**, and their extracted passages can contain reference-list citations or multi-column mixing. The `pdf_path` values are paths on the user's Windows machine, not files opened in this execution. Source excerpts should be verified against original PDF pages before making specific method claims.
