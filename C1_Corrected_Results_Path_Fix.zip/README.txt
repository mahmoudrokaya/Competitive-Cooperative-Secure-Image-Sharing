Stage C1 — Corrected results-directory detection

This version reads experimental RESULTS, not raw image data.

Expected structure:
  Experiments/Results/Experiment_B/B1/B1_00_manifest.csv
  Experiments/Results/Experiment_B/B1/B1_01_runs.csv
  Experiments/Results/Experiment_B/B1/B1_03_metadata.json
  Experiments/Results/Experiment_B/B2/B2_00_manifest.csv
  Experiments/Results/Experiment_B/B2/B2_01_runs.csv
  Experiments/Results/Experiment_B/B2/B2_03_metadata.json

A flat input folder containing these six files is also supported.

Windows PowerShell:
python -m pip install numpy pandas scipy
python .\43_C1_statistical_validation.py `
  --input "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_B" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C1" `
  --bootstrap 3000 `
  --seed 4301

This fix changes only file discovery. The inference calculations are unchanged.
Tested with actual B1 and B2 uploaded CSV/metadata using nested folders.
