#!/usr/bin/env python3
"""C4.3 instrumented adaptation of frozen A3.1. NOT a physical network or security benchmark."""
import argparse,csv,json,hashlib,importlib.util,copy,collections,statistics
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location('c43_'+name.split('_')[0],HERE/name)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def patch_source():
    original=(HERE/'40_A3_1_capacity_aware.py').read_text(encoding='utf-8')
    source=original
    # Only change execute() behavior in a new in-memory module, preserving the original source file.
    replacements={
      "  shares0,decoder,target,k=s34.make_shares(s33,method,rgb,b'')": "  shares0,decoder,target,k=s34.make_shares(s33,method,rgb,b'')\n  allocation=tuple(a.c43_allocation)\n  allowed_paths=[i for i,v in enumerate(allocation) if v>0]\n  if not allowed_paths:raise ValueError('No allocated paths')\n  path_bytes=[0.,0.,0.];path_commits=[0,0,0]",
      "   if not allowed:return None": "   allowed=[p for p in allowed if p in allowed_paths]\n   if not allowed:return None",
      "   if mode=='static' and old<0:return sid%3": "   if mode=='static' and old<0:return allowed_paths[sid%len(allowed_paths)]\n   if old<0 and a.c43_weighted:\n    # Weighted deterministic assignment: per-job/per-fragment hash, stable across reruns.\n    u=stable(entry['sha256'],sc,rep,job,sid,'allocation')/(2**64)\n    total=sum(allocation[p] for p in allowed)\n    for p in allowed:\n     u-=allocation[p]/total\n     if u<0:return p\n    return allowed[-1]",
      "    got,wire,_,_,_,_,lat=s35.transport(blob,path,a.policy,kind,loss,seed,a)": "    got,wire,_,_,_,_,lat=s35.transport(blob,path,a.policy,kind,loss,seed,a)\n    path_bytes[path]+=float(wire);path_commits[path]+=1",
      "   jobs=a.jobs,successes=successes,success_rate=successes/a.jobs,": "   jobs=a.jobs,successes=successes,success_rate=successes/a.jobs,\n   path0_wire_bytes=path_bytes[0],path1_wire_bytes=path_bytes[1],path2_wire_bytes=path_bytes[2],\n   path0_commits=path_commits[0],path1_commits=path_commits[1],path2_commits=path_commits[2],\n   control_messages=committed+released+sum(interventions.values()),\n   load_imbalance=(statistics.pvariance([path_bytes[p]/max(1.,a.path_rates[p]) for p in allowed_paths]) if len(allowed_paths)>1 else 0.),",
    }
    for old,new in replacements.items():
        old="\n".join(line[1:] if line.startswith(" ") else line for line in old.split("\n"))
        new="\n".join(line[1:] if line.startswith(" ") else line for line in new.split("\n"))
        if source.count(old)!=1:raise RuntimeError('A3.1 source mismatch at '+old[:70])
        source=source.replace(old,new,1)
    mod=load('40_A3_1_capacity_aware.py')
    exec(compile(source,str(HERE/'C43_IN_MEMORY_ADAPTER.py'),'exec'),mod.__dict__)
    return mod

def run(args):
    a31=patch_source();s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py')
    decisions=list(csv.DictReader(open(args.decisions,encoding='utf-8-sig',newline='')))
    chosen=[r for r in decisions if str(r['feasible']).lower() in ('1','true')]
    if args.limit:chosen=chosen[:args.limit]
    if args.images<1 or args.repeats<1 or args.jobs<1:raise ValueError('Positive counts required')
    entries=a31.manifest(args.data,args.images)
    entries=[r for r in entries if r['split']=='train'] if args.split=='train' else [r for r in entries if r['split']=='val']
    scenarios=args.scenarios.split(',')
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    rows=[];errors=[]
    for di,d in enumerate(chosen):
        allocation=json.loads(d['allocation'])
        if len(allocation)!=3 or sum(v>0 for v in allocation)!=int(d['path_count']):raise ValueError('Bad allocation '+d['candidate_id'])
        for e in entries:
            with Image.open(args.data/e['relative_path']) as im:rgb=im.convert('RGB').tobytes()
            for sc in scenarios:
                for rep in range(args.repeats):
                    config=argparse.Namespace(jobs=args.jobs,capacity=args.capacity,contention_capacity=args.contention_capacity,
                        policy=d['policy'],mtu=1000,header_bytes=20,fec_group=4 if int(d['fec_parity']) else 1000000,
                        max_retries=int(d['arq_limit']),failed_path=1,failure_at_ms=180.,burst_persist=.85,
                        timeout_ms=3000.,detection_ms=80.,queue_penalty_ms=20.,duplicate_path_penalty_ms=10.,
                        max_interventions_per_job=(3 if int(d['assistance']) or int(d['reassignment']) else 0),
                        max_events=100000,seed=args.seed,path_rates=(20.,10.,15.),path_delays=(10.,40.,25.),
                        c43_allocation=allocation,c43_weighted=True)
                    # FEC in the frozen transport is one XOR parity per group; fec_parity is a binary on/off switch.
                    if int(d['fec_parity']) not in (0,1):
                        errors.append({'candidate_id':d['candidate_id'],'reason':'unsupported fec_parity>1'});continue
                    if d['policy'] in ('fec','fec_arq') and int(d['fec_parity'])==0:
                        errors.append({'candidate_id':d['candidate_id'],'reason':'FEC policy with parity=0'});continue
                    if d['policy'] in ('arq','none') and int(d['fec_parity'])!=0:
                        errors.append({'candidate_id':d['candidate_id'],'reason':'non-FEC policy with parity>0'});continue
                    try:
                        trace=[];r=a31.execute(e,rgb,d['method'],d['mode'],sc,rep,config,s33,s34,s35,trace)
                        r['candidate_id']=d['candidate_id'];r['policy']=d['policy'];r['path_count']=d['path_count'];r['allocation']=d['allocation'];r['arq_limit']=d['arq_limit'];r['fec_parity']=d['fec_parity']
                        r['J1_failure']=1-r['success_rate'];r['J2_time']=r['mean_censored_ms']/config.timeout_ms;r['J3_wire']=r['wire_ratio']
                        r['J4_security']=None;r['J5_control']=r['control_messages']/max(1,r['jobs']);r['J6_imbalance']=r['load_imbalance']
                        r['feasible_network']=int(not (r['capacity_violations'] or r['reservation_leaks'] or r['ownership_conflicts'] or r['exposure_violations']))
                        rows.append(r)
                    except Exception as ex:errors.append({'candidate_id':d['candidate_id'],'image':e['image'],'scenario':sc,'repeat':rep,'reason':repr(ex)})
        print(f'candidate {di+1}/{len(chosen)} {d["candidate_id"]}',flush=True)
    if rows:a31.write_csv(out/'C43_01_runs.csv',rows)
    if errors:
        fields=sorted(set().union(*(e.keys() for e in errors)))
        with (out/'C43_02_errors.csv').open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(errors)
    audit={'stage':'C4.3 original A3.1 adapted integration','original_sha256':a31.digest(HERE/'40_A3_1_capacity_aware.py'),
      'source_modified_on_disk':False,'candidates_requested':len(chosen),'images':len(entries),'scenarios':scenarios,'repeats':args.repeats,
      'runs':len(rows),'errors':len(errors),'integrity_failures':sum(not r['feasible_network'] for r in rows),
      'security_objective':'unmeasured','fec_parity_semantics':'0=no FEC; 1=one XOR parity per group',
      'allocation_semantics':'weighted deterministic fragment placement; not packet splitting or continuous capacity optimization',
      'limitations':['A3.1 event-driven simulator, not real network','J4 not measured','No original manuscript J1-J6 confirmation',
       'Only train or val, never test','Loss traces not strictly identical across differing policies','Source includes original A3.1 cryptographic baseline behavior']}
    (out/'C43_00_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps(audit,indent=2))
    return audit

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--decisions',type=Path,default=HERE/'C41_01_decision_space.csv');p.add_argument('--out',type=Path,required=True)
    p.add_argument('--images',type=int,default=1,help='Images per train and val split');p.add_argument('--split',choices=('train','val'),default='train');p.add_argument('--limit',type=int,default=3)
    p.add_argument('--repeats',type=int,default=1);p.add_argument('--jobs',type=int,default=4);p.add_argument('--seed',type=int,default=5001)
    p.add_argument('--capacity',type=int,default=4);p.add_argument('--contention-capacity',type=int,default=2);p.add_argument('--scenarios',default='iid_0.10,burst_0.20,path_failure')
    args=p.parse_args();run(args)
if __name__=='__main__':main()
