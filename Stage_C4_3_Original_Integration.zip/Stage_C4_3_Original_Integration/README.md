# C4.3 — Original A3.1 integration, conservative adapter

The supplied A3.1 source and Step33/34/35 dependencies are bundled under their expected names. The original A3.1 SHA-256 is `67507e212cfd8e2d3677d58b5f7dcdcb03ec24552d847e660337f55f542cf295`. The integration script modifies the `execute` function **in memory**, not the original file.

## Windows pilot

```powershell
python -m pip install pillow cryptography
python -m unittest discover -p "test_c43.py" -v
python .\50_C4_3_integrated_simulator.py `
  --data "D:\48\481\New Papers\Progressive_HHO_Cryptography\Data" `
  --out "D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Stage_C4_3_Pilot" `
  --images 1 --split train --limit 3 --repeats 1 --jobs 4
```

## Broader training-only run

After inspecting the pilot audit and errors, set `--limit 0` to consider all 120 structurally feasible C4.1 candidates; unsupported combinations are explicitly rejected and logged, not silently reinterpreted. Use `--images 200 --split train` only after pilot confirmation. `--images` counts images per split, so 200 requires at least 200 in **both** train and val even if only train is evaluated. Do not use test data for optimization.

## Technical limitations and warnings

- This is the **original A3.1 event-driven simulator** adapted for C4.1 decisions, not physical networking.
- Path allocation weights affect deterministic **fragment placement**. They do not split one fragment into arbitrary proportions or enforce proportional packet-level bandwidth. On a one-fragment AES job, weights are realized statistically across jobs/images.
- FEC parity `1` means the existing single XOR parity packet per `fec_group=4`; parity `2` is **not supported** by Step35. C4.1 candidates with parity `2`, or inconsistent parity/policy combinations, are rejected with reasons. No invented FEC implementation.
- Recovery-policy and `arq_limit` affect the existing Step35 transport. Assistance and reassignment remain A3.1 organizational abstractions.
- J1/J2/J3/J5/J6 are instrumented proxies based on actual simulated execution; J4 remains NULL and is **not** a validated security risk measure. J6 is variance of path wire bytes divided by nominal path rates (not calibrated utilization).
- Capacity constraints remain A3.1 active-commitment limits; true link bandwidth capacity is not enforced.
- Do not interpret C4.3 results as fresh held-out evidence or six-objective HHO optimization.
