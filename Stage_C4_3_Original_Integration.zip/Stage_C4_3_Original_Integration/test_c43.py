import unittest,importlib,sys,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
m=importlib.import_module('50_C4_3_integrated_simulator')
class IntegrationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.a=m.patch_source();cls.s33=m.load('33_expanded_baseline.py');cls.s34=m.load('34_multipath_loss_simulator.py');cls.s35=m.load('35_packet_recovery.py')
 def config(self,allocation):
  return argparse.Namespace(jobs=4,capacity=4,contention_capacity=2,policy='arq',mtu=1000,header_bytes=20,fec_group=4,max_retries=2,failed_path=1,failure_at_ms=180.,burst_persist=.85,timeout_ms=3000.,detection_ms=80.,queue_penalty_ms=20.,duplicate_path_penalty_ms=10.,max_interventions_per_job=3,max_events=100000,seed=5001,path_rates=(20.,10.,15.),path_delays=(10.,40.,25.),c43_allocation=allocation,c43_weighted=True)
 def test_invariants(self):
  for method in self.a.METHODS:
   r=self.a.execute(dict(split='train',image='synthetic',sha256='synthetic'),bytes(range(256))*4,method,'static','iid_0.10',0,self.config([1,0,0]),self.s33,self.s34,self.s35,[])
   self.assertEqual(r['committed'],r['released']);self.assertEqual(r['capacity_violations'],0)
 def test_allocation_changes_path(self):
  results=[]
  for allocation in ([1,0,0],[0,0,1]):
   r=self.a.execute(dict(split='train',image='synthetic',sha256='synthetic'),bytes(range(256))*4,'AES128_GCM_PSK','static','iid_0.10',0,self.config(allocation),self.s33,self.s34,self.s35,[])
   results.append([r['path0_commits'],r['path1_commits'],r['path2_commits']])
  self.assertNotEqual(*results)
 def test_source_digest(self):
  self.assertEqual(self.a.digest(Path(__file__).parent/'40_A3_1_capacity_aware.py'),'67507e212cfd8e2d3677d58b5f7dcdcb03ec24552d847e660337f55f542cf295')
if __name__=='__main__':unittest.main()
