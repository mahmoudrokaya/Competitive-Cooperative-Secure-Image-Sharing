# Step 22 — Evidence-Constrained Algorithmic Novelty Roadmap

Generated: 2026-10-16T20:40:17.439167+00:00

## Input integrity and coverage
- Organizational catalog: **2155**; organizational passage records: **533**, spanning **35** papers.
- Visual-cryptography/multipath catalog: **383**; extracted passages: **543**, spanning **73** papers.
- Source file checksums and original Windows PDF paths are preserved in `source_manifest.csv` and `concept_evidence_matrix.csv`.
- No original PDFs were attached for systematic full-paper reading. Passages may include reference-list mentions, column mixing, or unrelated claims.
- **NOT_OBSERVED never means ABSENT.** Keywords only nominate papers for review.

## Formal research proposition
Each agent assesses feasible tasks and seeks responsibility; a feasible organizational assignment is agreed; each agent honors its primary task and provides assistance if doing so increases expected global utility without violating commitments or hard constraints. Reassignment is event-triggered.

## Novelty verdict
**NOT YET VERIFIED.** Contract-net, auctions, role allocation, and teamwork cover substantial components. The candidate contribution must be a precisely defined *commitment-preserving, counterfactual, global-benefit assistance policy jointly integrated with task assignment*, not a relabeling of known mechanisms.

## Closest-work reading queue
| ID | Year | Title | PDF passages | Candidate concepts |
|---|---:|---|---:|---|
| RW0199 | 2022 | NexGen S-MPTCP: Next Generation Smart Multipath TCP Controller | 12 | C1, C7, C9 |
| RW0072 | 2025 | Two-Dimensional XOR-Based Secret Sharing for Layered Multipath Communication | 7 | C1, C9 |
| RW0180 | 2021 | More than a Fair Share: Network Data Remanence Attacks against Secret Sharing-based Schemes | 11 | C1, C9 |
| OI0013 | 2025 | A Unified Decentralized Framework for Task Allocation in Heterogeneous Multi-Robot Systems | 27 | none in extracts |
| OI0020 | 2023 | Competitive-Cooperative Multi-Agent Reinforcement Learning for Auction-based Federated Learning | 19 | none in extracts |
| OI0001 | 2022 | Distributed Grouping Cooperative Dynamic Task Assignment Method of UAV Swarm | 0 | none in extracts |
| OI0002 | 2011 | A Control Agent Architecture for Cooperative Robotic Tasks | 19 | none in extracts |
| OI0005 | 2026 | Multi-agent task allocation method based on the cost-effectiveness maximization multi-round auction algorithm | 27 | none in extracts |
| OI0031 | 2021 | Collaborative Task Allocation of Heterogeneous Multi-Unmanned Platform Based on a Hybrid Improved Contract Net Algorithm | 30 | none in extracts |
| OI0035 | 2020 | Hierarchical Needs Based Self-Adaptive Framework For Cooperative Multi-Robot System | 18 | none in extracts |
| RW0226 | 2022 | Secret Sharing-Based Energy-Aware and Multi-Hop Routing Protocol for IoT Based WSNs | 2 | C9 |
| OI0010 | 2023 | A Two-Stage Distributed Task Assignment Algorithm Based on Contract Net Protocol for Multi-UAV Cooperative Reconnaissance Task Reassignment in Dynamic Environments | 0 | none in extracts |
| OI0027 | 2018 | Cooperative-Competitive Task Allocation in Edge Computing for Delay-Sensitive Social Sensing | 0 | none in extracts |
| OI0028 | 2022 | Task Allocation Using a Team of Robots | 31 | none in extracts |

## Claim-by-claim status
| Claim | Evidence assessment | Action |
|---|---|---|
| N1: Capability-based task evaluation is new | Established related work in heterogeneous capability/task assignment | Do not claim novelty of capability matching alone |
| N2: Competition for responsibility is new | Contract-net, auction and market-based allocation are established | Do not claim novelty of bidding/selection alone |
| N3: Cooperation after assignment is new | Teamwork, joint intentions and collaborative execution are established | Do not claim novelty of cooperation alone |
| N4: A commitment-aware assistance decision rule is new | Not established by current automated evidence | Verify primary algorithms and identify a precise non-equivalent rule |
| N5: Joint assignment and assistance with feasible guarantees is new | Not established by current automated evidence | Compare against joint assignment, coalition and DCOP methods |
| N6: Secure multipath deployment is new | Secret sharing and adaptive multipath delivery already have direct prior art | Novelty must reside in a distinct verified organizational mechanism or guarantee |

## Proposed algorithmic research plan

### Candidate mechanism: Commitment-Preserving Counterfactual Assistance (CPCA)
For each assigned agent i and a potential assistance action (i -> j), estimate the **counterfactual** change in team utility relative to continuing its own task. Assistance is allowed only when primary-task commitments, resources, dependencies, and security constraints remain feasible. The organizational controller compares feasible help actions and reallocations, accounting for control overhead and uncertainty.

Let \(\Delta_{ij}=\mathbb E[J_{team}\mid do(help_{i\to j})]-\mathbb E[J_{team}\mid do(no\ help)]-\lambda C_{ij}\). The controller chooses a feasible action maximizing positive \(\Delta_{ij}\), subject to a bound on primary-task failure probability and per-agent budgets. This is a *candidate design*, not a novel theorem or verified invention.

### Essential algorithm comparisons
1. Static skill-based assignment with no help.
2. Contract-net / auction task assignment with independent execution.
3. Cooperative team assignment without competitive bidding.
4. Auction + conventional greedy assistance (strong sequential baseline).
5. Joint task assignment + assistance via MILP on small instances (optimality reference).
6. Proposed CPCA with counterfactual global gain and commitment constraints.
7. CPCA minus counterfactual estimation; minus commitment; minus assistance; minus event-triggered reassignment.

### Evaluation design
- Synthetic heterogeneous agents (skills, capacities, dependencies), varied agent/task counts, delayed or noisy ability estimates, task failures and correlated disruptions.
- Use paired scenarios and shared random seeds; tune on separate development scenarios; report means, medians, dispersion, paired confidence intervals, multiple-comparison control and effect sizes.
- Report makespan, task completion, global utility, missed commitments, help rate, fairness, computational latency, communication overhead, and scalability.
- Include negative and adversarial cases: inaccurate self-assessment, selfish preference, assistance overhead exceeding benefit, overload, conflicting commitments, and high failure correlation.
- On small instances, compare against an exact joint optimization formulation and report optimality gaps; on larger instances report wall-clock budgets.

### Security-transfer boundary
The attached Split-Path proposal specifies (2,2) XOR shares sent over Wi-Fi/LTE. This establishes neither active-message authenticity nor loss tolerance. The organizational mechanism may optimize delivery, but cryptographic privacy and availability require separate formal definitions and security-preserving constraints.

## Sequential research gates
| Gate | Work | Acceptance criterion |
|---|---|---|
| G0 | Evidence verification: Verify original full-text methods for 14 named competitors, reconcile DOI/version, annotate C1-C9 as PRESENT/ABSENT/UNCLEAR with page and direct algorithm evidence | No novelty claims until each critical comparator is verified |
| G1 | Formal model: Define agents, heterogeneous task skills, task dependencies, capacities, commitments, aid feasibility, stochastic task completion and global utility | Produce unambiguous optimization problem and feasible action set |
| G2 | Novel decision mechanism: Derive a joint task-allocation and conditional-help policy with marginal global gain, counterfactual cost of abandoning primary work, assistance budget and coordination overhead | Algorithm must differ operationally from auction+greedy-help |
| G3 | Theoretical guarantees: Prove feasibility preservation; establish a limited improvement/approximation or regret bound under explicit assumptions; characterize worst-case overhead | Avoid unsupported universal optimality claims |
| G4 | Implementation: Implement deterministic simulator and all baseline policies under shared scenario generator, seeds, resource limits, and event traces | Reproducible runnable code and configuration hashes |
| G5 | Ablations: Compare static, auction-only, cooperation-only, sequential auction+greedy help, joint optimizer, proposed method, no-commitment, no-help, no-reassignment | Isolate actual contribution from known components |
| G6 | Evaluation: Report task success, makespan, total utility, aid cost, missed primary commitments, fairness, runtime, messages, robustness; paired confidence intervals and corrected tests | No unmeasured claims of superior intelligence |
| G7 | Security transfer: After general algorithm is validated, map tasks to share transmission/recovery; enforce access structures, correlated-compromise, authentication and loss constraints | Separate cryptographic guarantees from scheduling gains |
| G8 | Writing decision: Revisit closest work and document exact novelty delta with evidence IDs, algorithm differences, limitations, reproducibility artifacts | Proceed only if delta and statistically credible gains survive strong baselines |

## Required manual full-text audit template
For each critical paper: record bibliographic version; exact algorithm name and equations; who bids; who assigns; when competition ends; whether post-award assistance exists; whether assistance is optional or mandatory; whether it optimizes joint utility; whether commitments are preserved; whether reassignment occurs; complexity; datasets; limitations; PDF page and verbatim 1–2 sentence evidence. Mark each feature PRESENT / ABSENT_AFTER_FULL_REVIEW / UNCLEAR; never mark absent based on keyword search.

## Discussion/proposal ingestion
- Prior discussion text available: True (52689 characters).
- Split-Path DOCX text available: True (5787 characters).
- Their contents inform the research proposition but are not empirical evidence of novelty.

## Files generated
`concept_evidence_matrix.csv`, `traceable_passages.csv`, `priority_fulltext_queue.csv`, `novelty_claim_register.csv`, `research_gates.csv`, `source_manifest.csv`, `audit_statistics.json`.
