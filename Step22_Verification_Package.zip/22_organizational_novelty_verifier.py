#!/usr/bin/env python3
"""Offline, evidence-traceable audit of organizational competition/cooperation prior art.
No web calls, no LLM judgments, no fabricated negative findings. Python >=3.9.
"""
import argparse,csv,json,re,hashlib,collections,datetime,pathlib,zipfile,xml.etree.ElementTree as ET

CONCEPTS={
 'C1_capability_assessment':[r'capabilit(?:y|ies)',r'competenc(?:e|y)',r'self.assess',r'heterogeneous',r'suitab',r'ability',r'skill'],
 'C2_competitive_task_preference':[r'\bbidd?ing\b',r'\bbids?\b',r'auction',r'contract.net',r'negotiat',r'task.preference',r'competit'],
 'C3_task_assignment':[r'task.allocat',r'task.assign',r'role.allocat',r'task.distribut',r'coalition.formation',r'award(?:ed|ing)?'],
 'C4_commitment_after_assignment':[r'commitment',r'joint.intent',r'accept(?:ance|ed)?',r'responsibilit',r'after.assignment',r'post.allocat'],
 'C5_mutual_assistance':[r'mutual.assist',r'help(?:ing|ed)?\s+(?:other|another|team)',r'peer.assist',r'task.support',r'workload.shar',r'subcontract',r'collaborat'],
 'C6_global_team_utility':[r'global.objective',r'team.utility',r'collective.performance',r'system.level',r'global.reward',r'joint.reward',r'overall.performance',r'group.utility'],
 'C7_reassignment_recovery':[r'reassign',r're.allocat',r'fault.toler',r'failure.recover',r'dynamic.task',r'adaptiv'],
 'C8_explicit_phase_transition':[r'competition.to.cooperation',r'competitive.cooperative',r'competition.and.cooperation',r'phase.transition',r'after.(?:task.)?allocation',r'from.competition.to.cooperation'],
 'C9_security_constraints':[r'secret.shar',r'confidential',r'adversar',r'multipath',r'authenticat',r'compromis',r'threshold'],
}
# Relevance triggers are candidates for reading, never claims that the paper implements a mechanism.
PRIORITY_IDS=['OI0005','OI0031','OI0002','OI0020','OI0035','OI0028','OI0010','OI0027','OI0013','OI0001','RW0072','RW0180','RW0199','RW0226']
CLAIMS=[
 ('N1','Capability-based task evaluation is new','Established related work in heterogeneous capability/task assignment','Do not claim novelty of capability matching alone'),
 ('N2','Competition for responsibility is new','Contract-net, auction and market-based allocation are established','Do not claim novelty of bidding/selection alone'),
 ('N3','Cooperation after assignment is new','Teamwork, joint intentions and collaborative execution are established','Do not claim novelty of cooperation alone'),
 ('N4','A commitment-aware assistance decision rule is new','Not established by current automated evidence','Verify primary algorithms and identify a precise non-equivalent rule'),
 ('N5','Joint assignment and assistance with feasible guarantees is new','Not established by current automated evidence','Compare against joint assignment, coalition and DCOP methods'),
 ('N6','Secure multipath deployment is new','Secret sharing and adaptive multipath delivery already have direct prior art','Novelty must reside in a distinct verified organizational mechanism or guarantee'),
]

def read_csv(path):
 if not path or not path.exists(): return []
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def txt(v):return str(v or '').strip()
def number(v):
 try:return float(v)
 except (ValueError,TypeError):return 0.0
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(v):return txt(v).replace('|','\\|').replace('\n',' ')[:260]
def docx_text(p):
 if not p or not p.exists():return ''
 with zipfile.ZipFile(p) as z:
  root=ET.fromstring(z.read('word/document.xml'))
  return '\n'.join(''.join(n.itertext()) for n in root.iter() if n.tag.endswith('}p'))
def marks(text):
 out={}
 for name,patterns in CONCEPTS.items():
  found=[]
  for pattern in patterns:
   m=re.search(pattern,text,re.I)
   if m:found.append(text[max(0,m.start()-55):min(len(text),m.end()+80)].replace('\n',' '))
  out[name]=found[:3]
 return out

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--input-dir',type=pathlib.Path,default=pathlib.Path('.'))
 ap.add_argument('--output-dir',type=pathlib.Path,default=pathlib.Path('Step22_Verification'))
 ap.add_argument('--organization-catalog',type=pathlib.Path)
 ap.add_argument('--organization-evidence',type=pathlib.Path)
 ap.add_argument('--vc-catalog',type=pathlib.Path)
 ap.add_argument('--vc-evidence',type=pathlib.Path)
 ap.add_argument('--discussion',type=pathlib.Path)
 ap.add_argument('--splitpath-docx',type=pathlib.Path)
 args=ap.parse_args();base=args.input_dir;out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
 def choose(explicit,name):return explicit if explicit else base/name
 files={'organization_catalog':choose(args.organization_catalog,'literature_catalog.csv'), 'organization_evidence':choose(args.organization_evidence,'evidence_passages(2).csv'), 'vc_catalog':choose(args.vc_catalog,'screening_matrix(2).csv'), 'vc_evidence':choose(args.vc_evidence,'evidence_passages(3).csv'),'discussion':choose(args.discussion,'Chat1(20261016-203707).txt'),'splitpath_docx':args.splitpath_docx}
 # Evidence(2).csv is the organizational extraction in the original Step21 run; avoid mixing with RW.
 oc=read_csv(files['organization_catalog']);oe=read_csv(files['organization_evidence']);vc=read_csv(files['vc_catalog']);ve=read_csv(files['vc_evidence'])
 if not oc:raise SystemExit('Missing organizational literature_catalog.csv; supply --organization-catalog')
 if not oe or not any(txt(x.get('id')).startswith('OI') for x in oe):
  raise SystemExit('Organizational evidence file absent/mismatched: supply --organization-evidence with OI IDs')
 if not vc or not ve:raise SystemExit('Missing VC catalog/evidence: supply --vc-catalog and --vc-evidence')
 if not any(txt(x.get('id')).startswith('RW') for x in ve):raise SystemExit('VC evidence file lacks RW IDs')
 discussion=files['discussion'].read_text(encoding='utf-8-sig',errors='replace') if files['discussion'].exists() else ''
 proposal=docx_text(files['splitpath_docx'])
 grouped=collections.defaultdict(list)
 for origin,rows in [('OI',oe),('RW',ve)]:
  for r in rows:grouped[txt(r.get('id'))].append((origin,r))
 catalog={txt(r.get('id')):r for r in oc+vc}
 rows=[]; queue=[]; evidence_rows=[]
 for pid,record in catalog.items():
  evidence=grouped.get(pid,[])
  abstract=txt(record.get('abstract'))
  metadata=txt(record.get('title'))+' '+abstract
  mm=marks(metadata)
  fullmarks={k:[] for k in CONCEPTS}
  for origin,e in evidence:
   passage=txt(e.get('passage_verbatim_extracted'))
   em=marks(passage)
   for k,v in em.items():
    if v:fullmarks[k].append(txt(e.get('evidence_id'))+' (p.'+txt(e.get('page'))+')')
   evidence_rows.append({'paper_id':pid,'evidence_id':txt(e.get('evidence_id')),'page':txt(e.get('page')),'text':passage,'concept_candidates':'; '.join(k for k,v in em.items() if v),'verification':'UNVERIFIED_EXTRACTION'})
  features={k:('EVIDENCE_CANDIDATE' if fullmarks[k] else 'METADATA_CANDIDATE' if mm[k] else 'NOT_OBSERVED') for k in CONCEPTS}
  # Important: NOT_OBSERVED is NOT ABSENT; no automated absence conclusions.
  candidate_count=sum(bool(fullmarks[k]) for k in CONCEPTS)
  score=candidate_count*3+sum(bool(mm[k]) for k in CONCEPTS)+ (12 if pid in PRIORITY_IDS else 0)
  row={'id':pid,'year':txt(record.get('year')),'title':txt(record.get('title')),'doi':txt(record.get('doi')),'source':('OI' if pid.startswith('OI') else 'RW'),'has_extracted_passages':bool(evidence),'evidence_count':len(evidence),'review_priority_score':score,'evidence_ids':'; '.join(txt(e.get('evidence_id')) for _,e in evidence[:8]),'pdf_path_original':txt(record.get('pdf_path')),'review_status':'PENDING_HUMAN_VERIFICATION',**features}
  rows.append(row)
  if pid in PRIORITY_IDS or score>=17:
   queue.append({'id':pid,'score':score,'title':row['title'],'doi':row['doi'],'why_prioritized': 'named_close_competitor' if pid in PRIORITY_IDS else 'multi_concept_candidate','available_evidence':len(evidence),'next_action':'Read complete methods/algorithms and check C4-C8 with page-specific citations','claim_absence_allowed':'NO'})
 def savecsv(name,data,columns=None):
  if not data:return
  columns=columns or list(data[0])
  with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
   w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(data)
 rows.sort(key=lambda x:(-x['review_priority_score'],x['id']))
 queue.sort(key=lambda x:(-x['score'],x['id']))
 savecsv('concept_evidence_matrix.csv',rows)
 savecsv('priority_fulltext_queue.csv',queue)
 savecsv('traceable_passages.csv',evidence_rows)
 claimrows=[{'claim_id':a,'claim':b,'current_evidence_assessment':c,'required_action':d,'decision':'NOT_CLEARED_FOR_NOVELTY_CLAIM'} for a,b,c,d in CLAIMS]
 savecsv('novelty_claim_register.csv',claimrows)
 manifest=[{'source':k,'path':str(v) if v else 'NOT_PROVIDED','exists':bool(v and v.exists()),'sha256':digest(v) if v and v.exists() else '','bytes':v.stat().st_size if v and v.exists() else 0} for k,v in files.items()]
 savecsv('source_manifest.csv',manifest)
 counts={'organization_records':len(oc),'organization_extracted_passages':len(oe),'organization_distinct_pdfs_with_passages':len(set(x['id'] for x in oe)),'vc_records':len(vc),'vc_extracted_passages':len(ve),'vc_distinct_pdfs_with_passages':len(set(x['id'] for x in ve)),'discussion_characters':len(discussion),'proposal_docx_characters':len(proposal),'priority_queue':len(queue),'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (out/'audit_statistics.json').write_text(json.dumps(counts,indent=2),encoding='utf-8')
 stages=[
 ('G0','Evidence verification','Verify original full-text methods for 14 named competitors, reconcile DOI/version, annotate C1-C9 as PRESENT/ABSENT/UNCLEAR with page and direct algorithm evidence','No novelty claims until each critical comparator is verified'),
 ('G1','Formal model','Define agents, heterogeneous task skills, task dependencies, capacities, commitments, aid feasibility, stochastic task completion and global utility','Produce unambiguous optimization problem and feasible action set'),
 ('G2','Novel decision mechanism','Derive a joint task-allocation and conditional-help policy with marginal global gain, counterfactual cost of abandoning primary work, assistance budget and coordination overhead','Algorithm must differ operationally from auction+greedy-help'),
 ('G3','Theoretical guarantees','Prove feasibility preservation; establish a limited improvement/approximation or regret bound under explicit assumptions; characterize worst-case overhead','Avoid unsupported universal optimality claims'),
 ('G4','Implementation','Implement deterministic simulator and all baseline policies under shared scenario generator, seeds, resource limits, and event traces','Reproducible runnable code and configuration hashes'),
 ('G5','Ablations','Compare static, auction-only, cooperation-only, sequential auction+greedy help, joint optimizer, proposed method, no-commitment, no-help, no-reassignment','Isolate actual contribution from known components'),
 ('G6','Evaluation','Report task success, makespan, total utility, aid cost, missed primary commitments, fairness, runtime, messages, robustness; paired confidence intervals and corrected tests','No unmeasured claims of superior intelligence'),
 ('G7','Security transfer','After general algorithm is validated, map tasks to share transmission/recovery; enforce access structures, correlated-compromise, authentication and loss constraints','Separate cryptographic guarantees from scheduling gains'),
 ('G8','Writing decision','Revisit closest work and document exact novelty delta with evidence IDs, algorithm differences, limitations, reproducibility artifacts','Proceed only if delta and statistically credible gains survive strong baselines'),
 ]
 savecsv('research_gates.csv',[{'gate':g,'name':n,'deliverable':d,'acceptance_criterion':a} for g,n,d,a in stages])
 # Prioritized methods use grounded identifiers, not claims of verified method absence.
 top=[r for r in rows if r['id'] in PRIORITY_IDS]
 md=['# Step 22 — Evidence-Constrained Algorithmic Novelty Roadmap','',f"Generated: {counts['generated_utc']}",'','## Input integrity and coverage',f"- Organizational catalog: **{len(oc)}**; organizational passage records: **{len(oe)}**, spanning **{counts['organization_distinct_pdfs_with_passages']}** papers.",f"- Visual-cryptography/multipath catalog: **{len(vc)}**; extracted passages: **{len(ve)}**, spanning **{counts['vc_distinct_pdfs_with_passages']}** papers.",'- Source file checksums and original Windows PDF paths are preserved in `source_manifest.csv` and `concept_evidence_matrix.csv`.','- No original PDFs were attached for systematic full-paper reading. Passages may include reference-list mentions, column mixing, or unrelated claims.','- **NOT_OBSERVED never means ABSENT.** Keywords only nominate papers for review.','', '## Formal research proposition','Each agent assesses feasible tasks and seeks responsibility; a feasible organizational assignment is agreed; each agent honors its primary task and provides assistance if doing so increases expected global utility without violating commitments or hard constraints. Reassignment is event-triggered.','', '## Novelty verdict','**NOT YET VERIFIED.** Contract-net, auctions, role allocation, and teamwork cover substantial components. The candidate contribution must be a precisely defined *commitment-preserving, counterfactual, global-benefit assistance policy jointly integrated with task assignment*, not a relabeling of known mechanisms.','', '## Closest-work reading queue','| ID | Year | Title | PDF passages | Candidate concepts |','|---|---:|---|---:|---|']
 for r in top:
  concepts=', '.join(k.split('_',1)[0] for k in CONCEPTS if r[k]=='EVIDENCE_CANDIDATE') or 'none in extracts'
  md.append(f"| {r['id']} | {r['year']} | {safe(r['title'])} | {r['evidence_count']} | {concepts} |")
 md+=['','## Claim-by-claim status','| Claim | Evidence assessment | Action |','|---|---|---|']
 for a,b,c,d in CLAIMS:md.append(f'| {a}: {b} | {c} | {d} |')
 md+=['','## Proposed algorithmic research plan','', '### Candidate mechanism: Commitment-Preserving Counterfactual Assistance (CPCA)','For each assigned agent i and a potential assistance action (i -> j), estimate the **counterfactual** change in team utility relative to continuing its own task. Assistance is allowed only when primary-task commitments, resources, dependencies, and security constraints remain feasible. The organizational controller compares feasible help actions and reallocations, accounting for control overhead and uncertainty.','',r'Let \(\Delta_{ij}=\mathbb E[J_{team}\mid do(help_{i\to j})]-\mathbb E[J_{team}\mid do(no\ help)]-\lambda C_{ij}\). The controller chooses a feasible action maximizing positive \(\Delta_{ij}\), subject to a bound on primary-task failure probability and per-agent budgets. This is a *candidate design*, not a novel theorem or verified invention.','', '### Essential algorithm comparisons','1. Static skill-based assignment with no help.','2. Contract-net / auction task assignment with independent execution.','3. Cooperative team assignment without competitive bidding.','4. Auction + conventional greedy assistance (strong sequential baseline).','5. Joint task assignment + assistance via MILP on small instances (optimality reference).','6. Proposed CPCA with counterfactual global gain and commitment constraints.','7. CPCA minus counterfactual estimation; minus commitment; minus assistance; minus event-triggered reassignment.','', '### Evaluation design','- Synthetic heterogeneous agents (skills, capacities, dependencies), varied agent/task counts, delayed or noisy ability estimates, task failures and correlated disruptions.','- Use paired scenarios and shared random seeds; tune on separate development scenarios; report means, medians, dispersion, paired confidence intervals, multiple-comparison control and effect sizes.','- Report makespan, task completion, global utility, missed commitments, help rate, fairness, computational latency, communication overhead, and scalability.','- Include negative and adversarial cases: inaccurate self-assessment, selfish preference, assistance overhead exceeding benefit, overload, conflicting commitments, and high failure correlation.','- On small instances, compare against an exact joint optimization formulation and report optimality gaps; on larger instances report wall-clock budgets.','', '### Security-transfer boundary','The attached Split-Path proposal specifies (2,2) XOR shares sent over Wi-Fi/LTE. This establishes neither active-message authenticity nor loss tolerance. The organizational mechanism may optimize delivery, but cryptographic privacy and availability require separate formal definitions and security-preserving constraints.','', '## Sequential research gates','| Gate | Work | Acceptance criterion |','|---|---|---|']
 for g,n,d,a in stages:md.append(f'| {g} | {n}: {d} | {a} |')
 md+=['','## Required manual full-text audit template','For each critical paper: record bibliographic version; exact algorithm name and equations; who bids; who assigns; when competition ends; whether post-award assistance exists; whether assistance is optional or mandatory; whether it optimizes joint utility; whether commitments are preserved; whether reassignment occurs; complexity; datasets; limitations; PDF page and verbatim 1–2 sentence evidence. Mark each feature PRESENT / ABSENT_AFTER_FULL_REVIEW / UNCLEAR; never mark absent based on keyword search.','', '## Discussion/proposal ingestion',f'- Prior discussion text available: {bool(discussion)} ({len(discussion)} characters).',f'- Split-Path DOCX text available: {bool(proposal)} ({len(proposal)} characters).','- Their contents inform the research proposition but are not empirical evidence of novelty.','', '## Files generated','`concept_evidence_matrix.csv`, `traceable_passages.csv`, `priority_fulltext_queue.csv`, `novelty_claim_register.csv`, `research_gates.csv`, `source_manifest.csv`, `audit_statistics.json`.']
 (out/'Detailed_Algorithmic_Contribution_Plan.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
 print(json.dumps(counts,indent=2));print('OUTPUT',out.resolve())
if __name__=='__main__':main()
