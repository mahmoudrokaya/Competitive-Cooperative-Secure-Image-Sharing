#!/usr/bin/env python3
"""Mandatory deterministic preflight for G factorial engine."""
import importlib.util,types
from pathlib import Path
HERE=Path(__file__).resolve().parent

def load(name):
 p=HERE/name;spec=importlib.util.spec_from_file_location('pre_'+name[:2],p)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 driver=load('61_experiment_g_factorial.py');engine=load('60_g_factorial_engine.py')
 s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py');s35=load('35_packet_recovery.py')
 c=driver.defaults();c.update(jobs=4,capacity=2,contention_capacity=1,
   failure_at_ms=0.0,max_interventions_per_job=3,seed=2026)
 a=driver.config_args(c)
 rgb=bytes(range(256))*400
 e=dict(split='synthetic',image='synthetic',sha256='synthetic')
 all_results=[]
 for method in c['methods']:
  for mask in range(16):
   trace=[]
   r=engine.execute(e,rgb,method,mask,'iid_0.01',0,a,s33,s34,s35,trace)
   assert r['successes']==a.jobs,(method,mask,r)
   assert r['capacity_violations']==r['reservation_leaks']==0
   assert r['committed']==r['released']
   assert (r['assists']==0 if not mask&4 else True)
   assert (r['reassignments']==0 if not mask&8 else True)
   all_results.append(r)
 # Severe synthetic packet loss: interventions must be reachable and controlled by switches.
 a.failure_at_ms=20.0
 a.policy='none'
 for mask in range(16):
  trace=[]
  r=engine.execute(e,rgb,c['methods'][1],mask,'iid_0.95',0,a,s33,s34,s35,trace)
  assert r['committed']==r['released'] and not r['capacity_violations']
  if not(mask&12):assert r['assists']==r['reassignments']==0
  if not(mask&4):assert r['assists']==0
  if not(mask&8):assert r['reassignments']==0
  all_results.append(r)
 assert any(r['assists']>0 for r in all_results),'Assistance never activated'
 assert any(r['reassignments']>0 for r in all_results),'Reassignment never activated'
 print('PASS: 16 factorial arms; two methods; no-loss exact reconstruction; severe-loss intervention switches; capacity/release invariants')
if __name__=='__main__':main()
