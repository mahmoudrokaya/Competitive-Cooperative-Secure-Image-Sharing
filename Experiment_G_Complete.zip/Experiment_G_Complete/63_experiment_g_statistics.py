#!/usr/bin/env python3
"""Paired 2^4 factorial contrasts with image-cluster bootstrap and Holm adjustment."""
import argparse,csv,json,random,statistics
from collections import defaultdict
from pathlib import Path
FACTORS=['bidding','ownership','assistance','reassignment']
METRICS=['success_rate','wire_ratio','mean_censored_ms','assists','reassignments']

def csvwrite(path,rows):
 if not rows:raise ValueError('No results')
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def mean(x):return sum(x)/len(x)

def ci(vals):
 s=sorted(vals);return s[int(.025*(len(s)-1))],s[int(.975*(len(s)-1))]

def holm(pvalues):
 n=len(pvalues);order=sorted(range(n),key=lambda i:pvalues[i]);res=[0.]*n;running=0.
 for rank,i in enumerate(order):
  running=max(running,min(1.,pvalues[i]*(n-rank)));res[i]=running
 return res

def analyze(input_path,out,bootstrap,seed):
 out.mkdir(parents=True,exist_ok=True)
 with input_path.open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
 if not rows:raise ValueError('Empty input')
 # Each experimental block must have exactly the 16 configurations.
 blocks=defaultdict(dict)
 for r in rows:
  key=(r['sha256'],r['scenario'],r['repeat'],r['method'])
  mask=int(r['arm'][1:]);
  if mask in blocks[key]:raise ValueError(f'Duplicate factorial arm {key} {mask}')
  blocks[key][mask]=r
 if any(set(v)!=set(range(16)) for v in blocks.values()):raise ValueError('Incomplete factorial blocks')
 images=sorted({k[0] for k in blocks})
 if len(images)<2:raise ValueError('At least two distinct images required for image-cluster inference')
 grouped=defaultdict(list)
 for k,v in blocks.items():grouped[k[0]].append(v)
 descriptive=[]
 for mask in range(16):
  rs=[v[mask] for v in blocks.values()]
  descriptive.append(dict(arm=f'G{mask:02d}',**{f:int(bool(mask&(1<<i))) for i,f in enumerate(FACTORS)},
   batches=len(rs),jobs=sum(int(r['jobs']) for r in rs),
   **{metric:mean([float(r[metric]) for r in rs]) for metric in METRICS}))
 csvwrite(out/'G_04_factorial_descriptive.csv',descriptive)
 # Full factorial effect: E[Y|factor=1]-E[Y|factor=0] averaging other switches.
 # Pair interaction: E[Y|11]-E[Y|10]-E[Y|01]+E[Y|00], averaging other switches.
 terms=[(f,(i,)) for i,f in enumerate(FACTORS)]
 terms += [(FACTORS[i]+' x '+FACTORS[j],(i,j)) for i in range(4) for j in range(i+1,4)]
 terms += [('assistance x reassignment | bidding='+str(b)+' ownership='+str(o), (2,3,b,o)) for b in (0,1) for o in (0,1)]
 rng=random.Random(seed)
 # Compute image-cluster contributions, not treating repeated simulations as independent images.
 result=[]
 for metric in METRICS:
  for label,term in terms:
   def block_effect(v):
    if len(term)==1:
     i=term[0];return mean([float(v[m][metric]) for m in range(16) if m&(1<<i)])-mean([float(v[m][metric]) for m in range(16) if not m&(1<<i)])
    i,j=term[:2]
    selected=range(16)
    if len(term)==4:
     b,o=term[2:];selected=[m for m in range(16) if bool(m&1)==bool(b) and bool(m&2)==bool(o)]
    cell=lambda x,y:mean([float(v[m][metric]) for m in selected if bool(m&(1<<i))==bool(x) and bool(m&(1<<j))==bool(y)])
    return cell(1,1)-cell(1,0)-cell(0,1)+cell(0,0)
   contributions={im:mean([block_effect(v) for v in grouped[im]]) for im in images}
   observed=mean(list(contributions.values()))
   draws=[]
   for _ in range(bootstrap):
    sample=[rng.choice(images) for _ in images]
    draws.append(mean([contributions[x] for x in sample]))
   low,high=ci(draws)
   # Sign-flip randomization approximation at image level; descriptive exploratory p-value.
   null=[]
   for _ in range(bootstrap):null.append(mean([contributions[im]*(1 if rng.getrandbits(1) else -1) for im in images]))
   p=(1+sum(abs(v)>=abs(observed)-1e-12 for v in null))/(bootstrap+1)
   result.append(dict(metric=metric,term=label,estimate=observed,ci_low=low,ci_high=high,
      p_signflip=p,n_images=len(images),n_blocks=len(blocks)))
 for metric in METRICS:
  indices=[i for i,r in enumerate(result) if r['metric']==metric]
  adjusted=holm([result[i]['p_signflip'] for i in indices])
  for i,p in zip(indices,adjusted):result[i]['p_holm_within_metric']=p
 csvwrite(out/'G_05_factorial_effects.csv',result)
 # Mechanism distinguishability diagnostics: effect exactly zero across all blocks.
 diag=[]
 for label,term in terms:
  if len(term)!=1:continue
  i=term[0]
  for metric in ('success_rate','wire_ratio','mean_censored_ms'):
   differences=[]
   for v in blocks.values():
    for m in range(16):
     if not(m&(1<<i)):
      differences.append(float(v[m|(1<<i)][metric])-float(v[m][metric]))
   diag.append(dict(factor=label,metric=metric,pairs=len(differences),
     exact_equal_pairs=sum(abs(x)<1e-12 for x in differences),
     exact_equal_fraction=sum(abs(x)<1e-12 for x in differences)/len(differences),
     positive_pairs=sum(x>1e-12 for x in differences),negative_pairs=sum(x<-1e-12 for x in differences)))
 csvwrite(out/'G_06_equivalence_diagnostics.csv',diag)
 (out/'G_07_analysis_metadata.json').write_text(json.dumps(dict(seed=seed,bootstrap=bootstrap,images=len(images),blocks=len(blocks),
   inference_unit='image SHA256 cluster',effects='marginal main effects and second-order difference-in-differences',
   caveats=['Exploratory tests; Holm correction within each metric only','Sign-flip assumes symmetric cluster effects under the null','Conditional contrasts prespecified for assistance x reassignment','Zero differences are evidence of indistinguishable behavior in observed scenarios, not equivalence proof','Synthetic simulation causal contrasts do not establish real-world causal effects']),indent=2),encoding='utf-8')
 print(json.dumps(dict(images=len(images),blocks=len(blocks),arms=16,effects=len(result),out=str(out)),indent=2))

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True)
 p.add_argument('--out',type=Path,required=True);p.add_argument('--bootstrap',type=int,default=2000)
 p.add_argument('--seed',type=int,default=2026);a=p.parse_args()
 if a.bootstrap<200:raise ValueError('At least 200 bootstrap draws required')
 analyze(a.input,a.out,a.bootstrap,a.seed)
if __name__=='__main__':main()
