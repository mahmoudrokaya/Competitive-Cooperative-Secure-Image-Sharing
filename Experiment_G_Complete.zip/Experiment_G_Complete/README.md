# Experiment G — Organizational Synergy and Causality

A **complete 16-arm factorial ablation** with four binary mechanisms:

- B: competitive path bidding (`mask & 1`)
- O: ownership-aware duplicate-path penalty and reservation checks (`mask & 2`)
- A: assistance on detected failed fragments (`mask & 4`)
- R: reassignment on detected failed fragments (`mask & 8`)

All 16 combinations G00–G15 are evaluated under the **same image, method, recovery policy, scenario, repetition, capacities, and exogenous packet-loss seed**. The optimizer does not know future packet losses. The engine is adapted from the original A3.1 capacity-aware event simulator. Cryptographic and transport primitives are copied unmodified.

## Install

Extract the folder `Experiment_G_Complete` into `D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Code`.

Install dependencies: `python -m pip install pillow cryptography`.

## Mandatory preflight

```powershell
$root = 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments'
$code = "$root\Code\Experiment_G_Complete"
python "$code\62_experiment_g_preflight.py"
```

Preflight covers loss-free reconstruction for both exact-RGB methods across all 16 arms; capacity/release invariants; and switch isolation under severe synthetic packet loss. **Stop on failure.**

## Execute the development experiment

```powershell
python "$code\61_experiment_g_factorial.py" `
  --config "$code\experiment_g_config.json" `
  --data 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data' `
  --out "$root\Results\Experiment_G_Complete"
```

Default: four train and four validation images, three repetitions, seven scenarios, two protection methods, 16 arms. Expected **5,376 run records**. Set `max_images_per_split` to `0` only after confirming the development design; it uses *all train/validation images* and can be slow. **Do not add the held-out test split.**

## Statistics

```powershell
python "$code\63_experiment_g_statistics.py" `
  --input "$root\Results\Experiment_G_Complete\G_01_runs.csv" `
  --out "$root\Results\Experiment_G_Complete" `
  --bootstrap 2000 --seed 2026
```

Outputs:
- `G_00_manifest.csv`: image hashes and provenance
- `G_01_runs.csv`: complete factorial batch records
- `G_02_events.csv`: time-ordered scheduling and intervention events
- `G_03_metadata.json`: exact config, hashes, limitations
- `G_04_factorial_descriptive.csv`: arm summaries
- `G_05_factorial_effects.csv`: four main effects, six two-way interactions, four conditional A×R effects; paired image-cluster intervals
- `G_06_equivalence_diagnostics.csv`: exact-zero paired differences
- `G_07_analysis_metadata.json`: statistical caveats

## Scientific interpretation

A full factorial ablation permits estimation of marginal contributions and interactions, rather than comparing only `full` against `reassignment`. **It cannot guarantee positive synergy**. If A and R are functionally indistinguishable under the simulator, the diagnostic output will reveal zero or near-zero differences. The current prototype's assistance and reassignment both rely on alternate-path retransmission; their labels differ, but a distinct helper/ownership transfer protocol is not fully modeled. Therefore, any inferred A×R interaction is a **simulator-level interaction**, not proof of a novel distributed protocol. Ownership is an abstract reservation policy, not a cryptographic security proof. Real-world causal claims require an independently implemented and validated distributed system.

No rerun of Experiments A–F is needed.
