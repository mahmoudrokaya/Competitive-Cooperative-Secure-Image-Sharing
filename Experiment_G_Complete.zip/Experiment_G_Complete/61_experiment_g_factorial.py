#!/usr/bin/env python3
"""Experiment G: full 2^4 factorial organizational ablation.

Research simulator only. Factors: bidding B, ownership O, assistance A,
reassignment R. Fixed protection/recovery within each matched block.
"""
import argparse,csv,hashlib,importlib.util,json,platform,sys,types
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent

def load(name):
    p=HERE/name
    spec=importlib.util.spec_from_file_location('g_'+name[:2],p)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def write_csv(path,rows):
    if not rows: raise ValueError('Empty output is not allowed')
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def defaults():
    return dict(seed=2026, max_images_per_split=4,repeats=3,jobs=4,
        scenarios=['iid_0.01','iid_0.10','iid_0.20','burst_0.10','burst_0.20','path_failure','contention'],
        methods=['AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3'],
        capacity=4,contention_capacity=2,policy='fec_arq',mtu=1000,header_bytes=20,
        fec_group=4,max_retries=3,failed_path=1,failure_at_ms=180.0,
        burst_persist=.85,timeout_ms=3000.0,detection_ms=80.0,
        queue_penalty_ms=20.0,duplicate_path_penalty_ms=10.0,
        max_interventions_per_job=3,max_events=100000,
        path_rates=[20.,10.,15.],path_delays=[10.,40.,25.],
        bootstrap=2000)

def config_args(cfg):
    a=types.SimpleNamespace(**cfg)
    a.path_rates=tuple(a.path_rates);a.path_delays=tuple(a.path_delays)
    return a

def manifest(root,n):
    records=[];seen=set()
    for split in ('train','val'):
        d=root/'BSR'/'BSDS500'/'data'/'images'/split
        if not d.is_dir():raise FileNotFoundError(d)
        paths=sorted(p for p in d.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png'))
        if n>0:paths=paths[:n]
        if not paths:raise ValueError(f'No images in {d}')
        for p in paths:
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            if h in seen:raise ValueError(f'Duplicate image content: {p}')
            seen.add(h)
            with Image.open(p) as im:w,ht=im.size
            records.append(dict(split=split,image=p.name,sha256=h,
                relative_path=p.relative_to(root).as_posix(),width=w,height=ht))
    return records

def run(cfg,data,out,limit=None):
    out.mkdir(parents=True,exist_ok=True)
    a=config_args(cfg);s33=load('33_expanded_baseline.py');s34=load('34_multipath_loss_simulator.py')
    s35=load('35_packet_recovery.py');engine=load('60_g_factorial_engine.py')
    s33.selftest()
    entries=manifest(data,int(cfg['max_images_per_split']))
    write_csv(out/'G_00_manifest.csv',entries)
    rows=[];traces=[]
    for i,e in enumerate(entries):
        p=data/e['relative_path']
        if hashlib.sha256(p.read_bytes()).hexdigest()!=e['sha256']:raise RuntimeError('Image changed')
        with Image.open(p) as im:rgb=im.convert('RGB').tobytes()
        for scenario in cfg['scenarios']:
            for rep in range(cfg['repeats']):
                for method in cfg['methods']:
                    for mask in range(16):
                        events=[]
                        result=engine.execute(e,rgb,method,mask,scenario,rep,a,s33,s34,s35,events)
                        result.update(arm=f'G{mask:02d}',bidding=(mask>>0)&1,
                            ownership=(mask>>1)&1,assistance=(mask>>2)&1,reassignment=(mask>>3)&1)
                        if result['capacity_violations'] or result['reservation_leaks'] or result['committed']!=result['released']:
                            raise AssertionError(('runtime invariant',result))
                        rows.append(result)
                        for ev in events:
                            ev['arm']=f'G{mask:02d}';ev['bidding']=(mask>>0)&1
                            ev['ownership']=(mask>>1)&1;ev['assistance']=(mask>>2)&1;ev['reassignment']=(mask>>3)&1
                        traces.extend(events)
                print(f'{e["image"]} {scenario} repetition={rep}: all 16 arms completed',flush=True)
        if limit and i+1>=limit:break
    write_csv(out/'G_01_runs.csv',rows)
    write_csv(out/'G_02_events.csv',traces)
    metadata=dict(config=cfg,records=len(rows),images=min(len(entries),limit or len(entries)),
        python=sys.version,platform=platform.platform(),
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')},
        limitations=['Synthetic deterministic transport; not a real distributed system',
            'Factorial ablations identify effects in this simulator, not real-world causal effects',
            'Assistance and reassignment use the same alternate-path transport primitive but differ in declared organizational action',
            'No cryptographic access-control proof; no deployment claims',
            'Fixed image protection and recovery within each matched block',
            'The organizational mechanisms are not necessarily behaviorally distinct in every network state',
            'Censored failures at timeout; no queueing/coding CPU cost',
            'Development data only; held-out generalization remains separate'])
    (out/'G_03_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    return rows

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',type=Path,default=HERE/'experiment_g_config.json')
    p.add_argument('--data',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    cfg=json.loads(args.config.read_text(encoding='utf-8'))
    if cfg['repeats']<1 or cfg['jobs']<1 or cfg['max_images_per_split']<0:raise ValueError('Invalid counts')
    run(cfg,args.data,args.out)
if __name__=='__main__':main()
