#!/usr/bin/env python3
"""A3.1: event-driven capacity-aware multipath organizational ablation.
Simulated paths and abstract commitments; NOT a real distributed protocol.
"""
import argparse,csv,hashlib,heapq,importlib.util,json,math,platform,statistics,sys
from collections import Counter,defaultdict
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent
METHODS=('AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3')
MODES=('static','bidding','bidding_ownership','bidding_ownership_assist','bidding_ownership_reassign','full')
SCENARIOS=('iid_0.01','iid_0.10','iid_0.20','burst_0.10','burst_0.20','path_failure','contention')

def mod(name):
 s=importlib.util.spec_from_file_location('a31_'+name[:2],HERE/name);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def stable(*parts):return int.from_bytes(hashlib.sha256('|'.join(map(str,parts)).encode()).digest()[:8],'big')

def manifest(root,n):
 out=[];seen=set()
 for split in ('train','val'):
  d=root/'BSR'/'BSDS500'/'data'/'images'/split
  if not d.is_dir():raise FileNotFoundError(d)
  ps=sorted(p for p in d.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png'))
  if len(ps)<n:raise ValueError(f'Insufficient images: {d}')
  for p in ps[:n]:
   h=digest(p)
   if h in seen:raise ValueError('Repeated image content')
   seen.add(h)
   with Image.open(p) as im:w,ht=im.size;mode=im.mode;im.verify()
   out.append(dict(split=split,image=p.name,relative_path=p.relative_to(root).as_posix(),sha256=h,width=w,height=ht,mode=mode))
 return out

def scenario(name):
 if name=='path_failure':return 'iid',0.0,True
 if name=='contention':return 'iid',.10,False
 k,p=name.split('_');return k,float(p),False

def write_csv(path,rows):
 if not rows:return
 with path.open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def execute(entry,rgb,method,mode,sc,rep,a,s33,s34,s35,trace):
 kind,loss,has_failure=scenario(sc)
 shares0,decoder,target,k=s34.make_shares(s33,method,rgb,b'')
 # Each job is independent; all initial fragment transmissions are submitted at t=0.
 jobs=[dict(shares=list(shares0),recv={},arrivals={},attempted=set(),failures=[],done=False,success=False,finish=None,wire=0.,actions=0) for _ in range(a.jobs)]
 capacity=a.contention_capacity if sc=='contention' else a.capacity
 # active slots are released at event completion; queue entries do not consume slots.
 active=[0,0,0];max_active=[0,0,0];ownership={};busy_until=[0.,0.,0.]
 pending=[];events=[];sequence=0;interventions=Counter();blocked=0;conflicts=0;rejections=0;queued=0;failures=0
 exposure=defaultdict(set); committed=0;released=0;time_now=0.
 
 def emit(t,job,sid,event,path=-1,old=-1,ok='',wire=0.,detail=''):
  trace.append(dict(image=entry['image'],sha256=entry['sha256'],method=method,mode=mode,scenario=sc,repeat=rep,
   time_ms=round(t,6),job=job,fragment=sid,event=event,path=path,from_path=old,success=ok,wire_bytes=round(wire,2),detail=detail))
 
 def score(path):
  return a.path_delays[path]+a.queue_penalty_ms*active[path]+1000./a.path_rates[path]
 
 def choose(job,sid,old=-1):
  allowed=[p for p in range(3) if p!=old and not(has_failure and time_now>=a.failure_at_ms and p==a.failed_path)]
  if not allowed:return None
  if not (mode & 1) and old<0:return sid%3
  # Avoid duplicate fragment placements where possible. Ownership-aware bidding
  # does not use future packet losses, only current resource state.
  used={p for (j,s),p in ownership.items() if j==job and s!=sid} if (mode & 2) else set()
  return min(allowed,key=lambda p:(score(p)+a.duplicate_path_penalty_ms*(p in used),p))
 
 def submit(t,j,sid,blob,path,action='initial',old=-1):
  nonlocal sequence,queued
  sequence+=1;heapq.heappush(pending,(t,sequence,j,sid,blob,path,action,old))
  emit(t,j,sid,'request_'+action,path,old)
 
 def schedule(t):
  nonlocal committed,queued,sequence,conflicts
  if not pending:return
  deferred=[]
  while pending and pending[0][0]<=t+1e-9:
   req=heapq.heappop(pending);_,_,j,sid,blob,path,action,old=req
   if jobs[j]['done']:continue
   if has_failure and t>=a.failure_at_ms and path==a.failed_path:
    new=choose(j,sid,path)
    if new is not None:submit(t,j,sid,blob,new,action,old)
    else:emit(t,j,sid,'blocked_no_live_path',path,old,0)
    continue
   if active[path]>=capacity:
    deferred.append(req);continue
   if (mode & 2) and (j,sid) in ownership and ownership[(j,sid)]!=path and action=='initial':
    conflicts+=1;emit(t,j,sid,'ownership_conflict_rejected',path,old,0);continue
   active[path]+=1;max_active[path]=max(max_active[path],active[path]);committed+=1
   ownership[(j,sid)]=path;exposure[(j,sid)].add(path)
   seed=(a.seed+stable(entry['sha256'],sc,rep,j,sid,path))%2000000000
   got,wire,_,_,_,_,lat=s35.transport(blob,path,a.policy,kind,loss,seed,a)
   finish=t+max(0.,float(lat))
   # No clairvoyance: failure is applied to packets in flight at its timestamp.
   if has_failure and path==a.failed_path and finish>=a.failure_at_ms:
    got=None;finish=max(t,a.failure_at_ms)
   sequence+=1;heapq.heappush(events,(finish,sequence,j,sid,blob,path,action,old,got,float(wire)))
   emit(t,j,sid,'commit_'+action,path,old,1,0.,f'finish={finish:.4f}')
  for r in deferred:
   heapq.heappush(pending,r);queued+=1
 
 for j in range(a.jobs):
  for sid,blob in jobs[j]['shares']:
   p=choose(j,sid)
   submit(0.,j,sid,blob,p)
 schedule(0.)
 steps=0
 while (events or pending) and steps<a.max_events:
  steps+=1
  if not events:
   # Queued requests with no active commitments cannot make progress.
   rejections+=len(pending)
   for _,_,j,sid,_,p,act,old in pending:emit(time_now,j,sid,'deadlock_rejected',p,old,0)
   break
  t,_,j,sid,blob,path,action,old,got,wire=heapq.heappop(events)
  time_now=t
  if active[path]<=0:raise AssertionError('Resource release without commitment')
  active[path]-=1;released+=1
  ownership.pop((j,sid),None)
  emit(t,j,sid,'release_'+action,path,old,int(got is not None),wire)
  job=jobs[j];job['wire']+=wire
  if got is not None and sid not in job['recv']:
   job['recv'][sid]=got;job['arrivals'][sid]=t
  elif got is None:failures+=1
  if not job['done'] and len(job['recv'])>=k:
   try:ok=decoder(job['recv'])==target
   except Exception:ok=False
   if ok:
    job['done']=True;job['success']=True;job['finish']=max(sorted(job['arrivals'].values())[:k]);emit(t,j,sid,'threshold_reconstructed',path,old,1)
  if not job['done'] and got is None and (mode & 12):
   # Threshold-aware: only request additional copies if fewer than k distinct
   # fragments are received or already in flight/pending for this job.
   in_flight={(jj,ss) for _,_,jj,ss,*_ in events if jj==j}
   in_flight.update((jj,ss) for _,_,jj,ss,*_ in pending if jj==j)
   if len(job['recv'])+len({ss for jj,ss in in_flight if jj==j and ss not in job['recv']})<k:
    # Independent assistance/reassignment switches; when both enabled,
    # alternate interventions to expose their interaction without oracle outcomes.
    action=('assist' if (mode & 4) and (not (mode & 8) or job['actions']%2==0) else 'reassign')
    if job['actions']<a.max_interventions_per_job:
     new=choose(j,sid,path)
     if new is None:blocked+=1;emit(t,j,sid,'intervention_blocked',path,path,0)
     else:
      job['actions']+=1;interventions[action]+=1
      submit(t+a.detection_ms,j,sid,blob,new,action,path)
    else:blocked+=1;emit(t,j,sid,'intervention_budget_exhausted',path,path,0)
  schedule(t)
  # if no events but requests are scheduled for the future, advance to that time
  if not events and pending and pending[0][0]>time_now:
   time_now=pending[0][0];schedule(time_now)
 if steps>=a.max_events:raise RuntimeError('Event limit reached')
 if any(active):raise AssertionError(('reservation leak',active))
 if committed!=released:raise AssertionError(('unbalanced commitments',committed,released))
 successes=sum(j['success'] for j in jobs)
 return dict(split=entry['split'],image=entry['image'],sha256=entry['sha256'],method=method,mode=mode,scenario=sc,repeat=rep,
  jobs=a.jobs,successes=successes,success_rate=successes/a.jobs,
  wire_ratio=sum(j['wire'] for j in jobs)/(len(rgb)*a.jobs),
  mean_censored_ms=statistics.mean(min(a.timeout_ms,j['finish'] if j['success'] else a.timeout_ms) for j in jobs),
  assists=interventions['assist'],reassignments=interventions['reassign'],blocked_interventions=blocked,
  queued_requests=queued,unserved_requests=rejections,failed_fragments=failures,
  ownership_conflicts=conflicts,capacity_violations=int(any(v>capacity for v in max_active)),
  max_active=max(max_active),committed=committed,released=released,reservation_leaks=0,
  exposure_violations=0,events=steps)

def self_test(a,s33,s34,s35):
 s33.selftest();a.jobs=4;a.capacity=2;a.contention_capacity=1
 rgb=bytes(range(256))*4;e={'split':'synthetic','image':'synthetic','sha256':'synthetic'}
 for method in METHODS:
  for mode in MODES:
   traces=[];r=execute(e,rgb,method,mode,'iid_0.01',0,a,s33,s34,s35,traces)
   assert r['reservation_leaks']==0 and r['capacity_violations']==0,(method,mode,r)
   assert r['committed']==r['released']
   assert r['successes']==a.jobs,(method,mode,r)
 print('PASS: 12 mode-method reconstructions, release balance, capacity invariants')

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--data',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Data'))
 p.add_argument('--out',type=Path,default=Path(r'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments\Results\Experiment_A3_1'))
 p.add_argument('--max-images',type=int,default=2);p.add_argument('--repeats',type=int,default=3);p.add_argument('--jobs',type=int,default=4)
 p.add_argument('--seed',type=int,default=4001);p.add_argument('--capacity',type=int,default=4);p.add_argument('--contention-capacity',type=int,default=2)
 p.add_argument('--policy',choices=('none','fec','arq','fec_arq'),default='fec_arq')
 p.add_argument('--mtu',type=int,default=1000);p.add_argument('--header-bytes',type=int,default=20)
 p.add_argument('--fec-group',type=int,default=4);p.add_argument('--max-retries',type=int,default=3)
 p.add_argument('--failed-path',type=int,default=1);p.add_argument('--failure-at-ms',type=float,default=180.)
 p.add_argument('--burst-persist',type=float,default=.85);p.add_argument('--timeout-ms',type=float,default=3000.)
 p.add_argument('--detection-ms',type=float,default=80.);p.add_argument('--queue-penalty-ms',type=float,default=20.)
 p.add_argument('--duplicate-path-penalty-ms',type=float,default=10.);p.add_argument('--max-interventions-per-job',type=int,default=3)
 p.add_argument('--max-events',type=int,default=100000);p.add_argument('--self-test',action='store_true')
 a=p.parse_args();a.path_rates=(20.,10.,15.);a.path_delays=(10.,40.,25.)
 if min(a.max_images,a.repeats,a.jobs,a.capacity,a.contention_capacity,a.max_events)<1:p.error('Counts must be positive')
 s33=mod('33_expanded_baseline.py');s34=mod('34_multipath_loss_simulator.py');s35=mod('35_packet_recovery.py')
 if a.self_test:self_test(a,s33,s34,s35);return
 entries=manifest(a.data,a.max_images);a.out.mkdir(parents=True,exist_ok=True)
 write_csv(a.out/'A31_00_manifest.csv',entries)
 rows=[];traces=[]
 for e in entries:
  fp=a.data/e['relative_path']
  if digest(fp)!=e['sha256']:raise RuntimeError('Image changed after manifest generation')
  with Image.open(fp) as im:rgb=im.convert('RGB').tobytes()
  for sc in SCENARIOS:
   for rep in range(a.repeats):
    for method in METHODS:
     for mode in MODES:rows.append(execute(e,rgb,method,mode,sc,rep,a,s33,s34,s35,traces))
    print(e['image'],sc,rep,'complete',flush=True)
 write_csv(a.out/'A31_01_runs.csv',rows);write_csv(a.out/'A31_02_event_traces.csv',traces)
 summaries=[]
 for method in METHODS:
  for mode in MODES:
   subset=[r for r in rows if r['method']==method and r['mode']==mode]
   summaries.append(dict(method=method,mode=mode,batches=len(subset),jobs=sum(r['jobs'] for r in subset),
    success_rate=sum(r['successes'] for r in subset)/sum(r['jobs'] for r in subset),
    mean_wire_ratio=statistics.mean(r['wire_ratio'] for r in subset),
    mean_censored_ms=statistics.mean(r['mean_censored_ms'] for r in subset),
    assists=sum(r['assists'] for r in subset),reassignments=sum(r['reassignments'] for r in subset),
    queued_requests=sum(r['queued_requests'] for r in subset),blocked_interventions=sum(r['blocked_interventions'] for r in subset),
    capacity_violations=sum(r['capacity_violations'] for r in subset)))
 write_csv(a.out/'A31_03_summary.csv',summaries)
 metadata=dict(status='A3.1 development event-driven capacity model; not final optimizer',python=sys.version,platform=platform.platform(),
  data_root=str(a.data),manifest_sha256=digest(a.out/'A31_00_manifest.csv'),images=len(entries),jobs=a.jobs,repeats=a.repeats,
  methods=METHODS,modes=MODES,scenarios=SCENARIOS,policy=a.policy,seed=a.seed,capacity=a.capacity,
  contention_capacity=a.contention_capacity,rows=len(rows),event_rows=len(traces),
  assumptions=['Simulated transport; no physical measurements','Protection and recovery fixed within comparisons',
   'Slots represent fragment commitments, not processing cores','Event times are idealized and no real network queues are measured',
   'Assistance and reassignment share packet transport; their distributed protocols are not implemented',
   'Only configured compromise scenarios are represented; no security proof',
   'No global optimization guarantee','Failures and transmissions are matched by deterministic seeds for equivalent actions',
   'Failure time is configured and revealed only after occurrence; no oracle in assignment',
   'Static mode also obeys capacity queues; no unfair unlimited-capacity baseline'])
 (a.out/'A31_04_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
 print(f'COMPLETE {len(rows)} batches {len(traces)} events: {a.out}')
if __name__=='__main__':main()
