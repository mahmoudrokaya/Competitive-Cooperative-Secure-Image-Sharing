#!/usr/bin/env python3
"""Step 24: evidence-gated full-text comparison. No network calls or novelty auto-certification.
Requires Python 3.9+; optional: pip install pymupdf
"""
import argparse,csv,json,re,hashlib,datetime,collections
from pathlib import Path

MECH={
'capability_evaluation':[r'capabilit(?:y|ies)',r'competenc(?:e|y)',r'suitabilit',r'ability to perform',r'performance estimat'],
'competitive_preference':[r'\bbid(?:ding|s)?\b',r'\bauction',r'contract.net',r'task preference',r'competi(?:tion|tive)'],
'assignment':[r'task allocat',r'task assign',r'role allocat',r'winning bid',r'award(?:ed|ing)? task'],
'commitment':[r'\bcommitment',r'\bobligation',r'joint intention',r'guaranteed completion',r'service.level'],
'post_assignment_assistance':[r'\bassist(?:ance|ing)?\b',r'\bhelp(?:ing|er)?\b',r'mutual support',r'workload shar',r'cooperat'],
'global_utility':[r'global (?:utility|objective|reward)',r'team (?:utility|reward|performance)',r'collective (?:objective|utility|performance)',r'social welfare'],
'reassignment':[r'reassign',r'reallocat',r'reorgani',r'role switch',r'dynamic task'],
'counterfactual_assistance':[r'counterfactual',r'marginal (?:utility|gain|benefit|contribution)',r'opportunity cost',r'with(?:out)? assistance',r'difference reward'],
'commitment_guarantee':[r'chance.constraint',r'probabilistic guarantee',r'commitment (?:preserv|constraint)',r'feasibility preserv',r'primary.task constraint'],
}
HEAD=re.compile(r'(?im)^\s*(?:\d+(?:\.\d+){0,2}[.)]?\s+)?(abstract|introduction|related work|background|preliminaries|methodology|methods|proposed (?:method|approach|algorithm|framework)|algorithm|problem formulation|system model|experiments|experimental (?:setup|results)|results|discussion|conclusion|references|bibliography)\s*$')
METHOD=('method','algorithm','formulation','system model','proposed','preliminar')

def rows(p):
    with open(p,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,records,fields):
    p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
def norm(p):return str(p).replace('\\','/').lower()
def classify_section(text):
    m=list(HEAD.finditer(text[:4000]))
    if not m:return 'unknown'
    return m[-1].group(1).lower()
def section_type(s):
    if any(k in s for k in METHOD):return 'method_candidate'
    if 'reference' in s or 'bibliography' in s:return 'references_excluded'
    if any(k in s for k in ('experiment','result')):return 'evaluation_candidate'
    if any(k in s for k in ('related','background','introduction')):return 'context_only'
    return 'unclassified'
def windows_path_candidates(raw,roots):
    if not raw:return []
    p=Path(raw)
    candidates=[p]
    parts=re.split(r'[\\/]+',raw)
    for root in roots:
        for i in range(len(parts)):
            suffix=Path(*parts[i:]);candidates.append(root/suffix)
        candidates.append(root/parts[-1])
    return candidates

def find_pdf(rec,roots,index):
    raw=rec.get('pdf_path','')
    for p in windows_path_candidates(raw,roots):
        try:
            if p.is_file() and p.suffix.lower()=='.pdf':return p,'resolved'
        except OSError:
            continue
    if raw:
        hits=index.get(Path(raw.replace('\\','/')).name.lower(),[])
        if len(hits)==1:return hits[0],'resolved_filename'
        if len(hits)>1:return None,'ambiguous_filename'
    return None,'missing_pdf'

def pdf_pages(p,max_pages):
    import fitz
    with fitz.open(str(p)) as doc:
        for i in range(min(len(doc),max_pages)):
            page=doc[i]
            # sorted text mitigates (does not eliminate) column interleaving
            yield i+1,page.get_text('text',sort=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--priority',required=True,help='Step23 G0_priority_methods_review.csv')
    ap.add_argument('--organization-catalog',required=True)
    ap.add_argument('--organization-evidence',required=True)
    ap.add_argument('--vc-catalog',default='')
    ap.add_argument('--vc-evidence',default='')
    ap.add_argument('--pdf-root',action='append',default=[],help='Repeat to add original PDF directories')
    ap.add_argument('--output-dir',required=True)
    ap.add_argument('--max-pages',type=int,default=120)
    ap.add_argument('--max-excerpts-per-mechanism',type=int,default=5)
    ap.add_argument('--include-vc',action='store_true',help='Include VC entries listed in priority CSV')
    a=ap.parse_args()
    out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=True)
    roots=[Path(x).resolve() for x in a.pdf_root]
    priority=rows(a.priority);org=rows(a.organization_catalog)
    vc=rows(a.vc_catalog) if a.vc_catalog else []
    catalog={r['id']:r for r in org+vc}
    org_e=rows(a.organization_evidence)
    vc_e=rows(a.vc_evidence) if a.vc_evidence else []
    evid=collections.defaultdict(list)
    for r in org_e+vc_e:evid[r.get('id','')].append(r)
    index=collections.defaultdict(list)
    for root in roots:
        if root.exists():
            for p in root.rglob('*.pdf'):index[p.name.lower()].append(p)
    candidates=[];review=[];missing=[];summary=[];hashes=[]
    try:import fitz;pdf_available=True
    except ImportError:pdf_available=False
    for item in priority:
        ident=item.get('id','');rec=catalog.get(ident,{})
        if not rec:continue
        title=rec.get('title',item.get('title',''))
        p,status=find_pdf(rec,roots,index)
        pdf_text=[];pages_count=0
        if p and pdf_available:
            try:
                for page,text in pdf_pages(p,a.max_pages):
                    pages_count+=1;pdf_text.append((page,text))
                hashes.append({'id':ident,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
                status='pdf_extracted'
            except Exception as ex:status='pdf_error:'+str(ex)[:130]
        elif p and not pdf_available:status='pymupdf_not_installed'
        if status!='pdf_extracted':missing.append({'id':ident,'title':title,'doi':rec.get('doi',''),'pdf_status':status,'original_pdf_path':rec.get('pdf_path',''),'suggested_action':'Locate authorized full PDF and add its parent via --pdf-root; do not interpret missing as absence'})
        # Page-based candidates; never infer author ownership of methods automatically.
        for mech,patterns in MECH.items():
            matches=[]
            for page,text in pdf_text:
                for pattern in patterns:
                    for m in list(re.finditer(pattern,text,re.I))[:8]:
                        start=max(0,m.start()-270);end=min(len(text),m.end()+420)
                        snippet=' '.join(text[start:end].split())
                        # approximate section by nearest heading before occurrence on same page
                        section=classify_section(text[:m.start()]);stype=section_type(section)
                        matches.append((0 if stype=='method_candidate' else 1 if stype=='unclassified' else 2,page,section,stype,snippet,pattern))
            matches.sort(key=lambda x:(x[0],x[1]))
            for rank,page,section,stype,snippet,pattern in matches[:a.max_excerpts_per_mechanism]:
                candidates.append({'id':ident,'title':title,'mechanism':mech,'source_type':'original_pdf_page','page':page,'section_guess':section,'evidence_role':stype,'matched_pattern':pattern,'excerpt':snippet,'verification':'UNVERIFIED_CANDIDATE','pdf_path':str(p)})
            # fallback excerpts are not fulltext verification
            if not matches:
                fallback=[]
                for e in evid.get(ident,[]):
                    passage=e.get('passage','') or e.get('passage_verbatim_extracted','')
                    if any(re.search(pat,passage,re.I) for pat in patterns):fallback.append(e)
                for e in fallback[:min(2,a.max_excerpts_per_mechanism)]:
                    passage=e.get('passage','') or e.get('passage_verbatim_extracted','')
                    candidates.append({'id':ident,'title':title,'mechanism':mech,'source_type':'prior_extracted_passage','page':e.get('page',''),'section_guess':'unknown','evidence_role':'unclassified','matched_pattern':'keyword_locator','excerpt':' '.join(passage.split())[:850],'verification':'UNVERIFIED_CANDIDATE','pdf_path':e.get('pdf_path','')})
            review.append({'id':ident,'title':title,'doi':rec.get('doi',''),'mechanism':mech,'automated_pdf_status':status,'original_pdf_candidates':len(matches),'finding':'UNDETERMINED','author_method_verified':'NO','exact_equation_or_rule':'','page_and_section':'','comparison_to_CPOA':'','reviewer':'','review_date':'','note':'Search hit is not proof; review full methods, pseudocode, appendices, and citations'})
        summary.append({'id':ident,'title':title,'doi':rec.get('doi',''),'pdf_status':status,'pdf_pages_processed':pages_count,'extracted_passages_available':len(evid.get(ident,[])),'method_verified':'NO'})
    write(out/'G0_algorithm_comparison_review.csv',review,list(review[0]) if review else ['id'])
    write(out/'G0_fulltext_evidence_candidates.csv',candidates,list(candidates[0]) if candidates else ['id'])
    write(out/'G0_missing_fulltext.csv',missing,['id','title','doi','pdf_status','original_pdf_path','suggested_action'])
    write(out/'G0_paper_coverage.csv',summary,list(summary[0]) if summary else ['id'])
    write(out/'G0_pdf_sha256.csv',hashes,['id','path','sha256'])
    report=[
'# Step 24 — Full-Text Algorithmic Prior-Art Comparison',
'',f'Generated UTC: {datetime.datetime.now(datetime.timezone.utc).isoformat()}',
'',f'Priority papers processed: {len(summary)}',f'Original PDFs extracted: {sum(s["pdf_status"]=="pdf_extracted" for s in summary)}',
 f'PDFs unresolved or not extracted: {len(missing)}',f'Candidate passages: {len(candidates)}',f'Manual method verification rows: {len(review)}',
'', '## Evidence discipline',
'All findings remain UNDETERMINED. Keywords and section guesses locate potential evidence but do not establish author methods, novelty, or absence. Prior extracted passages may contain column mixing, citations, and bibliography text. Confirm source pages, equations, and pseudocode manually.',
'', '## Required manual method comparison',
'For each priority paper record: capability estimation, task bids/preferences, allocation, post-award commitment, peer assistance, global utility, reassignment, marginal-gain policy, and commitment feasibility guarantees. For each supported mechanism quote or paraphrase only the author’s actual decision rule, with PDF page and equation/algorithm number.',
'', '## Candidate CPOA differentiation to test',
'Capability-ranked task proposals → feasible responsibility assignment → explicit primary commitments → joint counterfactual evaluation of help including opportunity cost → conservative feasibility check → nonconflicting assistance selection → event-triggered reassignment with switching cost.',
'Each element may be established independently; the integrated policy is NOT certified novel.',
'', '## Go/no-go criteria',
'GO only after (1) closest papers reviewed at equation level, (2) distinguishable operational decision rule, (3) reproducible strong baselines including auction+greedy-help and small-instance joint optimum, (4) valid feasibility claim under stated assumptions, and (5) statistically supported paired improvements or a precisely scoped theoretical advantage.',
'', '## Missing source PDFs',
'Provide original PDF directories with repeated --pdf-root arguments. The crawler’s Windows pdf_path metadata does not itself provide accessible bytes.',
'', '## Execution summary',
'```json',json.dumps({'papers':len(summary),'pdfs_extracted':sum(s['pdf_status']=='pdf_extracted' for s in summary),'candidate_passages':len(candidates),'manual_review_rows':len(review),'pymupdf_available':pdf_available},indent=2),'```'
]
    (out/'Step24_G0_Decision_and_Action_Plan.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(json.dumps({'papers':len(summary),'pdfs_extracted':sum(s['pdf_status']=='pdf_extracted' for s in summary),'missing_pdfs':len(missing),'candidate_passages':len(candidates),'manual_review_rows':len(review),'output':str(out)},indent=2))
if __name__=='__main__':main()
