#!/usr/bin/env python3
"""Experiment F: integrated, constrained J1-J6 simulated image delivery.
Research simulator; not a deployed security protocol or a global-optimum proof.
All decisions use forecasts; realized loss is observed only after commitment.
"""
import argparse,csv,hashlib,importlib.util,itertools,json,math,statistics,time,sys,platform
from collections import defaultdict
from dataclasses import dataclass,field
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
HERE=Path(__file__).resolve().parent
ARMS={'J1_static':(0,0,0),'J2_recovery':(0,1,0),'J3_organization':(0,0,1),'J4_protection':(1,0,0),'J5_recovery_organization':(0,1,1),'J6_joint':(1,1,1)}
POLICIES=('none','fec','arq','fec_arq')
AUTH={'AES128_GCM_PSK','AESGCM_XOR_Erasure_2of3','X25519_HKDF_AES128_GCM'}
FIELDS=['split','image','sha256','scenario','loss_rate','repeat','arm','jobs','successes','success_rate','wire_bytes','wire_ratio','mean_censored_ms','realized_objective','mean_predicted_objective','planning_ms','methods','policies','assignments','commitments','assistance','reassignments','interventions','security_rejections','capacity_rejections','reliability_rejections','infeasible_jobs','auth_failures','invariant_violations','trace_key']

def load(filename):
    p=HERE/filename; spec=importlib.util.spec_from_file_location('f_'+filename.split('_')[0],p)
    if spec is None or spec.loader is None:raise RuntimeError(f'Cannot load {p}')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def digest(*items):return int.from_bytes(hashlib.sha256('|'.join(map(str,items)).encode()).digest()[:8],'big')
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_csv(path,rows,fields):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def config(path):
    c=json.loads(Path(path).read_text(encoding='utf-8'))
    c['data_root']=Path(c['data_root']);c['weights']={k:float(v) for k,v in c['weights'].items()}
    assert set(c['weights'])=={'failure','time','wire','intervention'}
    assert all(x>=0 for x in c['weights'].values()) and abs(sum(c['weights'].values())-1)<1e-9
    assert len(c['path_capacity'])==len(c['path_rates'])==len(c['path_delays'])==3
    assert len(c['agent_capacity'])==len(c['agent_path_eligibility'])==3
    assert all(len(x)>0 and set(x)<=set(range(3)) for x in c['agent_path_eligibility'])
    assert all(x>0 for x in c['path_capacity']+c['agent_capacity'])
    assert c['fixed_method'] in c['methods'] and c['fixed_policy'] in POLICIES
    assert set(c['allowed_paths'])<=set(range(3)) and c['allowed_paths']
    assert all(set(x)<=set(range(3)) for x in c['compromised_path_sets'])
    assert c['max_interventions_per_job']>=0 and c['jobs']>0 and c['repeats']>0
    assert 0<=c['min_predicted_reliability']<=1 and 0<=c['burst_persist']<1
    assert all(0<=x<1 for x in c['loss_rates']) and c['mtu']>0 and c['fec_group']>=2
    if c['require_authentication'] and c['fixed_method'] not in AUTH:raise ValueError('Fixed method fails authentication requirement')
    return c

@dataclass
class State:
    path_load:list=field(default_factory=lambda:[0,0,0]);agent_load:list=field(default_factory=lambda:[0,0,0])
    exposure:dict=field(default_factory=lambda:defaultdict(lambda:defaultdict(set)))
    owners:set=field(default_factory=set);commitments:dict=field(default_factory=dict);job_methods:dict=field(default_factory=dict)
    assistance:int=0;reassignments:int=0;interventions:int=0
    security_rejections:int=0;capacity_rejections:int=0;reliability_rejections:int=0
    infeasible_jobs:int=0;auth_failures:int=0;invariant_violations:int=0

@dataclass
class Plan:
    method:str;policy:str;assignment:tuple;shares:list;decoder:object;target:bytes;k:int
    score:float;predicted_reliability:float;predicted_time:float;predicted_wire:float

def allowed(job,method,share_ids,assignment,s,c,ignore=None):
    # assignment elements are (agent_id,path_id); security history is monotone.
    if len(share_ids)!=len(assignment):return False,'eligibility'
    pd=defaultdict(int);ad=defaultdict(int)
    for sid,(agent,path) in zip(share_ids,assignment):
        if path not in c['allowed_paths'] or path not in c['agent_path_eligibility'][agent]:return False,'eligibility'
        pd[path]+=1;ad[agent]+=1
    if any(s.path_load[p]+n-(ignore[0].get(p,0) if ignore else 0)>c['path_capacity'][p] for p,n in pd.items()):return False,'capacity'
    if any(s.agent_load[a]+n-(ignore[1].get(a,0) if ignore else 0)>c['agent_capacity'][a] for a,n in ad.items()):return False,'capacity'
    if method not in AUTH:
        for compromised in c['compromised_path_sets']:
            seen={sid for sid,paths in s.exposure[job].items() if paths.intersection(compromised)}
            seen.update(sid for sid,(_,p) in zip(share_ids,assignment) if p in compromised)
            if len(seen)>=2:return False,'security'
    return True,''

def fragment_prob(n,loss,policy,c):
    count=max(1,math.ceil(n/c['mtu']));q=loss**(c['max_retries']+1) if 'arq' in policy else loss
    if 'fec' in policy:
        k=c['fec_group'];full,partial=divmod(count,k)
        group=lambda x:(1-q)**x+x*q*(1-q)**(x-1)
        return group(k)**full*(group(partial) if partial else 1.)
    return (1-q)**count

def predict(shares,k,assignment,policy,loss,c,interventions=0):
    probs=[];wire=0.;times=[]
    for (_,blob),(_,path) in zip(shares,assignment):
        n=max(1,math.ceil(len(blob)/c['mtu']));probs.append(fragment_prob(len(blob),loss,policy,c))
        parity=math.ceil(n/c['fec_group'])*(c['mtu']+c['header_bytes']) if 'fec' in policy else 0
        retries=sum(loss**j for j in range(1,c['max_retries']+1)) if 'arq' in policy else 0
        wb=(len(blob)+n*c['header_bytes'])*(1+retries)+parity
        wire+=wb;times.append(c['path_delays'][path]+wb*8/(c['path_rates'][path]*1000)+2*c['path_delays'][path]*retries)
    dist=[1.]
    for p in probs:
        nd=[0.]*(len(dist)+1)
        for j,v in enumerate(dist):nd[j]+=v*(1-p);nd[j+1]+=v*p
        dist=nd
    success=sum(dist[k:]);t=sorted(times)[k-1]
    w=c['weights'];score=(w['failure']*(1-success)+w['time']*min(1,t/c['timeout_ms'])+
       w['wire']*wire/max(1,c['_payload_bytes'])+w['intervention']*interventions/max(1,c['max_interventions_per_job']))
    return score,success,t,wire

def candidates(n,organizational,c):
    if not organizational:
        placement=[]
        for i in range(n):
            path=i%3;agent=next((a for a,paths in enumerate(c['agent_path_eligibility']) if path in paths),None)
            if agent is None:return
            placement.append((agent,path))
        yield tuple(placement);return
    options=[(a,p) for a,paths in enumerate(c['agent_path_eligibility']) for p in paths if p in c['allowed_paths']]
    yield from itertools.product(options,repeat=n)

def choose(job,rgb,arm,loss,s,c,m33,m34,preencoded):
    am,ar,ao=ARMS[arm];methods=c['methods'] if am else [c['fixed_method']]
    policies=POLICIES if ar else (c['fixed_policy'],)
    best=None
    for method in methods:
        if c['require_authentication'] and method not in AUTH:continue
        shares,decoder,target,k=preencoded[method]
        ids=[sid for sid,_ in shares]
        for placement in candidates(len(shares),ao,c):
            ok,reason=allowed(job,method,ids,placement,s,c)
            if not ok:
                if reason=='security':s.security_rejections+=1
                else:s.capacity_rejections+=1
                continue
            for policy in policies:
                score,r,t,w=predict(shares,k,placement,policy,loss,c)
                if r<c['min_predicted_reliability']-1e-12:s.reliability_rejections+=1;continue
                key=(score,method,policy,placement)
                if best is None or key<best[0]:best=(key,Plan(method,policy,placement,shares,decoder,target,k,score,r,t,w))
    return best[1] if best else None

def commit(job,plan,s,c):
    if job in s.owners:return False
    ok,reason=allowed(job,plan.method,[i for i,_ in plan.shares],plan.assignment,s,c)
    if not ok:return False
    s.owners.add(job);s.commitments[job]=list(plan.assignment);s.job_methods[job]=plan.method
    for (sid,_),(a,p) in zip(plan.shares,plan.assignment):
        s.path_load[p]+=1;s.agent_load[a]+=1;s.exposure[job][sid].add(p)
    return True

def release(job,s):
    for a,p in s.commitments.pop(job):s.path_load[p]-=1;s.agent_load[a]-=1
    s.owners.remove(job)

def invariants(s,c):
    if any(x<0 or x>cap for x,cap in zip(s.path_load,c['path_capacity'])):return False
    if any(x<0 or x>cap for x,cap in zip(s.agent_load,c['agent_capacity'])):return False
    for job,hist in s.exposure.items():
        if s.job_methods.get(job) in AUTH:continue
        for compromised in c['compromised_path_sets']:
            exposed={sid for sid,paths in hist.items() if paths.intersection(compromised)}
            if len(exposed)>=2:return False
    return True

def transport(blob,path,policy,scenario,loss,repeat,c,m35):
    a=SimpleNamespace(mtu=c['mtu'],fec_group=c['fec_group'],max_retries=c['max_retries'],
        seed=c['seed'],failed_path=c['failed_path'],burst_persist=c['burst_persist'],
        header_bytes=c['header_bytes'],path_rates=c['path_rates'],path_delays=c['path_delays'])
    kind='path_failure' if scenario=='path_failure' else scenario
    return m35.transport(blob,path,policy,kind,loss,repeat,a)

def adapt(job,plan,sid,blob,old,received,s,scenario,loss,rep,c,m35,budget,mode):
    if budget<=0:return 0.,None,False
    current=s.commitments[job];index=[i for i,_ in plan.shares].index(sid)
    options=sorted(((a,p) for a,paths in enumerate(c['agent_path_eligibility']) for p in paths
      if p in c['allowed_paths'] and p!=old[1] and not(scenario=='path_failure' and p==c['failed_path'])),
      key=lambda ap:(c['path_delays'][ap[1]]+len(blob)*8/(c['path_rates'][ap[1]]*1000),ap))
    for new in options:
        ignore=None
        if mode=='reassign':ignore=({old[1]:1},{old[0]:1})
        ok,reason=allowed(job,plan.method,[sid],[new],s,c,ignore)
        if not ok:
            if reason=='security':s.security_rejections+=1
            else:s.capacity_rejections+=1
            continue
        if mode=='reassign':
            s.path_load[old[1]]-=1;s.agent_load[old[0]]-=1
            s.path_load[new[1]]+=1;s.agent_load[new[0]]+=1
            current[index]=new;s.reassignments+=1
        else:s.assistance+=1
        s.interventions+=1;s.exposure[job][sid].add(new[1])
        got,w,_,_,_,_,ms=transport(blob,new[1],plan.policy,scenario,loss,rep+digest(job,sid,mode)%10000000,c,m35)
        if got is not None:received[sid]=got
        if not invariants(s,c):s.invariant_violations+=1;raise AssertionError('Resource invariant')
        return w,c['detection_ms']+ms,got is not None
    return 0.,None,False

def execute(job,plan,s,scenario,loss,rep,c,m35,adaptive):
    received={};arrivals={};wire=0.;failed=[];events=0
    for (sid,blob),place in zip(plan.shares,plan.assignment):
        _,p=place
        got,w,_,_,_,_,ms=transport(blob,p,plan.policy,scenario,loss,rep+digest(job)%10000000,c,m35)
        wire+=w
        if got is None:failed.append((sid,blob,place))
        else:received[sid]=got;arrivals[sid]=ms
    if adaptive and len(received)<plan.k:
        for sid,blob,old in failed:
            if len(received)>=plan.k or events>=c['max_interventions_per_job']:break
            for mode in ('assist','reassign'):
                if events>=c['max_interventions_per_job'] or sid in received:break
                if mode=='assist' and not c['enable_assistance']:continue
                if mode=='reassign' and not c['enable_reassignment']:continue
                before=s.interventions
                w,ms,ok=adapt(job,plan,sid,blob,old,received,s,scenario,loss,rep,c,m35,c['max_interventions_per_job']-events,mode)
                wire+=w;events+=s.interventions-before
                if ms is not None and ok:arrivals[sid]=ms
    success=False
    if len(received)>=plan.k:
        try:success=plan.decoder(received)==plan.target
        except Exception:s.auth_failures+=1
    elapsed=sorted(arrivals.values())[plan.k-1] if success else c['timeout_ms']
    return int(success),wire,elapsed

def batch(entry,rgb,arm,scenario,loss,repeat,c,m33,m34,m35):
    s=State();c['_payload_bytes']=len(rgb);start=time.perf_counter()
    # One shared encoded realization per method and batch: arms differ by decisions, not fresh random shares.
    methods=c['methods'] if not c['require_authentication'] else [m for m in c['methods'] if m in AUTH]
    preencoded={m:m34.make_shares(m33,m,rgb,b'') for m in methods}
    plans=[];results=[];predicted=[]
    for j in range(c['jobs']):
        job=f'{entry["sha256"]}:{scenario}:{loss}:{repeat}:{j}'
        p=choose(job,rgb,arm,loss,s,c,m33,m34,preencoded)
        if p is None or not commit(job,p,s,c):s.infeasible_jobs+=1;results.append((0,0.,c['timeout_ms']));continue
        plans.append((job,p,j));predicted.append(p.score)
    planning=(time.perf_counter()-start)*1000
    for job,p,j in plans:
        results.append(execute(job,p,s,scenario,loss,repeat*100+j,c,m35,bool(ARMS[arm][2])))
    if not invariants(s,c):s.invariant_violations+=1
    for job,p,j in plans:release(job,s)
    if any(s.path_load) or any(s.agent_load) or s.owners:s.invariant_violations+=1
    successes=sum(x[0] for x in results);wire=sum(x[1] for x in results)
    ms=statistics.mean(x[2] for x in results);ratio=wire/max(1,len(rgb)*c['jobs'])
    w=c['weights'];obj=w['failure']*(1-successes/c['jobs'])+w['time']*ms/c['timeout_ms']+w['wire']*ratio+w['intervention']*s.interventions/max(1,c['jobs']*c['max_interventions_per_job'])
    return dict(split=entry['split'],image=entry['image'],sha256=entry['sha256'],scenario=scenario,loss_rate=loss,repeat=repeat,arm=arm,
      jobs=c['jobs'],successes=successes,success_rate=successes/c['jobs'],wire_bytes=wire,wire_ratio=ratio,mean_censored_ms=ms,
      realized_objective=obj,mean_predicted_objective=statistics.mean(predicted) if predicted else '',planning_ms=planning,
      methods=';'.join(p.method for _,p,_ in plans),policies=';'.join(p.policy for _,p,_ in plans),
      assignments=';'.join(','.join(f'{a}:{p}' for a,p in plan.assignment) for _,plan,_ in plans),commitments=len(plans),
      assistance=s.assistance,reassignments=s.reassignments,interventions=s.interventions,security_rejections=s.security_rejections,
      capacity_rejections=s.capacity_rejections,reliability_rejections=s.reliability_rejections,infeasible_jobs=s.infeasible_jobs,
      auth_failures=s.auth_failures,invariant_violations=s.invariant_violations,
      trace_key=f'{c["seed"]}|{entry["sha256"]}|{scenario}|{loss}|{repeat}')

def manifest(c):
    rows=[];seen=set();root=c['data_root']
    for split in c['splits']:
        folder=root/'BSR'/'BSDS500'/'data'/'images'/split
        if not folder.is_dir():raise FileNotFoundError(folder)
        images=sorted(p for p in folder.iterdir() if p.suffix.lower() in ('.jpg','.jpeg','.png'))
        limit=c['max_images_per_split'];images=images[:limit] if limit else images
        if not images:raise RuntimeError(f'No images in {folder}')
        for p in images:
            h=hashfile(p)
            if h in seen:raise RuntimeError('Duplicate image hash in selected sample')
            seen.add(h);rows.append(dict(split=split,image=p.name,sha256=h,path=str(p)))
    return rows

def run(c,out,preflight=False):
    m33=load('33_expanded_baseline.py');m34=load('34_multipath_loss_simulator.py');m35=load('35_packet_recovery.py')
    if preflight:
        m33.selftest();payload=bytes(range(256))*4
        old=(c['jobs'],c['min_predicted_reliability'],c['path_capacity'][:],c['agent_capacity'][:],c['max_interventions_per_job'])
        c['jobs']=2;c['min_predicted_reliability']=0;c['path_capacity']=[20]*3;c['agent_capacity']=[20]*3;c['max_interventions_per_job']=2
        entry=dict(split='synthetic',image='synthetic',sha256=hashlib.sha256(payload).hexdigest())
        for arm in ARMS:
            r=batch(entry,payload,arm,'iid',0.,0,c,m33,m34,m35)
            assert r['successes']==2 and r['invariant_violations']==0,(arm,r)
        c['jobs'],c['min_predicted_reliability'],c['path_capacity'],c['agent_capacity'],c['max_interventions_per_job']=old
        s=State();s.exposure['t'][0].add(0)
        assert not allowed('t','Shamir_GF256_2of3',[1],[(0,0)],s,c)[0]
        assert allowed('t','Shamir_GF256_2of3',[0],[(0,0)],s,c)[0]
        assert not allowed('t','AES128_GCM_PSK',[0],[(0,99)],s,c)[0]
        print('PREFLIGHT PASS: all six arms, reconstruction, resources, cumulative exposure')
        return
    selected=manifest(c);out.mkdir(parents=True,exist_ok=True)
    write_csv(out/'F_00_manifest.csv',selected,['split','image','sha256','path'])
    rows=[]
    for entry in selected:
        p=Path(entry['path']);assert hashfile(p)==entry['sha256']
        with Image.open(p) as im:rgb=im.convert('RGB').tobytes()
        for scenario in c['scenarios']:
            losses=[0.] if scenario=='path_failure' else c['loss_rates']
            for loss in losses:
                for rep in range(c['repeats']):
                    for arm in ARMS:
                        r=batch(entry,rgb,arm,scenario,loss,rep,c,m33,m34,m35);rows.append(r)
                        if r['invariant_violations'] or r['auth_failures']:raise AssertionError(f'Invariant/auth failure: {r}')
                    print(f'{entry["split"]}/{entry["image"]}: {scenario} {loss} rep={rep} completed',flush=True)
    write_csv(out/'F_01_runs.csv',rows,FIELDS)
    serializable={k:(str(v) if isinstance(v,Path) else v) for k,v in c.items() if not k.startswith('_')}
    (out/'F_02_metadata.json').write_text(json.dumps(dict(config=serializable,python=sys.version,platform=platform.platform(),
       rows=len(rows),images=len(selected),source_hashes={f.name:hashfile(f) for f in HERE.glob('*.py')},
       assumptions=['Synthetic deterministic packet erasures; no real sockets or deployed key management',
       'One encoded realization per method per batch, across arms',
       'Path failure modeled as persistent erasure on failed path',
       'No intervention before a failed whole fragment is detected',
       'Interventions are limited per job; fixed recovery policy after commitment',
       'Security constraints are placement/exposure policies, not cryptographic proofs',
       'Joint candidate enumeration is bounded and not a proof of global optimality',
       'Path and agent capacities are concurrent fragment slots; assistance uses spare capacity admission but does not retain a new slot',
       'Censored failure time equals timeout; no queueing or coding CPU cost']),indent=2,default=str),encoding='utf-8')
    print(f'COMPLETE: {len(rows)} paired batch rows -> {out}')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,default=HERE/'experiment_f_config.json')
    ap.add_argument('--out',type=Path,default=HERE/'Results');ap.add_argument('--preflight',action='store_true')
    a=ap.parse_args();c=config(a.config);run(c,a.out,a.preflight)
if __name__=='__main__':main()
