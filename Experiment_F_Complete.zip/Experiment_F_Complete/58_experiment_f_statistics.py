#!/usr/bin/env python3
"""Paired, image-cluster bootstrap and descriptive summaries for Experiment F."""
import argparse,csv,hashlib,json,random,statistics
from collections import defaultdict
from pathlib import Path
METRICS=('success_rate','wire_ratio','mean_censored_ms','realized_objective','planning_ms','interventions')
ARMS=('J1_static','J2_recovery','J3_organization','J4_protection','J5_recovery_organization','J6_joint')
def write(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--out',type=Path,default=None)
    p.add_argument('--bootstrap',type=int,default=2000);p.add_argument('--seed',type=int,default=2026);a=p.parse_args()
    if a.bootstrap<100:raise ValueError('Bootstrap iterations must be >=100')
    out=a.out or a.input.parent;out.mkdir(parents=True,exist_ok=True)
    with a.input.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    if not rows:raise RuntimeError('No experiment rows')
    bykey=defaultdict(dict)
    for r in rows:
        key=(r['sha256'],r['scenario'],r['loss_rate'],r['repeat'])
        if r['arm'] in bykey[key]:raise RuntimeError(f'Duplicate pair: {key} {r["arm"]}')
        bykey[key][r['arm']]=r
    for key,group in bykey.items():
        if set(group)!=set(ARMS):raise RuntimeError(f'Incomplete arm block {key}: {set(ARMS)-set(group)}')
    groups=defaultdict(list)
    for r in rows:groups[(r['scenario'],r['arm'])].append(r)
    summary=[]
    for (scenario,arm),rr in sorted(groups.items()):
        record=dict(scenario=scenario,arm=arm,blocks=len(rr),images=len({r['sha256'] for r in rr}),jobs=sum(int(r['jobs']) for r in rr))
        for m in METRICS:record['mean_'+m]=round(statistics.mean(float(r[m]) for r in rr),9)
        summary.append(record)
    write(out/'F_03_summary.csv',summary)
    comparisons=[];rng=random.Random(a.seed)
    for scenario in sorted({r['scenario'] for r in rows}):
        blocks={key:group for key,group in bykey.items() if key[1]==scenario}
        images=sorted({key[0] for key in blocks})
        if not images:continue
        byimage=defaultdict(list)
        for key,g in blocks.items():byimage[key[0]].append(g)
        for comparator in ARMS[:-1]:
            for metric in METRICS:
                image_diffs={img:statistics.mean(float(g['J6_joint'][metric])-float(g[comparator][metric]) for g in byimage[img]) for img in images}
                # Equal-image weighting; repetitions/scenarios are dependent within image.
                delta=statistics.mean(image_diffs.values());boots=[]
                for _ in range(a.bootstrap):
                    sample=[images[rng.randrange(len(images))] for __ in images]
                    boots.append(statistics.mean(image_diffs[i] for i in sample))
                boots.sort();lo=boots[int(.025*(a.bootstrap-1))];hi=boots[int(.975*(a.bootstrap-1))]
                comparisons.append(dict(scenario=scenario,contrast=f'J6_joint - {comparator}',metric=metric,images=len(images),blocks=len(blocks),difference=round(delta,9),ci95_low=round(lo,9),ci95_high=round(hi,9),bootstrap=a.bootstrap,unit='image_cluster',note='Exploratory unadjusted CI; no multiple-comparison correction'))
    write(out/'F_04_paired_bootstrap.csv',comparisons)
    meta=dict(rows=len(rows),paired_blocks=len(bykey),images=len({r['sha256'] for r in rows}),bootstrap=a.bootstrap,seed=a.seed,
      input_sha256=hashlib.sha256(a.input.read_bytes()).hexdigest(),method='Paired J6 vs J1-J5; image-cluster bootstrap; unadjusted percentile 95% intervals',
      limitations=['Small image counts produce unstable intervals','Do not treat jobs or repeated network traces as independent images','No multiple testing correction','Planning time includes candidate construction and image encoding; not a pure solver benchmark'])
    (out/'F_05_statistics_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
