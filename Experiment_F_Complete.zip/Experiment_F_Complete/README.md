# Experiment F — Integrated constrained J1–J6 simulation

**Status:** Complete runnable *simulation prototype*, not physical network validation, deployed cryptographic security, proof of optimality, or proof of a positive J6 effect. The implementation can yield null or negative comparisons; report those faithfully.

## Contents

- `56_experiment_f_integrated.py`: joint candidate enumeration, method/recovery/agent-path choices, admission, cumulative exposure, FEC/ARQ execution, bounded event-triggered assistance/reassignment, six matched configurations, results and metadata.
- `57_experiment_f_preflight.py`: fail-closed functional and adversarial checks; **run first**.
- `58_experiment_f_statistics.py`: paired image-cluster bootstrap and descriptive summaries.
- `experiment_f_config.json`: frozen experiment configuration; adjust dataset path before use.
- `33_expanded_baseline.py`, `34_multipath_loss_simulator.py`, `35_packet_recovery.py`: unmodified uploaded baseline primitives.
- `38_full_constrained_optimizer_reference.py`: reference original optimizer, preserved without modifications.

## Install

Python 3.10+; `python -m pip install pillow cryptography`.

## PowerShell

```powershell
$root = 'D:\48\481\New Papers\Progressive_HHO_Cryptography\Experiments'
$code = Join-Path $root 'Code\Experiment_F_Complete'
python "$code\57_experiment_f_preflight.py" --config "$code\experiment_f_config.json"
if ($LASTEXITCODE -ne 0) { throw 'Experiment F preflight failed; do not run.' }
python "$code\56_experiment_f_integrated.py" --config "$code\experiment_f_config.json" --out "$root\Results\Experiment_F_Complete"
if ($LASTEXITCODE -ne 0) { throw 'Experiment F execution failed.' }
python "$code\58_experiment_f_statistics.py" --input "$root\Results\Experiment_F_Complete\F_01_runs.csv" --bootstrap 2000 --seed 2026
```

## IMPORTANT before full execution

1. Confirm `data_root` points to the dataset directory containing `BSR/BSDS500/data/images/train` and `val`.
2. This config defaults to **four images per split** as a controlled pilot. Freeze a larger development-only matrix before making claims; change `max_images_per_split` to `0` for all images in selected splits.
3. Do not use held-out images for model tuning. `splits` defaults to `train` and `val`.
4. J1–J6 are **adaptation configurations**, not six objective components. J6 searches method, recovery, and organizational placement. J5 adapts recovery and organization; J1 is fixed.
5. An *agent* and a *path* are separate assignment coordinates; eligibility, capacity, and ownership are checked at commitment. Cumulative exposure is never cleared upon release.
6. Organizational adaptation is triggered only after whole-fragment failure, and is limited by `max_interventions_per_job`. Protection and recovery are selected at initial commitment, **not changed for in-flight fragments**. Consequently, this tests *event-driven organizational replanning*, not full mid-flight protection/recovery reconfiguration.
7. Simulated assistance is an admitted one-shot helper transmission; it does not hold an additional concurrent slot after completion. This is an explicit simplifying assumption.
8. Synthetic loss and ideal feedback exclude real network queueing, jitter, sockets, authentication/key exchange overhead and congestion. XOR-erasure ciphertext fragments do not provide Shamir secrecy.
9. The reliability predictor uses approximate packet independence, including in burst scenarios. Observed reliability is measured independently.
10. The reported `realized_objective` uses censored latency and measured overhead. It is **not** guaranteed to match the forecast used in planning.

## Outputs

- `F_00_manifest.csv` dataset paths and hashes
- `F_01_runs.csv` matched blocks × J1–J6
- `F_02_metadata.json` configuration, source hashes, limitations
- `F_03_summary.csv` scenario × arm descriptive outcomes
- `F_04_paired_bootstrap.csv` J6 contrasts with image-cluster percentile intervals
- `F_05_statistics_metadata.json` inferential protocol and limitations

## Known boundary

This package is an integrated prototype implementing the stated constrained **initial joint selection** plus bounded **organizational** adaptation. It does **not** implement in-flight replacement of protection methods or recovery policies, and must not be described as doing so. It also does not validate claims of emergent synergy or security beyond the specified admission threat model. Those require Experiments G/H and independent evaluation.
