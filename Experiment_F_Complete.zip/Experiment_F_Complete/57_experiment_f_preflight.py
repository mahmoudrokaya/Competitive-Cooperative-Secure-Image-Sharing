#!/usr/bin/env python3
"""Fail-closed Experiment F preflight: tests only, never runs dataset experiments."""
import argparse,importlib.util,json,copy
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('f56',HERE/'56_experiment_f_integrated.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,default=HERE/'experiment_f_config.json');a=ap.parse_args()
    c=f.config(a.config);f.run(c,HERE/'Results',preflight=True)
    m33=f.load('33_expanded_baseline.py');m34=f.load('34_multipath_loss_simulator.py');m35=f.load('35_packet_recovery.py')
    args=__import__('types').SimpleNamespace(mtu=c['mtu'],fec_group=c['fec_group'],max_retries=c['max_retries'],seed=c['seed'],failed_path=c['failed_path'],burst_persist=c['burst_persist'],header_bytes=c['header_bytes'],path_rates=c['path_rates'],path_delays=c['path_delays'])
    m35.selftest(m33,m34,args)
    s=f.State();c2=copy.deepcopy(c)
    assert not f.allowed('a','Shamir_GF256_2of3',[0,1],[(0,0),(1,0)],s,c2)[0]
    assert f.allowed('a','AES128_GCM_PSK',[0],[(0,0)],s,c2)[0]
    c2['path_capacity']=[1,1,1];s.path_load[0]=1
    assert f.allowed('a','AES128_GCM_PSK',[0],[(0,0)],s,c2)[1]=='capacity'
    s=f.State();s.job_methods['x']='Shamir_GF256_2of3';s.exposure['x'][0].add(0);s.exposure['x'][1].add(0)
    assert not f.invariants(s,c)
    s=f.State();s.job_methods['x']='AESGCM_XOR_Erasure_2of3';s.exposure['x'][0].add(0);s.exposure['x'][1].add(0)
    assert f.invariants(s,c)
    assert f.fragment_prob(100,0.,'none',c)==1.
    assert all(f.fragment_prob(1000,x,'none',c)>=f.fragment_prob(1000,y,'none',c) for x,y in [(0,.1),(.1,.2)])
    print('PASS: authorization, exposure, capacity, primitive integrity, policy ordering')
    print(json.dumps({'status':'PASS','arms':list(f.ARMS),'source_root':str(HERE)},indent=2))
if __name__=='__main__':main()
